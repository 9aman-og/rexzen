/* A single, local playback run through the existing illustrated Aero tabs. */
const mounted = new WeakMap();
const STAGE_MS = 5000;
const VISIBILITY = 0.45;
let instanceId = 0;

export function mountAeroMotion(preview) {
  if (!preview?.matches?.("[data-aero-preview]")) return null;
  if (mounted.has(preview)) return mounted.get(preview);
  const tabs = [...preview.querySelectorAll('.preview-tabs [role="tab"]')];
  const tablist = preview.querySelector(".preview-tabs");
  if (tabs.length < 2 || !tablist) return null;
  const doc = preview.ownerDocument, win = doc.defaultView;
  const motion = win.matchMedia("(prefers-reduced-motion: reduce)");
  const cleanups = [];
  const controls = doc.createElement("div");
  controls.className = "aero-motion";
  controls.dataset.aeroMotionControls = "";
  controls.setAttribute("role", "group");
  controls.setAttribute("aria-label", "Illustrated workflow playback");
  const top = doc.createElement("div"), buttons = doc.createElement("div");
  top.className = "aero-motion-top";
  buttons.className = "aero-motion-buttons";
  function makeButton(label) {
    const button = doc.createElement("button");
    button.type = "button";
    button.textContent = label;
    button.setAttribute("aria-label", `${label} illustrated workflow`);
    buttons.append(button);
    return button;
  }
  const play = makeButton("Play"), pause = makeButton("Pause"), replay = makeButton("Replay");
  const status = doc.createElement("p"), note = doc.createElement("p");
  status.className = "aero-motion-status";
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");
  status.setAttribute("aria-atomic", "true");
  note.className = "aero-motion-note";
  note.id = `aero-motion-note-${++instanceId}`;
  note.textContent = "Illustrated workflow · fictional records";
  controls.setAttribute("aria-describedby", note.id);
  const progress = doc.createElement("div"), fill = doc.createElement("span");
  progress.className = "aero-motion-progress";
  progress.setAttribute("role", "progressbar");
  progress.setAttribute("aria-label", "Playback through the current illustrated stage");
  progress.setAttribute("aria-valuemin", "0");
  progress.setAttribute("aria-valuemax", "100");
  fill.className = "aero-motion-progress-fill";
  progress.append(fill);
  top.append(buttons, status);
  controls.append(top, progress, note);
  tablist.after(controls);

  let index = Math.max(0, tabs.findIndex(tab => tab.getAttribute("aria-selected") === "true"));
  let remaining = STAGE_MS, started = 0, timer = null, animation = null;
  let intent = false, running = false, complete = false, destroyed = false, suspended = false, hasRun = false;
  let visible = false, reduced = motion.matches, autoplayAttempted = motion.matches;
  let userInteracted = false, intersectionObserver = null;
  const autoplay = preview.hasAttribute("data-motion-autoplay");
  const selectedIndex = () => Math.max(0, tabs.findIndex(tab => tab.getAttribute("aria-selected") === "true"));
  const name = () => tabs[index].textContent.trim().replace(/^\d{2}\s*/, "");
  const readingFocus = () => preview.contains(doc.activeElement) && !controls.contains(doc.activeElement);
  userInteracted = readingFocus();

  function listen(target, type, handler, options) {
    target.addEventListener(type, handler, options);
    cleanups.push(() => target.removeEventListener(type, handler, options));
  }
  function cancelAnimation() {
    if (animation) animation.cancel();
    animation = null;
  }
  function paintProgress() {
    const amount = Math.max(0, Math.min(1, 1 - remaining / STAGE_MS));
    fill.style.transform = `scaleX(${amount})`;
    progress.setAttribute("aria-valuenow", String(Math.round(amount * 100)));
    progress.setAttribute("aria-valuetext", `${Math.round(amount * 100)} percent of stage ${index + 1} of ${tabs.length}`);
  }
  function update() {
    play.disabled = reduced || intent || complete;
    pause.disabled = reduced || !intent;
    replay.disabled = reduced;
    controls.dataset.playback = reduced ? "reduced" : complete ? "complete" : running ? "playing" : "paused";
    const stage = `stage ${index + 1} of ${tabs.length}: ${name()}`;
    status.textContent = reduced ? "Reduced motion is on. Use the stage tabs to explore." : complete ? "Complete · the proposed plan remains in view." : running ? `Playing · ${stage}` : intent && (doc.hidden || suspended) ? `Paused while this page is hidden · ${stage}` : intent && !visible ? `Paused until the example is in view · ${stage}` : userInteracted ? `Paused for reading · ${stage}` : `${hasRun ? "Paused" : "Ready"} · ${stage}`;
  }
  function stopClock() {
    if (timer !== null) win.clearTimeout(timer);
    timer = null;
    if (running) remaining = Math.max(0, remaining - (win.performance.now() - started));
    running = false;
    started = 0;
    cancelAnimation();
    paintProgress();
  }
  function dispatchSelection(next) {
    index = next;
    preview.dispatchEvent(new win.CustomEvent("aero-preview-select", { detail: { index } }));
  }
  function canPlay() { return intent && !reduced && !doc.hidden && !suspended && visible && !destroyed && preview.isConnected && !readingFocus(); }
  function startClock() {
    if (running || !canPlay()) { update(); return; }
    if (remaining <= 0) { advance(); return; }
    running = true;
    started = win.performance.now();
    const amount = Math.max(0, Math.min(1, 1 - remaining / STAGE_MS));
    cancelAnimation();
    if (fill.animate) {
      try {
        animation = fill.animate([{ transform: `scaleX(${amount})` }, { transform: "scaleX(1)" }], { duration: remaining, easing: "linear", fill: "forwards" });
        animation.finished.catch(() => {});
      } catch { animation = null; }
    }
    timer = win.setTimeout(advance, remaining);
    update();
  }
  function advance() {
    timer = null;
    running = false;
    started = 0;
    remaining = 0;
    cancelAnimation();
    paintProgress();
    if (!canPlay()) { update(); return; }
    if (index === tabs.length - 1) {
      intent = false;
      complete = true;
      update();
      return;
    }
    dispatchSelection(index + 1);
    remaining = STAGE_MS;
    paintProgress();
    startClock();
  }
  function begin(restart = false, automatic = false) {
    if (destroyed || reduced) return;
    stopClock();
    autoplayAttempted = true;
    if (!automatic) userInteracted = false;
    if (restart) { dispatchSelection(0); remaining = STAGE_MS; complete = false; }
    else if (complete) return;
    intent = true;
    hasRun = true;
    paintProgress();
    startClock();
  }
  function manualPause(forReading = false) {
    autoplayAttempted = true;
    userInteracted = true;
    intent = false;
    stopClock();
    if (!forReading) userInteracted = false;
    update();
  }
  function reconcileVisibility() {
    if (!visible || doc.hidden || suspended) { stopClock(); update(); return; }
    if (intent) { startClock(); return; }
    if (autoplay && !autoplayAttempted && !userInteracted && !reduced && !readingFocus()) {
      autoplayAttempted = true;
      begin(true, true);
    } else update();
  }
  function measureVisibility() {
    const rect = preview.getBoundingClientRect();
    const w = Math.max(0, Math.min(rect.right, win.innerWidth) - Math.max(rect.left, 0));
    const h = Math.max(0, Math.min(rect.bottom, win.innerHeight) - Math.max(rect.top, 0));
    visible = rect.width > 0 && rect.height > 0 && w * h / (rect.width * rect.height) >= VISIBILITY;
    reconcileVisibility();
  }
  listen(play, "click", () => begin());
  listen(pause, "click", () => manualPause());
  listen(replay, "click", () => begin(true));
  function readingInteraction(event) {
    if (controls.contains(event.target)) return;
    if (event.target.closest?.('.preview-tabs, .preview-content, [role="tabpanel"]')) manualPause(true);
  }
  listen(preview, "pointerdown", readingInteraction, true);
  listen(preview, "focusin", readingInteraction, true);
  listen(preview, "click", readingInteraction, true);
  listen(preview, "keydown", event => {
    if (event.target.closest?.(".preview-tabs") && ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "Enter", " "].includes(event.key)) readingInteraction(event);
  }, true);
  const selectionObserver = new win.MutationObserver(() => {
    const next = selectedIndex();
    if (next === index) return;
    manualPause(true);
    index = next;
    remaining = STAGE_MS;
    complete = false;
    paintProgress();
    update();
  });
  selectionObserver.observe(tablist, { attributes: true, subtree: true, attributeFilter: ["aria-selected"] });
  cleanups.push(() => selectionObserver.disconnect());
  if (win.IntersectionObserver) {
    intersectionObserver = new win.IntersectionObserver(entries => {
      visible = entries.some(entry => entry.isIntersecting && entry.intersectionRatio >= VISIBILITY);
      reconcileVisibility();
    }, { threshold: [0, VISIBILITY, 1] });
    intersectionObserver.observe(preview);
    cleanups.push(() => intersectionObserver.disconnect());
  } else {
    listen(win, "scroll", measureVisibility, { passive: true });
    listen(win, "resize", measureVisibility, { passive: true });
    measureVisibility();
  }
  listen(doc, "visibilitychange", reconcileVisibility);
  listen(doc, "site-menu-open", () => manualPause());
  listen(win, "pagehide", () => {
    suspended = true;
    intent = false;
    autoplayAttempted = true;
    stopClock();
    intersectionObserver?.disconnect();
    update();
  });
  listen(win, "pageshow", () => {
    if (!suspended) return;
    suspended = false;
    if (intersectionObserver) intersectionObserver.observe(preview);
    else measureVisibility();
    update();
  });
  const motionChanged = event => {
    reduced = event.matches;
    intent = false;
    autoplayAttempted = true;
    stopClock();
    update();
  };
  if (motion.addEventListener) listen(motion, "change", motionChanged);
  else { motion.addListener(motionChanged); cleanups.push(() => motion.removeListener(motionChanged)); }
  function destroy() {
    if (destroyed) return;
    intent = false;
    destroyed = true;
    stopClock();
    cleanups.splice(0).forEach(cleanup => cleanup());
    controls.remove();
    mounted.delete(preview);
  }
  if (doc.body) {
    const removalObserver = new win.MutationObserver(() => { if (!preview.isConnected) destroy(); });
    removalObserver.observe(doc.body, { childList: true, subtree: true });
    cleanups.push(() => removalObserver.disconnect());
  }
  paintProgress();
  update();
  const controller = { preview, play: () => begin(), pause: () => manualPause(), replay: () => begin(true), destroy };
  mounted.set(preview, controller);
  return controller;
}

export function mountAeroMotions(scope = document) {
  const previews = [...scope.querySelectorAll("[data-aero-preview]")];
  if (scope.matches?.("[data-aero-preview]")) previews.unshift(scope);
  const controllers = previews.map(mountAeroMotion).filter(Boolean);
  return { controllers, destroy() { controllers.forEach(controller => controller.destroy()); } };
}

if (typeof document !== "undefined") {
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => mountAeroMotions(document), { once: true });
  else mountAeroMotions(document);
}
