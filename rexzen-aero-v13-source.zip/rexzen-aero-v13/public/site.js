const header = document.querySelector('.site-header');
const toggle = header?.querySelector('.nav-toggle');
const navigation = header?.querySelector('.site-nav');

if (header && toggle && navigation) {
  document.documentElement.classList.add('js');
  const closeNavigation = () => {
    header.classList.remove('nav-open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.textContent = 'Menu';
  };
  toggle.addEventListener('click', () => {
    const isOpen = header.classList.toggle('nav-open');
    toggle.setAttribute('aria-expanded', String(isOpen));
    toggle.textContent = isOpen ? 'Close' : 'Menu';
  });
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    const hasOpenMenu = header.classList.contains('nav-open');
    header.querySelectorAll('details[open]').forEach((menu) => { menu.open = false; });
    closeNavigation();
    if (hasOpenMenu) toggle.focus();
  });
  document.addEventListener('click', (event) => {
    if (!header.contains(event.target)) {
      header.querySelectorAll('details[open]').forEach((menu) => { menu.open = false; });
      closeNavigation();
    }
  });
  header.querySelectorAll('.nav-group').forEach((menu) => {
    menu.addEventListener('toggle', () => {
      if (!menu.open) return;
      header.querySelectorAll('.nav-group').forEach((other) => {
        if (other !== menu) other.open = false;
      });
    });
  });
  matchMedia('(min-width: 861px)').addEventListener('change', closeNavigation);
}

document.querySelectorAll('[data-current-year]').forEach((node) => {
  node.textContent = String(new Date().getFullYear());
});

// Keep section navigation below the chrome, including an expanded mobile menu.
if (header && 'ResizeObserver' in window) {
  const measureChrome = () => {
    const top = innerWidth <= 560 ? 8 : 10;
    document.documentElement.style.setProperty('--chrome-bottom', `${Math.ceil(header.getBoundingClientRect().height + top)}px`);
    document.dispatchEvent(new Event('site-chrome-resize'));
  };
  const chromeSize = new ResizeObserver(measureChrome);
  chromeSize.observe(header);
  measureChrome();
}
document.querySelectorAll('.page-index').forEach(index => {
  const links = [...index.querySelectorAll('a[href^="#"]')];
  const targets = links.map(link => document.getElementById(link.hash.slice(1))).filter(Boolean);
  const select = id => links.forEach(link => {
    if (link.hash === `#${id}`) link.setAttribute('aria-current', 'location');
    else link.removeAttribute('aria-current');
  });
  if (targets.length) select(location.hash.slice(1) || targets[0].id);
  links.forEach(link => link.addEventListener('click', () => select(link.hash.slice(1))));
  // Read every heading at the current chrome boundary. Observer callbacks
  // contain only changed entries and can leave an earlier section stale.
  let frame = null;
  const sync = () => {
    frame = null;
    if (document.hidden || !targets.length) return;
    const boundary = Math.max(header?.getBoundingClientRect().bottom || 0, index.getBoundingClientRect().bottom) + 24;
    const passed = targets.filter(target => target.getBoundingClientRect().top <= boundary);
    select((passed.at(-1) || targets[0]).id);
  };
  const schedule = () => { if (frame === null && !document.hidden) frame = requestAnimationFrame(sync); };
  window.addEventListener('scroll', schedule, {passive:true});
  window.addEventListener('resize', schedule, {passive:true});
  document.addEventListener('site-chrome-resize', schedule);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && frame !== null) { cancelAnimationFrame(frame); frame = null; }
    else schedule();
  });
  schedule();
});

const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const activeMotion = new Map();
const stopMotion = () => {
  activeMotion.forEach(animation => animation.cancel());
  activeMotion.clear();
};

document.addEventListener('site-navigation-start', stopMotion);
function settleIntoView(node, delay = 0) {
  if (reducedMotion.matches || document.hidden || !node.animate || node.contains(document.activeElement)) return;
  const artwork = node.tagName === 'FIGURE';
  const animation = node.animate(
    [{opacity:artwork ? .45 : .75, transform:`translateY(${artwork ? 18 : 12}px)`}, {opacity:1, transform:'none'}],
    {duration:artwork ? 440 : 360, delay, easing:'cubic-bezier(.22,.75,.2,1)', fill:'backwards'}
  );
  trackMotion(node, animation);
}
function trackMotion(node, animation) {
  activeMotion.get(node)?.cancel();
  activeMotion.set(node, animation);
  const clear = () => { if (activeMotion.get(node) === animation) activeMotion.delete(node); };
  animation.finished.then(clear, clear);
}

// No content is hidden in CSS. Observation adds a short, one-time reveal.
// Animate editorial groups, never both a group and its nested children.
if ('IntersectionObserver' in window && !reducedMotion.matches) {
  const selector = '[data-reveal], .section-heading, .section-topline, .split-section, .frontier-row, .detail-row, .principle-row, .research-link-row, .manuscript, .horizon-column, .closing-note, .process-step, .research-themes, main .section h2, .brand-item, .status-copy, .preview-topline';
  const candidates = [...document.querySelectorAll(selector)].filter(node => !node.matches('[data-aero-preview]'));
  const candidateSet = new Set(candidates);
  const pending = new Set(candidates.filter(node => {
    for (let parent = node.parentElement; parent; parent = parent.parentElement) {
      if (candidateSet.has(parent)) return false;
    }
    const bounds = node.getBoundingClientRect();
    // The first viewport is handled by the page transition. Deep links and
    // restored scroll positions stay readable without a second entrance.
    if (bounds.top < innerHeight && bounds.bottom > 0) {
      node.dataset.motionState = 'settled';
      return false;
    }
    node.dataset.motionState = 'pending';
    return true;
  }));
  const reveal = new IntersectionObserver(entries => {
    if (document.hidden || reducedMotion.matches) return;
    const incoming = entries.filter(entry => entry.isIntersecting && pending.has(entry.target));
    incoming.sort((a,b) => a.boundingClientRect.top - b.boundingClientRect.top);
    incoming.forEach((entry,index) => {
      pending.delete(entry.target);
      reveal.unobserve(entry.target);
      entry.target.dataset.motionState = 'revealed';
      settleIntoView(entry.target, Math.min(index * 45, 90));
    });
  }, {threshold:0, rootMargin:'0px 0px -8% 0px'});
  const watchPending = () => pending.forEach(node => reveal.observe(node));
  watchPending();
  document.addEventListener('visibilitychange', () => {
    reveal.disconnect();
    if (!document.hidden && !reducedMotion.matches) watchPending();
  });
  reducedMotion.addEventListener('change', () => {
    if (!reducedMotion.matches) return;
    reveal.disconnect();
    pending.forEach(node => { node.dataset.motionState = 'settled'; });
    pending.clear();
  });
}
if ('IntersectionObserver' in window) {
  const dot = new IntersectionObserver(entries => entries.forEach(entry => entry.target.classList.toggle('is-visible',entry.isIntersecting)),{threshold:.1});
  document.querySelectorAll('.footer-dot').forEach(node => dot.observe(node));
}
document.addEventListener('focusin', event => {
  activeMotion.forEach((animation,node) => {
    if (node.contains(event.target)) animation.cancel();
  });
});
document.addEventListener('visibilitychange', () => {
  document.documentElement.classList.toggle('page-sleeping', document.hidden);
  // Native view transitions handle background visibility. Cancelling them
  // here would also cancel normal cross-document page navigation.
  if (document.hidden) stopMotion();
});
reducedMotion.addEventListener('change', () => {
  if (reducedMotion.matches) {
    stopMotion();
    document.activeViewTransition?.skipTransition();
  }
});
window.addEventListener('pageswap', event => {
  stopMotion();
  if (reducedMotion.matches) event.viewTransition?.skipTransition();
});
window.addEventListener('pagereveal', event => {
  if (reducedMotion.matches) event.viewTransition?.skipTransition();
});

document.querySelectorAll('[data-aero-preview]').forEach(preview => {
  const tabs = [...preview.querySelectorAll('[role="tab"]')];
  const select = (tab,focus=false) => {
    if (!tabs.includes(tab)) return;
    tabs.forEach(item => {
      const active = item === tab;
      item.setAttribute('aria-selected',String(active));item.tabIndex=active?0:-1;
      const panel=document.getElementById(item.getAttribute('aria-controls'));panel.hidden=!active;panel.inert=!active;
      activeMotion.get(panel)?.cancel();
      if(active&&!reducedMotion.matches&&!document.hidden)trackMotion(panel,panel.animate([{opacity:.75,transform:'translateY(6px)'},{opacity:1,transform:'none'}],{duration:220,easing:'ease-out'}));
    });
    if(focus)tab.focus();
  };
  preview.addEventListener('aero-preview-select', event => {
    const next = event.detail?.index;
    if (Number.isInteger(next)) select(tabs[next]);
  });
  preview.querySelectorAll('[data-preview-cite]').forEach(button => {
    button.addEventListener('click', () => {
      preview.querySelectorAll('[data-preview-cite]').forEach(item => {
        const active = item === button;
        item.setAttribute('aria-pressed', String(active));
        const excerpt = preview.querySelector(`#${item.getAttribute('aria-controls')}`);
        if (excerpt) { excerpt.hidden = !active; excerpt.inert = !active; }
      });
      const hint = preview.querySelector('.preview-evidence-hint');
      if (hint) hint.hidden = true;
    });
  });
  tabs.forEach((tab,index) => {
    tab.addEventListener('click',()=>select(tab));
    tab.addEventListener('keydown',event=>{
      let next;
      if(event.key==='ArrowRight')next=(index+1)%tabs.length;
      if(event.key==='ArrowLeft')next=(index+tabs.length-1)%tabs.length;
      if(event.key==='Home')next=0;if(event.key==='End')next=tabs.length-1;
      if(next!==undefined){event.preventDefault();select(tabs[next],true);}
    });
  });
});
