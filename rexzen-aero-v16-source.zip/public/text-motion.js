(() => {
  'use strict';
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const active = new Map();
  const pending = new Set();
  const seen = new WeakSet();
  const segmenter = typeof Intl.Segmenter === 'function' ? new Intl.Segmenter(undefined, {granularity:'grapheme'}) : null;
  let observer;
  let coverObserver;
  let frame;

  function settle(node) {
    const job = active.get(node);
    if (!job) return;
    active.delete(node);
    job.animations.forEach(animation => animation.cancel());
    node.replaceChildren(...job.original);
    if (job.label === null) node.removeAttribute('aria-label');
    else node.setAttribute('aria-label', job.label);
    node.dataset.textState = 'settled';
  }
  function stop() {
    if (frame) cancelAnimationFrame(frame);
    frame = null;
    coverObserver?.disconnect();
    coverObserver = null;
    [...active.keys()].forEach(settle);
    pending.forEach(node => { seen.add(node); node.dataset.textState = 'settled'; });
    pending.clear();
    observer?.disconnect();
  }
  function canReveal(node) {
    return !preference.matches && !document.hidden && !document.documentElement.classList.contains('directory-open') &&
      !document.documentElement.hasAttribute('data-page-motion') && node.isConnected &&
      typeof node.animate === 'function' && !node.contains(document.activeElement);
  }
  function reveal(node) {
    if (seen.has(node)) return;
    seen.add(node);
    pending.delete(node);
    observer?.unobserve(node);
    if (!canReveal(node)) { node.dataset.textState = 'settled'; return; }
    const original = [...node.childNodes];
    const label = node.getAttribute('aria-label');
    const clone = node.cloneNode(true);
    clone.querySelectorAll('br').forEach(br => br.replaceWith(' '));
    const name = clone.textContent.replace(/\s+/g,' ').trim();
    const characterMode = Array.from(name).length <= 48;
    const fragment = document.createDocumentFragment();
    original.forEach(child => fragment.append(child.cloneNode(true)));
    const walker = document.createTreeWalker(fragment, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);
    const pieces = [];
    textNodes.forEach(text => {
      const tokens = characterMode ? (segmenter ? [...segmenter.segment(text.data)].map(x=>x.segment) : Array.from(text.data)) : text.data.split(/(\s+)/);
      const replacement = document.createDocumentFragment();
      tokens.forEach(token => {
        if (!token.trim()) { replacement.append(document.createTextNode(token)); return; }
        const span = document.createElement('span');
        span.textContent = token;
        span.setAttribute('aria-hidden','true');
        span.dataset.textPiece = '';
        replacement.append(span);
        pieces.push(span);
      });
      text.replaceWith(replacement);
    });
    const height = node.getBoundingClientRect().height;
    node.setAttribute('aria-label', label || name);
    node.replaceChildren(fragment);
    node.dataset.textState = 'running';
    const job = {original,label,animations:[]};
    active.set(node,job);
    try {
      // If font shaping changes a line break, use one opacity entrance.
      const stable = Math.abs(node.getBoundingClientRect().height-height) < 1;
      if (!stable || !pieces.length) {
        node.replaceChildren(...original);
        job.animations.push(node.animate([{opacity:.25},{opacity:1}],{duration:420,easing:'ease-out'}));
      } else {
        const step = Math.min(characterMode ? 10 : 30, 210 / Math.max(1,pieces.length-1));
        pieces.forEach((piece,index) => job.animations.push(piece.animate([{opacity:0},{opacity:1}],
          {duration:260,delay:index*step,easing:'cubic-bezier(.2,.65,.3,1)',fill:'backwards'})));
      }
      Promise.allSettled(job.animations.map(animation=>animation.finished)).then(()=>{
        if (active.get(node) === job) settle(node);
      });
    } catch { settle(node); }
  }
  function collect(scope=document, working=false) {
    [...active.keys()].filter(node=>!node.isConnected).forEach(settle);
    pending.forEach(node=>{if(!node.isConnected){observer?.unobserve(node);pending.delete(node);}});
    if(frame){cancelAnimationFrame(frame);frame=null;}
    const nodes = [...scope.querySelectorAll('[data-headline-reveal]')];
    const restored = !working && (location.hash || window.scrollY > 24 || performance.getEntriesByType('navigation')[0]?.type === 'back_forward');
    nodes.forEach(node => {
      if (seen.has(node)) return;
      if (preference.matches || restored || document.hidden || document.documentElement.classList.contains('directory-open')) {
        seen.add(node); node.dataset.textState = 'settled'; return;
      }
      pending.add(node);
    });
    const start = () => {
      coverObserver?.disconnect(); coverObserver=null;
      if (document.documentElement.hasAttribute('data-page-motion')) return;
      frame = requestAnimationFrame(()=>{
        frame=null;
        pending.forEach(node => {
          const box=node.getBoundingClientRect();
          if (box.top < innerHeight*.92 && box.bottom > 0) reveal(node);
          else observer?.observe(node);
        });
      });
    };
    if (document.documentElement.hasAttribute('data-page-motion')) {
      coverObserver?.disconnect();
      coverObserver=new MutationObserver(()=>{
        if (!document.documentElement.hasAttribute('data-page-motion')) start();
      });
      coverObserver.observe(document.documentElement,{attributes:true,attributeFilter:['data-page-motion']});
    } else start();
  }
  if ('IntersectionObserver' in window) observer=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{if(entry.isIntersecting && canReveal(entry.target))reveal(entry.target);});
  },{rootMargin:'0px 0px -8% 0px',threshold:0});
  ['site-navigation-start','site-menu-open','aero-navigation-start'].forEach(event=>document.addEventListener(event,stop));
  document.addEventListener('aero-view-rendered',event=>{if(event.detail?.animateHeadline)collect(document.querySelector('#workspace') || document,true);});
  document.addEventListener('focusin',event=>{
    [...active.keys()].forEach(node=>{if(node.contains(event.target))settle(node);});
  });
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
  preference.addEventListener('change',()=>{if(preference.matches)stop();});
  window.addEventListener('resize',()=>[...active.keys()].forEach(settle),{passive:true});
  window.addEventListener('pagehide',stop);
  window.addEventListener('pageshow',event=>{if(event.persisted)stop();});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',()=>collect(),{once:true});
  else collect();
})();
