import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

try:
    from site_publisher import ASSETS, publish
except ModuleNotFoundError as e:
    if e.name != 'site_publisher':
        raise
    ASSETS = ()
    publish = None


class PublishTests(unittest.TestCase):
    def test_adds_only_new_release_and_two_discovery_entries(self):
        self.assertTrue(callable(publish),'Implement the bounded public release overlay')
        with TemporaryDirectory(dir=Path(__file__).parent) as d:
            root=Path(d)/'site'; src=Path(d)/'release'; src.mkdir(); root.mkdir()
            (root/'research').mkdir(); (root/'research/index.html').write_text('<main><p>Original research</p></main>')
            (root/'sitemap.xml').write_text('<urlset></urlset>')
            (root/'index.html').write_bytes(b'original homepage')
            for n in ASSETS:
                (src/n).write_bytes(b'artifact')
            (src/'index.html').write_text('<a href="demo.html">Demo</a>')
            (src/'technical.html').write_text('<img src="architecture.svg">')
            publish(src,root)
            self.assertEqual((root/'index.html').read_bytes(),b'original homepage')
            self.assertIn('Original research',(root/'research/index.html').read_text(encoding='utf-8'))
            self.assertIn('/research/bci/',(root/'research/index.html').read_text(encoding='utf-8'))
            self.assertIn('https://rexzen.si/research/bci/',(root/'sitemap.xml').read_text(encoding='utf-8'))
            self.assertEqual({p.name for p in (root/'research/bci').iterdir()},set(ASSETS))
            with self.assertRaises(ValueError): publish(src,root)

if __name__=='__main__':unittest.main()
