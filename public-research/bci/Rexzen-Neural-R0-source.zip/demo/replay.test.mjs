import test from 'node:test';
import assert from 'node:assert/strict';
import {initial, step} from './replay.mjs';
const event = (s, type, now, extra={}) => step(s, {type, now, ...extra});

test('an unarmed replay cannot create a proposal; an armed one cannot commit without explicit confirmation', () => {
  let s=initial();
  s=event(s,'evidence',100,{confidence:.93,quality:.90});
  assert.equal(s.phase,'idle');
  s=event(s,'arm',200);
  s=event(s,'evidence',300,{confidence:.93,quality:.90});
  assert.equal(s.phase,'review');
  assert.equal(s.response,'');
  s=event(s,'confirm',400);
  assert.equal(s.phase,'done');
  assert.match(s.response,/starting point|break down/i);
});

test('degraded data invalidates a pending proposal', () => {
  let s=event(initial('robot'),'arm',100);
  s=event(s,'evidence',110,{confidence:.93,quality:.91});
  s=event(s,'evidence',120,{confidence:.96,quality:.31});
  assert.equal(s.phase,'fault');
  assert.equal(event(s,'confirm',130).response,'');
});

test('stale confirmation and reconnection cannot commit', () => {
  let s=event(initial('chess'),'arm',100);
  s=event(s,'evidence',110,{confidence:.93,quality:.91});
  assert.equal(event(s,'confirm',21000).phase,'idle');
  s=event(s,'disconnect',125);
  assert.equal(event(s,'confirm',130).response,'');
  assert.equal(event(s,'evidence',135,{confidence:.93,quality:.91}).phase,'fault');
});

test('changing mode cancels an armed session', () => {
  let s=event(initial('chess'),'arm',100);
  s=event(s,'mode',110,{mode:'robot'});
  assert.equal(s.mode,'robot');
  assert.equal(s.phase,'idle');
});
