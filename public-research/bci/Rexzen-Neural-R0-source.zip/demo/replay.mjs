export const TASKS = {
  question: {
    proposal: 'Break down the trade-offs between a 16-electrode wearable and a 32-electrode lab setup, then suggest the first three experiments we should run.',
    answer: 'A 16-channel liner is the starting point. First, compare dry and wet contact after each refit. Second, test the decoder on a different day. Third, measure false proposals while armed and idle. Add electrodes only if they improve the measured trade-offs.',
  },
  chess: {proposal:'Play e2–e4 in the starting position.',answer:'e2–e4 recorded on the demo board. No engine or external game is connected.'},
  fps: {proposal:'Select the movement practice menu.',answer:'Movement practice selected in the local mock-up. No game client or input events are connected.'},
  robot: {proposal:'Return the simulated robot to dock A.',answer:'Dock A is shown as the simulator destination. No physical robot is connected.'},
};
const TTL=20_000;
export const initial = (mode='question') => ({mode,phase:'idle',until:0,last:0,response:'',message:'Disarmed. Choose a mode and arm one replay.'});
export function step(state,event) {
  const {type,now}=event;
  if (!Number.isFinite(now) || now<state.last) return state;
  const base={...state,last:now};
  const clear=(message,phase='idle')=>({...base,phase,until:0,response:'',message});
  if (type==='mode' && Object.hasOwn(TASKS,event.mode)) return {...initial(event.mode),last:now};
  if (type==='cancel') return clear('Cancelled. Nothing was sent.');
  if (type==='disconnect') return clear('Link lost. Nothing was sent. Arm again to start a fresh replay.', 'fault');
  if (base.until && now>=base.until) return clear('The replay expired. Nothing was sent.');
  if (type==='arm' && !base.until) return {...clear('Armed. Inject sample scores to see what the gate does.', 'armed'),until:now+TTL};
  if (type==='evidence' && (base.phase==='armed' || base.phase==='review')) {
    const ok=[event.quality,event.confidence].every(n=>Number.isFinite(n)&&n>=0&&n<=1) && event.quality>=.8 && event.confidence>=.85;
    if (!ok) return clear('Scores failed the gate. No proposal was kept.', 'fault');
    if (base.phase==='armed') return {...base,phase:'review',message:'Proposal only. Verify the text, then explicitly confirm or cancel.'};
  }
  if (type==='confirm' && base.phase==='review') return {...clear('Confirmed locally. Nothing was sent to hardware or to a cloud model.', 'done'),response:TASKS[base.mode].answer};
  return base;
}
