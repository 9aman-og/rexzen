# Rexzen Neural / R0 research release

This is a non-invasive EEG **concept**, one offline analysis on public research data, and a browser demo with scripted inputs. This package contains no working wearable, clinical claims, trained production decoder, live cloud integration, raw participant EEG, PCB fabrication files or ready-to-mold CAD. Do not connect any unverified electronics to a person. Do not use for driving, continuous game control, or physical robot control.

- `Rexzen-Neural-R0.md` / `technical-draft.md`: editable technical document and render inputs. `architecture.svg`, `electrodes.svg`, `wearable.svg`: SVG source figures; first two are generated, latter is hand-drawn.
- `electrodes.csv`, `bom.csv`: physical channel wiring allocations and early cost/mass model, not released manufacturing data.
- `repro/`: benchmark source, tests and aggregate/per-participant balanced-accuracy summaries. Raw data is fetched directly from PhysioNet and excluded from this archive. `repro/results/benchmark.json` carries the hash and retained trial count of all source files. See PhysioNet's ODC Attribution v1.0 terms and the attribution below. Only public participant numbers (not real names), retained trial counts, and scores are exposed.
- `demo/`: interaction prototype source and test. It does not use raw EEG, a live model, an API key, real sound routing controls, or a robot/game connection. Browser audio is optional and uses an available on-device voice only; check where device audio is routed.
- `reference-ledger.json`: publisher links and matched small evidence excerpts. Code, data, and third-party checkpoints have separate terms; no third-party weights or data are redistributed. No license is granted here for hardware manufacture, third-party data, or trademarks.
- `build_release.py`, `build_investor.py`: regenerate the static pages, charts, and presentation. Print `release/technical.html` from a Chromium browser for PDF. `release/demo.html` works without a server when opened directly. `release/index.html` expects the standard assets to be served under `/research/bci/` in the Rexzen website.

## Reproduce the public-data benchmark

1. Install Python 3.11+ and NumPy (the tested NumPy version is in the JSON output). No PyTorch, MNE, or trained weights are required for this experiment.
2. In `repro/`, run `python -m unittest -v`. Run `python benchmark.py --cache ./edf-cache --out ./recheck` for the fixed S001–S016 sample. The run fetches 48 small EDF+ files; the local EDF cache is not a public asset. `--subjects 1` is a fetch smoke test, not the substantive experiment.
3. Compare JSON counts and file hashes; floating-point values may minimally differ across libraries/architectures. To test the browser state logic locally use `node --test demo/replay.test.mjs`. To rebuild the report HTML and release page, install `markdown-it-py` and run `python build_release.py`. For the editable investor deck, install `python-pptx` and run `python build_investor.py` after `build_release.py` (concept PNG can be provided to the build with `--rendered-figure`).

The participant-level experiment is retrospective on a convenience sample and same-visit runs; no cross-day, idle, online, wet-vs-dry, or speech claim follows. Verdict: **partial** — the channel sets and simple classifiers can be compared in the public-data protocol. Live wearable usefulness is unproven.

### Data attribution

Goldberger AL et al., *PhysioBank, PhysioToolkit, and PhysioNet: Components of a New Research Resource for Complex Physiologic Signals*, Circulation (2000); the data release separately credits the developers of the BCI2000 instrumentation system. Source: [EEG Motor Movement/Imagery Dataset v1.0.0](https://physionet.org/content/eegmmidb/1.0.0/), DOI [10.13026/C28G6P](https://doi.org/10.13026/C28G6P). If redistributing data or derived materials, review the applicable license and attribution requirements independently.
