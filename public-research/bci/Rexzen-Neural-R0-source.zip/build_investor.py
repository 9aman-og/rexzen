from __future__ import annotations

import argparse
import json
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

ROOT=Path(__file__).resolve().parent
INK='192622'; PAPER='F3F5F0'; LIGHT='F8FAF6'; RULE='C0CEC5'; MUTE='40564D'; GREEN='155B43'; MINT='A8DDBB'; NIGHT='173329'; DIM='D5E6DA'


def rgb(h): return RGBColor.from_string(h)
def box(s,x,y,w,h,c,line=None):
    sh=s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x),Inches(y),Inches(w),Inches(h));sh.fill.solid();sh.fill.fore_color.rgb=rgb(c)
    if line:sh.line.color.rgb=rgb(line)
    else:sh.line.fill.background()
    return sh

def text(s,content,x,y,w,h,size=18,c=INK,bold=False,font='Aptos', url=None):
    sh=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h)); f=sh.text_frame;f.clear();f.word_wrap=True;f.vertical_anchor=MSO_ANCHOR.TOP
    f.margin_left=f.margin_right=f.margin_top=f.margin_bottom=0
    for i,line in enumerate(content.split('\n')):
        p=f.paragraphs[0] if i==0 else f.add_paragraph(); p.space_before=Pt(0);p.space_after=Pt(0);p.line_spacing=1.11
        r=p.add_run();r.text=line;r.font.name=font;r.font.size=Pt(size);r.font.bold=bold
        if url: r.hyperlink.address=url
        r.font.color.rgb=rgb(c)
    return sh


def new(pr, n, label, title=None, subtitle=None, dark=False):
    s=pr.slides.add_slide(pr.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=rgb(NIGHT if dark else PAPER)
    fg=LIGHT if dark else INK; muted=DIM if dark else MUTE; accent=MINT if dark else GREEN
    text(s,f'REXZEN / RESEARCH     ·     {label.upper()}',.65,.37,11,.3,11,accent,True,'Consolas')
    box(s,.65,7.02,12.0,.012,'637F71' if dark else RULE)
    text(s,'NEURAL R0   ·   NOVEMBER 2026   ·   RESEARCH CONCEPT',.65,7.12,10,.24,10,muted,True,'Consolas')
    text(s,f'{n:02d}',12.04,7.12,.55,.24,10,muted,True,'Consolas')
    if title:text(s,title,.65,.89,12.0,1.03,37,fg,True)
    if subtitle:text(s,subtitle,.68,1.99,11.85,.64,16,muted)
    return s


def columns(s, items, y=3.05):
    widths=11.96/len(items)
    for i,(num,title,body) in enumerate(items):
        x=.69+widths*i
        box(s,x,y,widths-.25,.018,RULE)
        text(s,num,x,y+.13,widths-.3,.28,11,GREEN,True,'Consolas')
        text(s,title,x,y+.58,widths-.35,.65,23,INK,True)
        text(s,body,x,y+1.45,widths-.45,1.85,17,MUTE)


def build(figure):
    out=ROOT/'release';out.mkdir(exist_ok=True)
    refs={v['id']:v for v in json.loads((out/'evidence.json').read_text(encoding='utf-8'))}
    data=json.loads((out/'benchmark.json').read_text(encoding='utf-8'))
    pr=Presentation();pr.slide_width=Inches(13.3333);pr.slide_height=Inches(7.5)
    pr.core_properties.title='Rexzen Neural R0 | Investor briefing';pr.core_properties.author='Rexzen Research';pr.core_properties.subject='Research concept; not working hardware';pr.core_properties.keywords='EEG, wearable, feasibility, Rexzen'
    s=new(pr,1,'Concept',dark=True)
    text(s,'Rexzen\nNeural.',.65,1.14,6.1,2.1,62,LIGHT,True)
    text(s,'A discreet EEG liner for deliberate selections, not passive thought reading.',.69,4.0,5.6,1.38,25,DIM)
    text(s,'16 scalp channels proposed  /  32 for lab work',.69,6.27,6.35,.42,12,MINT,True,'Consolas')
    if figure and figure.is_file():s.shapes.add_picture(str(figure),Inches(6.37),Inches(1.69),width=Inches(6.26))
    else:text(s,'16 + 16\nDAILY / LAB',6.65,2.23,5.4,1.9,42,MINT,True)
    s=new(pr,2,'The problem','Good EEG starts before the ADC.','The product thesis is reliable useful coverage, not electrode count or a bigger language model.')
    columns(s,[('01 / FIT','Wear it naturally','Ordinary cap outside. Replaceable, size-indexed sensing liner inside. Separate earbuds.'),('02 / SIGNAL','Reject bad data','Check reference, motion and regional coverage. Show what needs reseating; refuse to guess.'),('03 / CONTROL','Keep the user in charge','A deliberate arm–review–confirm sequence. No background decoding or automatic action.')])
    s=new(pr,3,'Evidence','Different signal, different claim.','The studies below use different tasks and metrics. This is not a leaderboard.')
    columns(s,[('IMPLANTED [8][9][31]','62–78 words/min','Attempted speech in individual studies using implanted sensors. No parity claim.'),('NONINVASIVE [10][19]','29% / 65% CER','Brain2Qwerty MEG vs EEG while volunteers typed real keys. fMRI semantics are another different task.'),('REXZEN R0 [1]','Cued intent only','Public-data analysis of left vs right motor imagery. No wearable, no live speech and no async control evidence.')])
    s=new(pr,4,'Measured / offline','The 16-site subset led this replay.','16 people · 48 recordings · 720 cued trials · held-out runs within person · PhysioNet [1].')
    targets=[('8 central', 'central_8_cov'),('16 Day', 'day_16_cov'),('32 Lab', 'lab_32_cov'),('16 shuffled', 'day_16_cov_shuffled')]
    x0=3.05; bar=6.5
    for i,(title,k) in enumerate(targets):
        y=3.0+i*.64;m=data['metrics'][k];v=m['mean'];lo,hi=m['ci95']
        text(s,title,.7,y,2.22,.38,17,INK,i==1)
        box(s,x0,y+.1,bar,.15,'D6E1DA');box(s,x0,y+.1,bar*v,.15,GREEN if i==1 else '668779')
        text(s,f'{v:.1%} ({lo:.1%}–{hi:.1%})',9.78,y,2.8,.41,14,MUTE,i==1)
    box(s,x0+bar*.5,2.91,.015,2.42,'465F52')
    text(s,'Same-visit lab data. 95% participant-bootstrap intervals. The vertical marker shows 50% theoretical chance.',.7,5.89,11.92,.58,15,MUTE)
    s=new(pr,5,'Hardware','Two liners. One signal chain.','Keep the 16-site product provisional until dry fit, comfort and cross-day transfer are measured.')
    columns(s,[('MECHANICAL','16 daily + 16 lab','Indexed hair cartridges, separate REF and body bias, removable nape board. No integrated headset audio.'),('ELECTRONICS [2]','Sync first','Simultaneous conversion, common timebase, source counters, battery-powered acquisition, off-head charging.'),('VALIDATION','Manufacture after gates','Fit and leakage reviews, wet–dry comparison, multi-day repeats, DFM, production test and supplier quotes.')])
    s=new(pr,6,'Software','Use the right model for each job.','A strong baseline earns its place. A generative model does not get authority over the device.')
    columns(s,[('NEURAL MODEL [15]','Score or abstain','Causal DSP, data quality mask, fast covariance baseline, then small channel-aware neural model if it wins on locked data.'),('APP POLICY','Authorize','Arm, review, confirm. Reject stale inputs or low quality. Manual fallback and undo.'),('LANGUAGE [5]','Respond privately','Earphone reply is a product goal. Optional GPT receives approved text only, never EEG. No actuator permissions.')])
    s=new(pr,7,'Experience','Propose the next step.','Four staged demos; only scripted inputs run today.')
    columns(s,[('01','Ask in earphones','Compose via confirmed slots or text. Preview, confirm, hear a reply.'),('02','Chess','Pick a legal move in the app. Never use it to get an unfair advantage.'),('03','FPS','Local menu exploration, not aiming, firing, or VALORANT input integration [28].'),('04','Robot','Simulator only. Future work: high-level safe goals with independent stops.')])
    s=new(pr,8,'Novelty hypothesis','Prove that fit and abstention work together.','Dry contacts and impedance-assisted fit already exist. Patent claim and freedom to operate are not established. [3][4][6][7]')
    columns(s,[('A/B 01','Fit guidance','Compare fixed fit to recommendations derived from recurring poor-contact patterns.'),('A/B 02','Mask the model','Compare fixed channels to quality-aware weighting at equal false activation.'),('A/B 03','Measure utility','Collect real-world setup times, correct actions, abstentions, wear comfort and repeatability.')])
    s=new(pr,9,'Milestones','Fund evidence, not a launch promise.','Planning scenario only. No manufacturing quotes, sales, commitments, or investor solicitation.')
    columns(s,[('G0 / BENCH','Safety and fit','$270k hardware and DFM. Prototype only on fixtures until safety and study approval.'),('G1 / LEARN','Repeatable signal','$225k app and signal. Paired dry/wet, different days and clear artifacts controls.'),('G2 / FIELD','Utility vs a switch','$135k research and safety/privacy; $120k reserve and operations. If utility fails, narrow the product.')])
    s=new(pr,10,'Sources','Evidence and reproducibility','Select a title to open the source. The technical report links the full citation list, code and trial manifest.')
    for i, idx in enumerate([1,2,5,6,7,8,9,10,15,19,28,31,3,4]):
        x=.7+(i%2)*6.06;y=2.88+(i//2)*.45
        d=refs[idx]; title=d['title'];title=title if len(title)<=68 else title[:65]+'…'
        text(s,f'[{idx}] {title}',x,y,5.83,.4,13,GREEN,False,url=d['url'])
    text(s,'rexzen.si/research/bci/',.7,6.36,6,.45,17,GREEN,True,url='https://rexzen.si/research/bci/')
    dst=out/'Rexzen-Neural-Investor.pptx';pr.save(dst)
    reopened=Presentation(dst)
    assert len(reopened.slides)==10
    for sl in reopened.slides:
        for sh in sl.shapes:
            assert sh.left>=0 and sh.top>=0 and sh.left+sh.width<=reopened.slide_width and sh.top+sh.height<reopened.slide_height,sh.name
    print('PowerPoint: 10 slides parsed; all shape bounds valid')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rendered-figure',type=Path);build(p.parse_args().rendered_figure)
