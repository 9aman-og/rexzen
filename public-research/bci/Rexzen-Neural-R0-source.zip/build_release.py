from __future__ import annotations

import argparse
import csv
from html import escape
import json
from pathlib import Path
import re
import shutil

from markdown_it import MarkdownIt

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'release'
SVGNS = 'http://www.w3.org/2000/svg'
INK, MINT, PAPER, MUTED = '#192622', '#a8ddbc', '#f3f5f0', '#435750'


def file(name, text):
    (OUT / name).write_text(text, encoding='utf-8', newline='\n')


def pct(n):
    return f'{n:.1%}'


def montage_svg(rows):
    coords = {
        'FP1':(255,67),'FP2':(385,67),'AF7':(202,94),'AF8':(438,94),
        'F7':(161,139),'F3':(238,131),'F4':(402,131),'F8':(479,139),
        'FC3':(229,174),'FC1':(292,174),'FC2':(348,174),'FC4':(411,174),
        'T7':(143,218),'C3':(229,218),'C1':(274,218),'CZ':(320,218),'C2':(366,218),'C4':(411,218),'T8':(497,218),
        'CP3':(228,262),'CPZ':(320,262),'CP4':(412,262),
        'P3':(238,306),'PZ':(320,306),'P4':(402,306),
        'PO7':(194,344),'PO3':(266,344),'PO4':(374,344),'PO8':(446,344),
        'O1':(260,386),'OZ':(320,386),'O2':(380,386),'M1':(100,276),'M2':(540,276),
    }
    plotted = {r['site'].upper() for r in rows if r['variant'] != 'LAB_AUX'}
    assert plotted == coords.keys()
    markers = []
    for r in rows:
        if r['variant']=='LAB_AUX': continue
        label=r['site']; x,y=coords[label.upper()]; variant=r['variant']
        fill,stroke = {'DAY':('#175940','#0d432f'),'LAB':('#f3f5f0','#748679'),'SHARED':('#a86a34','#885221')}[variant]
        markers.append(f'<circle cx="{x}" cy="{y}" r="8" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/><text x="{x}" y="{y-13}" text-anchor="middle" fill="{INK}" font-size="13" font-weight="700">{label}</text>')
    return f'''<svg xmlns="{SVGNS}" width="640" height="450" viewBox="0 0 640 450" role="img" aria-labelledby="mtitle mdesc">
<title id="mtitle">Rexzen 10–10 conceptual scalp montage</title><desc id="mdesc">Sixteen filled Day sites, sixteen hollow Lab extension sites and two common mastoid contacts. Nasion is at top; left is left.</desc>
<rect width="640" height="450" rx="9" fill="{PAPER}" stroke="#bacbc0"/>
<g fill="none" stroke="#87998f" stroke-width="1.6"><ellipse cx="320" cy="224" rx="183" ry="181"/><path d="M300 44l20-19 20 19 M137 192q-27-1-25 27t25 33 M503 192q27-1 25 27t-25 33"/></g>
<path d="M320 58v337M155 218h330" stroke="#9baaa1" stroke-width="1" stroke-dasharray="3 6"/>
<g font-family="Segoe UI,Arial,sans-serif">{''.join(markers)}
<g fill="{MUTED}" font-size="12"><text x="19" y="32">LEFT</text><text x="584" y="32">RIGHT</text><text x="99" y="302" text-anchor="middle">REF</text><text x="540" y="302" text-anchor="middle">BIAS</text><text x="320" y="18" text-anchor="middle">NASION / FRONT</text></g>
<g font-size="13" fill="{INK}"><circle cx="102" cy="427" r="7" fill="#175940"/><text x="115" y="432">16 Day sites</text><circle cx="262" cy="427" r="7" fill="{PAPER}" stroke="#748679"/><text x="275" y="432">16 Lab additions</text><circle cx="461" cy="427" r="7" fill="#a86a34"/><text x="474" y="432">Shared; not EEG</text></g></g></svg>'''


def architecture_svg():
    boxes=[(18,55,175,60,'Receive only','EEG • REF • BIAS','#22d3ee'),(210,55,168,60,'Synchronized AFE','Bank A/B (+ lab)','#34d399'),(395,55,179,60,'Firmware','Clock • health • BLE','#fbbf24'),(18,165,175,66,'Phone decoder','Causal DSP • abstain','#c084fc'),(210,165,168,66,'Phone policy','Show • confirm • expire','#fb7185'),(395,165,179,66,'Allowed response','Local tools • earphones','#22d3ee'),(204,275,180,58,'Optional GPT','Approved text only','#fbbf24')]
    edges=[('M193 85H206','#86bcc0',''),('M378 85H391','#86bcc0',''),('M485 115v23H106v23','#86bcc0',''),('M193 198H206','#86bcc0',''),('M378 198H391','#86bcc0',''),('M291 231v40','#fb7185','stroke-dasharray="5 4"'),('M384 304h101v-69','#fb7185','stroke-dasharray="5 4"')]
    parts=[''.join(f'<path d="{d}" stroke="{c}" stroke-width="1.5" fill="none" marker-end="url(#a)" {extra}/>' for d,c,extra in edges)]
    for x,y,w,h,t,l,c in boxes:
        parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" fill="#172633" stroke="{c}"/><text x="{x+12}" y="{y+25}" fill="#f2f7f3" font-size="14" font-weight="700">{t}</text><text x="{x+12}" y="{y+45}" fill="#c4d4df" font-size="11">{l}</text>')
    return f'''<svg xmlns="{SVGNS}" viewBox="0 0 592 377" width="592" height="377" role="img" aria-labelledby="atitle arrdesc"><title id="atitle">Rexzen sensing, inference and authorization topology</title><desc id="arrdesc">The sensor reaches isolated acquisition, then the phone. Only user-confirmed text can flow to an optional model. No GPT command can directly actuate a device.</desc>
<defs><pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0V20" fill="none" stroke="#26475a" stroke-width=".45"/></pattern><marker id="a" markerWidth="7" markerHeight="6" refX="6" refY="3" orient="auto"><path d="M0 0l7 3-7 3Z" fill="#d3e2e0"/></marker></defs>
<rect width="592" height="377" rx="8" fill="#11222d"/><rect width="592" height="377" rx="8" fill="url(#grid)"/><g font-family="Segoe UI,Arial,sans-serif"><text x="18" y="31" fill="#b8e5cc" font-size="13" font-weight="700" letter-spacing="1.2">RXN / 03   SIGNAL AND CONTROL</text>{''.join(parts)}<path d="M22 354h20" stroke="#86bcc0"/><text x="49" y="358" fill="#bcd0dc" font-size="11">Device/phone</text><path d="M161 354h20" stroke="#fb7185" stroke-dasharray="5 4"/><text x="188" y="358" fill="#bcd0dc" font-size="11">Optional text path, no actuation permission</text></g></svg>'''


def html_doc(body):
    return '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rexzen Neural R0 | Technical design</title>
<link rel="canonical" href="https://rexzen.si/research/bci/technical.html"><style>
:root{--ink:#192622;--muted:#435750;--accent:#145940;--line:#bdcbc2; font:16px/1.59 'Segoe UI',Arial,sans-serif;color-scheme:light}*{box-sizing:border-box}body{margin:0;color:var(--ink);background:#f3f5f0}article{max-width:1020px;margin:auto;background:#fbfcf8;padding:36px 42px 70px}a{color:var(--accent);text-underline-offset:3px}.top{padding:0 0 14px;border-bottom:1px solid var(--line);font:700 .8rem Consolas,monospace;text-transform:uppercase;letter-spacing:.1em}h1{font-size:clamp(2.8rem,7vw,5.2rem);line-height:1;letter-spacing:-.07em;margin:28px 0 16px}h2{font-size:1.8rem;letter-spacing:-.04em;line-height:1.15;margin:40px 0 14px;border-top:1px solid var(--line);padding-top:16px}p,li{overflow-wrap:anywhere}h2,h3{break-after:avoid}p{margin:.7em 0}li{margin:.4em 0}figure{margin:1.2em 0}figure img{width:min(100%,680px);display:block;height:auto}figcaption{font-size:.84rem;color:var(--muted);margin-top:5px}table{width:100%;border-collapse:collapse;font-size:.91rem;margin:14px 0 19px;table-layout:auto}th,td{text-align:left;vertical-align:top;padding:8px 10px;border:1px solid var(--line);overflow-wrap:anywhere}th{background:#e0ebe3}tbody tr:nth-child(even){background:#f3f6f1}thead{display:table-header-group}code{font:.88em Consolas,monospace}nav a{display:inline-block;margin:0 .28em .3em 0}tr,figure{break-inside:avoid}.connected{color:#145940}@media(max-width:650px){article{padding:22px 15px 36px}table{font-size:.82rem}th,td{padding:5px}}
@page{size:A4;margin:13mm 13mm 16mm}@media print{*{-webkit-print-color-adjust:exact;print-color-adjust:exact}body,article{background:white}article{max-width:none;margin:0;padding:0}body{font:11.25pt/1.42 Arial,sans-serif}h1{font-size:45pt}h2{font-size:20pt;margin-top:24px}p,li{orphans:2;widows:2}table{font-size:9.7pt}figure img{max-height:95mm;object-fit:contain;object-position:left}a{text-decoration:none}}
</style></head><body><article><nav class="top" aria-label="Breadcrumb"><a href="https://rexzen.si/research/bci/">Rexzen Research / Neural R0</a></nav>'''+body+'''</article></body></html>'''


def convert(md, ids):
    cleaned = re.sub(r'^## (02 / What the offline experiment actually says)$', r'\n<span id="offline-experiment"></span>\n\n## \1', md, flags=re.M)
    # Convert headings and ordinary Markdown first, then link citation markers only in the body.
    part, _, refs = cleaned.partition('\n## Sources\n')
    markdown = MarkdownIt('commonmark', {'html':True}).enable(['table','strikethrough'])
    body = markdown.render(part)
    body = re.sub(r'<p>(<img[^>]+>)</p>', r'<figure>\1</figure>', body)
    body = re.sub(r'\[(\d+)\]', lambda m:f'<sup><a href="#src-{m[1]}">[{m[1]}]</a></sup>' if int(m[1]) in ids else m[0],body)
    src = '<h2 id="sources">Sources</h2><ul>'+''.join(f'<li id="src-{i}">[{i}] <a href="{escape(d["url"], quote=True)}">{escape(d["title"])}</a></li>' for i,d in ids.items())+'</ul>'
    return html_doc(body+src)


def render():
    b=json.loads((ROOT/'repro/results/benchmark.json').read_text(encoding='utf-8'))
    sources=json.loads((ROOT/'reference-ledger.json').read_text(encoding='utf-8'))
    md=(ROOT/'technical-draft.md').read_text(encoding='utf-8')
    cited={int(n) for n in re.findall(r'\[(\d+)\]',md)}
    ids={d['id']:d for d in sources if d['id'] in cited}
    assert cited == ids.keys() and all(d.get('quotes') for d in ids.values())
    OUT.mkdir(exist_ok=True)
    with (ROOT/'electrodes.csv').open(encoding='utf-8') as f: ele=list(csv.DictReader(f))
    assert [sum(row['variant']==setname for row in ele) for setname in ['DAY','LAB','SHARED','LAB_AUX']]==[16,16,2,4]
    assert [r['site'].upper() for r in ele if r['variant']=='DAY']==b['montage']['day_16']
    assert [r['site'].upper() for r in ele if r['variant'] in {'DAY','LAB'}]==b['montage']['lab_32']
    file('electrodes.svg',montage_svg(ele)); file('architecture.svg',architecture_svg()); shutil.copyfile(ROOT/'wearable.svg',OUT/'wearable.svg')
    names=[('Central 8','central_8'),('DAY 16','day_16'),('LAB 32','lab_32'),('Frontal 4, control','frontal_4_control')]
    r={k:f'{pct(m["mean"])} ({pct(m["ci95"][0])}–{pct(m["ci95"][1])})' for k,m in b['metrics'].items()}
    delta=b['lab_minus_day_cov']
    ppoint=lambda x:f'{x*100:+.1f} pp'
    bench=f"**Measured:** {b['participants']} participants · {len(b['file_manifest'])} EDF+ recordings · {b['unique_trials']} unique trials. Accuracy (95% participant bootstrap interval):\n\n| Montage subset | Log-bandpower | Log-covariance |\n|---|---:|---:|\n"
    bench+='\n'.join(f'| {title} | {r[key+"_power"]} | {r[key+"_cov"]} |' for title,key in names)
    bench+=f"\n| DAY 16, shuffled training labels | — | {r['day_16_cov_shuffled']} |\n\nPaired LAB 32 minus DAY 16 covariance: **{ppoint(delta['mean'])}** ({ppoint(delta['ci95'][0])} to {ppoint(delta['ci95'][1])}). This is not a statistical comparison of electrode hardware."
    with (ROOT/'bom.csv').open(encoding='utf-8') as f: bom=list(csv.DictReader(f))
    low,high,mass=(sum(int(a[k]) for a in bom) for k in ['extended_usd_low','extended_usd_high','extended_mass_g_target'])
    md=md.replace('@@BENCH@@',bench).replace('@@TOPOLOGY@@','![10–10 top view: 16 Day sites, 16 Lab additions, separate REF and BIAS](electrodes.svg)').replace('@@ARCHITECTURE@@','![Signal and authorization: receive only, phone decoder, phone policy, optional approved-text GPT](architecture.svg)')
    md=md.replace('`bom.csv` carries assumed ranges;',f'`bom.csv` models ${low}–${high} per assembled unit plus excluded landed/support costs, and {mass} g nominal worn mass before margin;')
    md+='\n\n## Sources\n\n'+'\n'.join(f'[{i}] {d["url"]} — {d["title"]}' for i,d in ids.items())+'\n'
    (ROOT/'Rexzen-Neural-R0.md').write_text(md,encoding='utf-8',newline='\n')
    file('technical.html',convert(md,ids)); shutil.copyfile(ROOT/'repro/results/benchmark.json',OUT/'benchmark.json')
    file('evidence.json',json.dumps(list(ids.values()),ensure_ascii=False,indent=2)+'\n')
    metrics=''.join(f'<tr><th scope="row">{title}</th><td>{pct(b["metrics"][key]["mean"])}</td></tr>' for title,key in [('Proposed DAY 16 · covariance','day_16_cov'),('Central 8 · covariance','central_8_cov'),('LAB 32 · covariance','lab_32_cov'),('DAY 16 · shuffled labels','day_16_cov_shuffled')])
    file('index.html',(ROOT/'landing-template.html').read_text(encoding='utf-8').replace('@@METRIC_ROWS@@',metrics))
    core=re.sub(r'^export ', '',(ROOT/'demo/replay.mjs').read_text(encoding='utf-8'),flags=re.M)
    file('demo.html',(ROOT/'demo/demo-template.html').read_text(encoding='utf-8').replace('@@REPLAY@@',core))
    print(f'Design HTML generated with {len(ids)} evidence-backed sources, ${low}–${high} unit estimate, {mass} g mass budget')

if __name__=='__main__': render()
