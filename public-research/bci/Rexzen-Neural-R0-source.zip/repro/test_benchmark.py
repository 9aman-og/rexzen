import unittest

import numpy as np

try:
    from benchmark import run_splits, balanced
except ModuleNotFoundError as exc:
    if exc.name != 'benchmark':
        raise
    run_splits = balanced = None


class BenchmarkProtocol(unittest.TestCase):
    def test_run_folds_use_every_trial_once_and_never_leak_group(self):
        self.assertTrue(callable(run_splits), 'Implement leave-one-run-out first')
        groups = np.array([4, 4, 8, 8, 12, 12])
        tests = []
        for run, train, test in run_splits(groups):
            self.assertTrue(np.all(groups[test] == run))
            self.assertTrue(np.all(groups[train] != run))
            self.assertEqual(len(train) + len(test), len(groups))
            tests.extend(test)
        self.assertEqual(sorted(tests), list(range(len(groups))))

    def test_class_balanced_accuracy_is_not_the_majority_accuracy(self):
        self.assertTrue(callable(balanced), 'Implement recall per class first')
        self.assertEqual(balanced(np.array([0, 0, 0, 1]), np.array([0, 0, 0, 0])), .5)


if __name__ == '__main__':
    unittest.main()
