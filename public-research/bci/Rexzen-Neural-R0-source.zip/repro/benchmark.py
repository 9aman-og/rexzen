"""Offline, fixed-window feasibility spike. This is not the wearable or online control."""
from __future__ import annotations

import argparse
import csv
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import urllib.request

import numpy as np

RUNS = (4, 8, 12)
FS = 160
URL = 'https://physionet.org/files/eegmmidb/1.0.0/'
CENTRAL = 'FC3 FC4 C3 C1 CZ C2 C4 CP3 CP4 CPZ FCZ C5 C6 CP1 CP2 FC1 FC2 CP5 CP6'.split()
# The 16-site map, ignoring the actual hardware's reference, wiring and contact characteristics.
DAY = 'AF7 AF8 F3 F4 FC3 FC4 C3 CZ C4 CP3 CP4 PZ PO3 PO4 O1 O2'.split()
LAB = DAY + 'FP1 FP2 F7 F8 FC1 FC2 C1 C2 T7 T8 CPZ P3 P4 PO7 PO8 OZ'.split()
SETS = {
    'central_8': 'FC3 FC4 C3 CZ C4 CP3 CP4 CPZ'.split(),
    'day_16': DAY,
    'lab_32': LAB,
    'frontal_4_control': 'FP1 FP2 AF7 AF8'.split(),
}
BANDS = ((8, 12), (13, 20), (20, 30))
TAL = re.compile(rb'([+-][\d.]+)(?:\x15([\d.]+))?\x14(T[12])\x14')


def run_splits(groups):
    for r in np.unique(groups):
        yield int(r), np.flatnonzero(groups != r), np.flatnonzero(groups == r)


def balanced(y, predictions):
    labels = np.unique(y)
    if len(labels) != 2:
        raise ValueError('both imagery classes required')
    return float(np.mean([np.mean(predictions[y == label] == label) for label in labels]))


def fetch(cache, sid, run):
    subject = f'S{sid:03d}'
    fname = f'{subject}R{run:02d}.edf'
    path = cache / fname
    if not path.exists():
        url = URL + subject + '/' + fname
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url, timeout=35) as res:
                    data = res.read()
                if len(data) < 100000 or b'EDF+C' not in data[:256]:
                    raise ValueError('missing expected EDF+C header for ' + fname)
                tmp = path.with_suffix('.download')
                tmp.write_bytes(data)
                tmp.replace(path)
                break
            except (OSError, ValueError):
                if attempt == 2:
                    raise
    return path


def epochs(path):
    """Strict reader for the uniform 64-scalp-channel EDF+ subset, not general EDF."""
    blob = path.read_bytes()
    n = int(blob[252:256]); h = int(blob[184:192]); nrec = int(blob[236:244])
    rec_seconds = float(blob[244:252])
    fields = []
    pos = 256
    for step in (16, 80, 8, 8, 8, 8, 8, 80, 8, 32):
        fields.append([blob[pos+i*step:pos+(i+1)*step].decode('ascii').strip() for i in range(n)])
        pos += step*n
    labels = [x.rstrip('.').upper() for x in fields[0]]
    counts = [int(x) for x in fields[8]]
    if n != 65 or h != pos or nrec <= 0 or rec_seconds != 1 or counts[:-1] != [FS]*64 or labels[-1] != 'EDF ANNOTATIONS':
        raise ValueError(f'unsupported EDF layout: {path.name}')
    if len(blob) != h + 2*nrec*sum(counts):
        raise ValueError(f'truncated or extended record: {path.name}')
    d = np.frombuffer(blob, dtype='<i2', offset=h).reshape(nrec, sum(counts))
    scalp = d[:, :64*FS].reshape(nrec, 64, FS).transpose(1, 0, 2).reshape(64, -1).astype(float)
    pmin, pmax, dmin, dmax = (np.array([float(x) for x in f[:-1]]) for f in fields[3:7])
    scalp = (scalp-dmin[:, None])*((pmax-pmin)/(dmax-dmin))[:, None] + pmin[:, None]
    ann = d[:, 64*FS:]
    trials, classes = [], []
    for r in ann:
        for m in TAL.finditer(r.astype('<i2',copy=False).tobytes()):
            if not m[2] or float(m[2]) < 3.5:
                continue
            t = float(m[1]); a = round(FS*(t+.5)); b = round(FS*(t+3.5))
            if 0 <= a < b <= scalp.shape[1]:
                trials.append(scalp[:, a:b]); classes.append(int(m[3][-1:])-1)
    if set(classes) != {0, 1}:
        raise ValueError(f'expected both classes: {path.name}')
    return np.stack(trials), np.array(classes), labels[:-1], hashlib.sha256(blob).hexdigest()


def feature_matrices(x):
    x = (x-x.mean(-1, keepdims=True))*np.hanning(x.shape[-1])
    spec = np.fft.rfft(x, axis=-1)
    hz = np.fft.rfftfreq(x.shape[-1], 1/FS)
    pooled = np.zeros((len(x), x.shape[1], x.shape[1]))
    power = []
    for low, high in BANDS:
        keep = (hz >= low) & (hz < high)
        y = np.fft.irfft(spec*keep, n=x.shape[-1], axis=-1)
        cov = y @ y.transpose(0, 2, 1) / y.shape[-1]
        diag = np.diagonal(cov, axis1=-2, axis2=-1)
        power.append(np.log(np.maximum(diag, 1e-16)))
        scale = np.maximum(diag.sum(-1), 1e-16)
        p = x.shape[1]
        shrunk = .8*(cov / scale[:, None, None]) + .2*np.eye(p)/p
        vals, vec = np.linalg.eigh(shrunk)
        pooled += (vec*np.log(np.maximum(vals, 1e-16))[:, None, :]) @ vec.transpose(0, 2, 1)
    return np.concatenate(power, axis=-1), pooled/len(BANDS)


def predict(features, group, y, shuffled=False, seed=0):
    out = np.full(len(y), -1, dtype=int)
    rng = np.random.default_rng(seed)
    for _, train, test in run_splits(group):
        ztrain = y[train].copy()
        if shuffled:
            gtrain = group[train]
            for r in np.unique(gtrain):
                m = gtrain == r
                ztrain[m] = rng.permutation(ztrain[m])
        f = features.copy().reshape(len(y), -1)
        if features.ndim == 2:
            # Center and scale using only training trials. Class mean distance on these features.
            f = (f - f[train].mean(0)) / np.maximum(f[train].std(0), 1e-8)
        centers = np.stack([f[train][ztrain == label].mean(0) for label in (0, 1)])
        distance = np.sum((f[test, None] - centers[None])**2, axis=-1)
        out[test] = distance.argmin(-1)
    if not (out >= 0).all():
        raise RuntimeError('one or more trials were not tested')
    return balanced(y, out)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cache', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--subjects', type=int, default=16, choices=range(1,17), metavar='1..16')
    args = p.parse_args()
    args.cache.mkdir(parents=True, exist_ok=True); args.out.mkdir(parents=True, exist_ok=True)
    ids = list(range(1, args.subjects+1))
    with ThreadPoolExecutor(max_workers=12) as ex:
        jobs = {(s,r): ex.submit(fetch, args.cache, s, r) for s in ids for r in RUNS}
        files = {k: v.result() for k,v in jobs.items()}
    rows = []
    manifest = {}
    print(f'Parsed source set: {len(files)} EDF+ files to evaluate', flush=True)
    for s in ids:
        data = [epochs(files[s,r]) for r in RUNS]
        names = data[0][2]
        if not all(z[2] == names for z in data):
            raise ValueError('channel order changed within subject')
        x = np.concatenate([z[0] for z in data]); y = np.concatenate([z[1] for z in data])
        g = np.concatenate([np.full(len(z[1]),r) for z,r in zip(data,RUNS,strict=True)])
        for r,z in zip(RUNS,data,strict=True):
            manifest[files[s,r].name] = dict(sha256=z[3], retained_trials=len(z[1]))
        row = dict(participant=f'S{s:03d}', trials=len(y), left=int(np.sum(y==0)), right=int(np.sum(y==1)))
        for label, chans in SETS.items():
            dat = x[:, [names.index(c) for c in chans]]
            power, cov = feature_matrices(dat)
            row[f'{label}_power'] = predict(power,g,y)
            row[f'{label}_cov'] = predict(cov,g,y)
            if label == 'day_16':
                row['day_16_cov_shuffled'] = float(np.mean([predict(cov,g,y,True,100*s+i) for i in range(24)]))
        rows.append(row)
        print(row['participant'],row['trials'],f"DAY16/cov {row['day_16_cov']:.3f}", flush=True)
    rng = np.random.default_rng(2202)
    resamples = rng.integers(0,len(ids),(10000,len(ids)))
    means = {}
    vectors = {}
    for metric in [k for k in rows[0] if k.endswith(('_power','_cov','_shuffled'))]:
        vec = np.array([row[metric] for row in rows]); vectors[metric] = vec
        means[metric] = dict(mean=float(vec.mean()), ci95=np.quantile(vec[resamples].mean(axis=1), [.025,.975]).tolist())
    paired = vectors['lab_32_cov'] - vectors['day_16_cov']
    out = dict(protocol='RXN-EEGMMIDB-R0', numpy=np.__version__, participants=len(ids), unique_trials=sum(row['trials'] for row in rows),
               runs=list(RUNS), montage=SETS, methods=['log-bandpower nearest standardized mean','trace-normalized log-Euclidean covariance nearest mean'],
               notes='Offline; same visit/run holdout; cue-locked 0.5–3.5 s; 50% theoretical chance; no idle/online/dry-hardware/speech conclusion; participant-bootstrap percentile intervals are descriptive.',
               metrics=means, lab_minus_day_cov=dict(mean=float(paired.mean()),ci95=np.quantile(paired[resamples].mean(axis=1),[.025,.975]).tolist()), file_manifest=manifest)
    with (args.out/'participants.csv').open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f,rows[0].keys()); w.writeheader(); w.writerows(rows)
    (args.out/'benchmark.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({k:out[k] for k in ('participants','unique_trials','metrics','lab_minus_day_cov')},indent=2))


if __name__ == '__main__':
    main()
