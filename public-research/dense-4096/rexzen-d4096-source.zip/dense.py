"""D4096 bench planning: exact topology, deterministic transport replay, budgets. Not hardware."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import struct
import time
import zlib

import numpy as np

CONTACTS = 4096
SECTORS = 8
TILES = 64
LANES = 64
WINDOW = 8
RATE = 250
PITCH_ASSUMPTION_MM = 3.5
RADIUS_MM = 96.
AREA_CM2 = 560.
MAGIC = b'RX4D'
HEADER = struct.Struct('<4sBBQH')
CRC = struct.Struct('<I')
PAYLOAD = WINDOW * LANES * 3
PACKET = HEADER.size + PAYLOAD + CRC.size


def repel_close_sites(xyz, radius_mm, cap_floor_mm):
    """Small deterministic tangent displacements on the surrogate; not anatomical CAD."""
    # Searching neighbors within 4.15 mm is sufficient: each point is allowed
    # to move at most 0.45 mm from its initial position (3.24 + 2 x 0.45 < 4.15).
    target=3.24; limit=.45
    n=len(xyz); pairs=[]
    for start in range(0,n,128):
        stop=min(start+128,n)
        d2=2*radius_mm**2-2*(xyz[start:stop]@xyz.T)
        i,j=np.where(d2<4.15**2); i=i+start
        pairs.append(np.column_stack((i[i<j],j[i<j])))
    a,b=np.concatenate(pairs,axis=0).T
    p=xyz.copy()
    for _ in range(200):
        dx=p[a]-p[b]; dist=np.linalg.norm(dx,axis=1)
        active=dist<target-1e-7
        if not active.any():break
        i,j=a[active],b[active]; d=dist[active]
        step=dx[active]*((target-d)/d*.28)[:,None]
        delta=np.zeros_like(p)
        np.add.at(delta,i,step); np.add.at(delta,j,-step)
        delta-=((delta*p).sum(axis=1)/radius_mm**2)[:,None]*p
        nxt=p+delta
        nxt*=radius_mm/np.linalg.norm(nxt,axis=1,keepdims=True)
        outside=nxt[:,2]<cap_floor_mm
        if np.any(outside):
            nxt[outside,:2]*=(math.sqrt(radius_mm**2-cap_floor_mm**2)/np.linalg.norm(nxt[outside,:2],axis=1))[:,None]
            nxt[outside,2]=cap_floor_mm
        nxt[np.linalg.norm(nxt-xyz,axis=1)>limit]=p[np.linalg.norm(nxt-xyz,axis=1)>limit]
        if np.array_equal(p,nxt):break
        p=nxt
    return p


def geometry(area_cm2=AREA_CM2, radius_mm=RADIUS_MM, relax=True):
    if not 0 < area_cm2 * 100 < 2 * math.pi * radius_mm**2:
        raise ValueError('surrogate assumes a non-empty cap smaller than a hemisphere')
    # Equal-area Fibonacci points on a spherical cap. Mapping, not patient anatomy.
    d = area_cm2 * 100 / (2 * math.pi * radius_mm**2)
    i = np.arange(CONTACTS, dtype=float)
    theta = i * (math.pi * (3 - math.sqrt(5)))
    z = 1 - d*(i + .5)/CONTACTS
    r = np.sqrt(1-z*z)*radius_mm
    xyz = np.column_stack((r*np.cos(theta),r*np.sin(theta),z*radius_mm))
    if relax: xyz=repel_close_sites(xyz,radius_mm,radius_mm*(1-d))
    xy = xyz[:,:2]*np.sqrt(2/(1+xyz[:,2]/radius_mm))[:,None]

    def split(indices, depth):
        if depth == 0:
            yield indices
            return
        a = int(np.argmax(np.ptp(xy[indices],axis=0)))
        halves = np.array_split(indices[np.argsort(xy[indices,a],kind='stable')],2)
        for half in halves: yield from split(half,depth-1)

    out=[]
    for sector, ss in enumerate(split(np.arange(CONTACTS),3)):
        for tile, tt in enumerate(split(ss,3)):
            t=sector*8+tile
            # Lanes follow local projection order; they do not represent a rectangular array.
            order=tt[np.lexsort((xy[tt,0],xy[tt,1]))]
            for lane,j in enumerate(order):
                x,y,z=xyz[j]; u,v=xy[j]
                out.append(dict(address=t*LANES+lane,sector=sector,tile_in_sector=tile,tile=t,lane=lane,
                                x_mm=float(x),y_mm=float(y),z_mm=float(z),lambert_x_mm=float(u),lambert_y_mm=float(v)))
    return out


def distribution(rows, radius_mm=RADIUS_MM):
    p=np.array([[r[f'{a}_mm'] for a in 'xyz'] for r in rows]); tile=np.array([r['tile'] for r in rows]); n=len(p)
    near=np.empty(n); seam=np.empty(n)
    for k in range(0,n,128):
        end=min(k+128,n); kx=np.arange(k,end)
        chord2=np.maximum(0,2*radius_mm**2-2*(p[k:end]@p.T))
        chord2[np.arange(end-k),kx]=np.inf
        near[k:end]=2*radius_mm*np.arcsin(np.sqrt(chord2.min(axis=1))/(2*radius_mm))
        chord2[tile[k:end,None]==tile[None,:]]=np.inf
        seam[k:end]=2*radius_mm*np.arcsin(np.sqrt(chord2.min(axis=1))/(2*radius_mm))
    spans=[]
    for j in range(TILES):
        pts=np.array([[r['lambert_x_mm'],r['lambert_y_mm']] for r in rows if r['tile']==j])
        spans.append(np.ptp(pts,axis=0))
    stats=lambda a:dict(min_mm=float(a.min()),p05_mm=float(np.quantile(a,.05)),median_mm=float(np.median(a)))
    return dict(nearest=stats(near),across_tile_nearest=stats(seam),max_tile_projection_spans_mm=np.max(spans,axis=0).tolist())


def encode(tile, first_sample, values):
    v=np.asarray(values)
    if not 0<=tile<TILES or not 0<=first_sample<2**64 or first_sample%WINDOW or v.shape!=(WINDOW,LANES) or v.dtype.kind not in 'iu':
        raise ValueError('invalid tile, block index, or integer array shape')
    if np.any(v < -8388608) or np.any(v > 8388607):
        raise ValueError('i24 overflow')
    a=v.ravel().astype(np.int32)
    wire=np.empty((a.size,3),dtype=np.uint8)
    for k in range(3): wire[:,k]=(a>>(8*k))&255
    b=HEADER.pack(MAGIC,1,tile,first_sample,PAYLOAD)+wire.tobytes()
    return b+CRC.pack(zlib.crc32(b))


def decode(packet):
    if len(packet)!=PACKET or CRC.unpack_from(packet,len(packet)-4)[0]!=zlib.crc32(packet[:-4]):
        raise ValueError('corrupt or truncated packet')
    magic,version,tile,first,size=HEADER.unpack_from(packet)
    if magic!=MAGIC or version!=1 or tile>=TILES or first%WINDOW or size!=PAYLOAD:
        raise ValueError('bad header')
    b=np.frombuffer(packet,dtype=np.uint8,count=PAYLOAD,offset=HEADER.size).reshape(-1,3).astype(np.int32)
    i=b[:,0]|(b[:,1]<<8)|(b[:,2]<<16)
    i=(i ^ 8388608)-8388608
    return tile,first,i.reshape(WINDOW,LANES)


class Collector:
    """Assemble a single time block; missing values are placeholders plus explicit validity."""
    def __init__(self,first_sample):
        if not 0<=first_sample<2**64 or first_sample%WINDOW: raise ValueError('bad block start')
        self.first=first_sample; self.seen=set(); self.closed=False
        self.values=np.zeros((WINDOW,CONTACTS),dtype=np.int32)
        self.valid=np.zeros(CONTACTS,dtype=bool)

    def add(self,packet):
        tile,first,values=decode(packet)
        if self.closed or first!=self.first or tile in self.seen: raise ValueError('closed, matching replay or wrong time block')
        a=tile*LANES; z=a+LANES
        self.values[:,a:z]=values; self.valid[a:z]=True; self.seen.add(tile)

    def finish(self):
        self.closed=True
        return self.values,self.valid


def stress(seconds):
    blocks=round(seconds*RATE/WINDOW)
    if blocks < 1: raise ValueError('duration too short')
    rng=np.random.default_rng(4096)
    sha=hashlib.sha256(); start=time.perf_counter()
    for b in range(blocks):
        block=rng.integers(-8388608,8388608,size=(WINDOW,CONTACTS),dtype=np.int32)
        c=Collector(b*WINDOW)
        for tile in range(TILES-1,-1,-1):  # deliberately delivered in reverse tile order
            lo=tile*LANES
            wire=encode(tile,b*WINDOW,block[:,lo:lo+LANES]); sha.update(wire); c.add(wire)
        decoded,valid=c.finish()
        if not np.all(valid) or not np.array_equal(decoded,block): raise AssertionError('bit mismatch')
    return dict(synthetic_duration_s=blocks*WINDOW/RATE,frames=blocks,signed_values=blocks*WINDOW*CONTACTS,
                packet_count=blocks*TILES,wire_bytes=blocks*TILES*PACKET,rejected_or_lost_clean_packets=0,
                wire_sha256=sha.hexdigest(),host_processing_s=round(time.perf_counter()-start,3))


def budgets():
    k=1.380649e-23; temp=310; bw=44.5; pr=[]
    for r in [100_000,300_000,1_000_000]:
        # Both source impedances modeled as equal, white resistors, and otherwise ideal.
        noise=(4*k*temp*(2*r)*bw)**.5 * 1e6
        pr.append(dict(ohm_per_side=r,johnson_uvrms_pair=noise,plus_1uv_electronics_rss_uvrms=math.hypot(noise,1.0)))
    wire=PACKET*TILES*RATE/WINDOW
    return dict(channels=CONTACTS,tile_count=TILES,lane_count=LANES,sectors=SECTORS,rate_sps=RATE,word_bits=24,
                payload_megabits_s=CONTACTS*RATE*24/1e6,raw_8h_decimal_gb=CONTACTS*RATE*3*8*3600/1e9,
                packet_overhead_wire_megabits_s=wire*8/1e6,packet_wire_8h_decimal_gb=wire*8*3600/1e9,
                each_sector_on_wire_megabits_s=wire*8/1e6/SECTORS,optional_500sps_wire_megabits_s=2*wire*8/1e6,
                skin_temp_kelvin_assumed=temp,noise_bandwidth_hz=bw,noise_model=pr,
                phase_error_at_90hz_degrees_for_10us=360*90*10e-6,
                links_and_logic_budget_w=.21,cap_power_goal_w=.45,afe_budget_at_50uW_each_w=CONTACTS*50e-6,
                cap_nominal_w=.21+CONTACTS*50e-6,pocket_nominal_w=.55,battery_design_ceiling_w=1.25,
                usable_wh_after_margins=15*.8,modeled_hours_at_design_ceiling=15*.8/1.25,
                triangular_pitch_3p5_area_cm2=CONTACTS*(3.5**2*math.sqrt(3)/2)/100,
                target_sphere_radius_mm=RADIUS_MM,projected_contact_pitch_guess_mm=PITCH_ASSUMPTION_MM)


def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--seconds',type=float,default=120.)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    g=geometry()
    with (a.out/'electrode-map.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=g[0].keys(),lineterminator='\n'); w.writeheader(); w.writerows(g)
    checks={str(area):{'unrelaxed':distribution(geometry(area_cm2=area,relax=False)),
                        'optimized':distribution(geometry(area_cm2=area))} for area in [480,520,560]}
    j=dict(version='D4096/0.2',scope='Modeled surrogate floorplan and synthetic transport loopback only; no hardware, human or signal data.',numpy=np.__version__,budgets=budgets(),geometry=checks,loopback=stress(a.seconds))
    (a.out/'bench-model.json').write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(j,indent=2))

if __name__=='__main__':main()
