"""Fixed-protocol secondary analysis of the author-published VisualStim S03 sample."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy import __version__ as scipy_version
from scipy.io import loadmat
from scipy.linalg import solve

EXPECTED_SHA='3a8f7f748174d070f0d181722fa6db929b49cd4fae5485c280b1fb2ca727791d'
SIZES=(32,64,128,256,512)
SEEDS=range(4096,4108)


def folds(filenames, n=4):
    for test in np.array_split(np.arange(len(filenames)),n):
        yield np.flatnonzero(~np.isin(filenames,filenames[test])),test


def scores(y, pred):
    return float(np.mean([np.mean(pred[y==j]==j) for j in np.unique(y)]))


def ridge_eval(features, labels, splits, label_seed=None):
    yp=np.full(len(labels),-1,dtype=int)
    rng=np.random.default_rng(label_seed)
    q=labels.copy()
    if label_seed is not None:
        for _,block in splits:q[block]=rng.permutation(labels[block])
    for train,test in splits:
        z=q[train]
        if set(z)!=set(np.unique(labels)): raise ValueError('a fold is missing a class')
        vals,trials=np.unique(z,return_counts=True)
        # Standardize and conservatively clip using only retained training trials in this fold.
        mu=features[train].mean(0); sd=np.maximum(features[train].std(0),1e-9)
        a=np.clip((features[train]-mu)/sd,-5,5)
        b=np.clip((features[test]-mu)/sd,-5,5)
        w=(len(z)/(len(vals)*trials[z]))**.5
        yw=np.eye(len(vals))[z]*w[:,None]
        u=a*w[:,None]
        gram=u@u.T + .5*a.shape[1]*np.eye(len(a))
        beta=solve(gram,yw,assume_a='pos')
        yp[test]=((b@u.T)@beta).argmax(1)
    if np.any(yp<0): raise AssertionError('incomplete fold coverage')
    return scores(labels,yp),yp


def epoch_features(x, onsets, rate, start):
    base_l,base_r=np.rint(np.array([-.60,-.43])*rate).astype(int)
    edges=np.rint((start+.04*np.arange(9))*rate).astype(int)
    feats=[]
    for k in onsets:
        if min(base_l,edges[0])+k<0 or k+max(base_r,edges[-1])>x.shape[1]:raise ValueError('incomplete epoch')
        baseline=x[:,k+base_l:k+base_r].mean(axis=1)
        feats.append(np.stack([x[:,k+a:k+b].mean(1)-baseline for a,b in zip(edges[:-1],edges[1:],strict=True)],axis=-1))
    return np.stack(feats)


def run_mat(path):
    with path.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
    if sha!=EXPECTED_SHA:raise ValueError('file does not match the published sample')
    m=loadmat(path,simplify_cells=True)
    tag=m['ch_str']; rate=m['SR']; raw=m['y']; meta=m['ParadigmInfo']; details=meta['ImageDetails']
    if rate!=512 or np.sum(tag=='EEG')!=512 or np.sum(tag=='image_type_sw')!=1:raise ValueError('schema differs')
    marker=raw[tag=='image_type_sw'][0]
    onsets=np.flatnonzero((marker[1:]!=marker[:-1]) & (marker[1:]>0))+1
    names=np.array([e['filename'] for e in details]); categories=list(meta['image_type']); y=np.array([categories.index(e['image_type']) for e in details]);
    if len(onsets)!=len(y) or not np.array_equal(marker[onsets],y+1):raise ValueError('marker and metadata disagree')
    if np.diff(onsets).min()/rate<=1:raise ValueError('unexpected overlap or event spacing')
    raw=raw[tag=='EEG']; pre=epoch_features(raw,onsets,rate,-.40); post=epoch_features(raw,onsets,rate,.08)
    if not (np.all(np.isfinite(pre)) and np.all(np.isfinite(post))):raise ValueError('bad input')
    splits=list(folds(names))
    stats=[]
    for n in SIZES:
        individual=[]; prior=[]
        for seed in SEEDS if n<512 else (4096,):
            channels=np.sort(np.random.default_rng(seed).permutation(512)[:n])
            a=post[:,channels].reshape(len(y),-1); b=pre[:,channels].reshape(len(y),-1)
            individual.append(ridge_eval(a,y,splits)[0]); prior.append(ridge_eval(b,y,splits)[0])
        stats.append(dict(eeg_channels=n,layout_repeats=len(individual),post_median=float(np.median(individual)),post_range=[min(individual),max(individual)],
                          prestim_median=float(np.median(prior)),prestim_range=[min(prior),max(prior)]))
    null=[ridge_eval(post.reshape(len(y),-1),y,splits,label_seed=i)[0] for i in range(32)]
    return dict(scope='Real author-published EEG: one participant, one session, exploratory four-class visual task only. No Rexzen recordings or 4096-channel inference.',
                file=path.name,sha256=sha,numpy=np.__version__,scipy=scipy_version,sampling_rate=rate,recorded_eeg_channels=512,tested_trials=len(y),
                unique_image_names=len(set(names)),class_counts=dict(Counter(e['image_type'] for e in details)),
                fold_sizes=[dict(train=len(train),test=len(test),image_name_overlap=len(set(names[train])&set(names[test]))) for train,test in splits],
                split='4 consecutive held-out time blocks; exclude all held-out image filenames from the training fold; all usable trials scored once.',
                windows='8 per-channel means on 40 ms bins at 80–400 ms for post tests; −400 to −80 ms for pre; from each subtract that trial’s −600 to −430 ms baseline.',
                montage='Nested random recorded-channel subsets for 12 fixed seeds per density; 512 uses every recorded EEG channel. Existing acquisition reference not undone; no new re-reference.',
                estimator='Fixed class-balanced ridge with training-only standardization; pooled class-balanced accuracy; ranges across subsets are not confidence intervals.',
                theoretical_chance=.25,results=stats,shuffle_512=dict(iterations=len(null),mean=float(np.mean(null)),minimum=min(null),maximum=max(null)))


def main():
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    result=run_mat(a.source)
    report=json.dumps(result,indent=2,ensure_ascii=False)+'\n'
    a.out.parent.mkdir(exist_ok=True,parents=True);a.out.write_text(report,encoding='utf-8',newline='\n')
    print(json.dumps(result,indent=2,ensure_ascii=True))

if __name__=='__main__':main()
