import itertools
import unittest

import numpy as np

try:
    import dense
except ModuleNotFoundError as exc:
    if exc.name != 'dense': raise
    dense = None


class Topology(unittest.TestCase):
    def test_independent_contact_address_space(self):
        self.assertIsNotNone(dense, 'Implement the 4096-contact floorplan')
        model = dense.geometry(area_cm2=560)
        self.assertEqual(len(model), 4096)
        self.assertEqual([x['address'] for x in model], list(range(4096)))
        self.assertEqual({(x['sector'],x['tile_in_sector'],x['lane']) for x in model}, set(itertools.product(range(8),range(8),range(64))))
        self.assertEqual(len({(x['x_mm'],x['y_mm'],x['z_mm']) for x in model}),4096)
        self.assertTrue(all(x['z_mm']>0 for x in model))

    def test_compact_surrogate_relaxation_meets_spacing_bound(self):
        optimized=dense.geometry(area_cm2=480,relax=True)
        self.assertEqual(len(optimized),4096)
        self.assertGreaterEqual(dense.distribution(optimized)['nearest']['min_mm'],3.2)

    def test_verified_i24_and_fault_handling(self):
        self.assertIsNotNone(dense, 'Implement the sample transport')
        rng=np.random.default_rng(13)
        v=rng.integers(-8388608,8388608,size=(8,64),dtype=np.int32); v[0,:3]=[-8388608,-1,8388607]
        pkt=dense.encode(19,72,v)
        tile,index,result=dense.decode(pkt)
        self.assertEqual((tile,index),(19,72));np.testing.assert_array_equal(v,result)
        damaged=bytearray(pkt);damaged[25]^=0x4
        with self.assertRaises(ValueError):dense.decode(damaged)
        with self.assertRaises(ValueError):dense.encode(19,72,v.astype(np.int64)+8388608)
        c=dense.Collector(72)
        c.add(pkt)
        with self.assertRaises(ValueError):c.add(pkt)
        with self.assertRaises(ValueError):c.add(dense.encode(20,80,v))
        batch,valid=c.finish()
        self.assertEqual(batch.shape,(8,4096));self.assertEqual(int(valid.sum()),64)
        self.assertFalse(valid[0]);self.assertTrue(valid[19*64]);np.testing.assert_array_equal(batch[:,19*64:20*64],v)


if __name__=='__main__':unittest.main()
