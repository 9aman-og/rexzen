"""Build the D4096 public research artifacts; Markdown remains the editable source."""
from __future__ import annotations

import csv
from html import escape
import json
import math
from pathlib import Path
import re
import shutil

from markdown_it import MarkdownIt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'release'
ROUTE='https://rexzen.si/research/bci/dense-4096/'
PALETTE=('#235b48','#55805f','#346669','#497f8a','#796f50','#a06244','#80575f','#4c6b82')


def out(name,text): (OUT/name).write_text(text,encoding='utf8',newline='\n')
def percent(value):return f'{value:.1%}'
def read(name): return json.loads((ROOT/name).read_text(encoding='utf8'))


def topology(rows):
    k=1.47; cx,cy=258,256; rr=math.sqrt(56000/math.pi)*k
    g=[]
    for s,col in enumerate(PALETTE):
        circles=[]
        for a in rows:
            if int(a['sector'])!=s:continue
            x=cx+k*float(a['lambert_x_mm']); y=cy-k*float(a['lambert_y_mm']); r=1.24 if int(a['tile'])%2==0 else 1.49
            circles.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r}"/>')
        assert len(circles)==512
        g.append(f'<g fill="{col}"><title>Sector {s+1}: 512 pads</title>'+''.join(circles)+'</g>')
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="680" height="530" viewBox="0 0 680 530" role="img" aria-labelledby="t d">
<title id="t">D4096 spherical surrogate contact map</title><desc id="d">Each point is one individually addressed scalp electrode in the design. Eight colors separate the eight 512-contact sectors. This is not an anatomical fit drawing.</desc>
<defs><pattern id="grid" width="18" height="18" patternUnits="userSpaceOnUse"><path d="M18 0H0V18" fill="none" stroke="#dce3d9"/></pattern></defs>
<rect x="0" y="0" width="680" height="530" rx="8" fill="#f4f6ef" stroke="#b9c6b9"/><rect x="20" y="20" width="640" height="490" fill="url(#grid)" stroke="#c1cdc1"/>
<circle cx="{cx}" cy="{cy}" r="{rr:.2f}" fill="#edf2e8" stroke="#819786" stroke-width="1.1"/>{''.join(g)}
<g font-family="Segoe UI, Arial, sans-serif" fill="#24382e"><text x="38" y="48" font-size="15" font-weight="700" letter-spacing="1">ELECTRODE MAP / 560 CM²</text>
<text x="487" y="122" font-size="15" font-weight="700">Sector index</text>
{''.join(f'<circle cx="495" cy="{148+i*30}" r="6" fill="{color}"/><text x="509" y="{153+i*30}" font-size="13">{i+1:02d} / 512 sites</text>' for i,color in enumerate(PALETTE))}
<text x="38" y="483" font-size="14">Equal-area projection • 4,096 independent addresses • not anatomical</text></g></svg>'''


def signal_path():
    labels=[(23,63,168,'Sensor islands','64 contacts × 64 tiles','#22d3ee'),(217,63,167,'Local AFE tiles','Aperture and gain calibrated','#34d399'),(410,63,190,'8 sector concentrators','Clock, health and reassembly','#fbbf24'),(410,185,190,'Pocket hub','Isolated link; raw off by default','#fbbf24'),(217,185,167,'Local decoder','Validity and mask before scores','#a78bfa'),(23,185,168,'Confirmed action','Review / confirm / expire','#fb7185')]
    cells=''.join(f'<rect x="{x}" y="{y}" width="{w}" height="68" rx="7" fill="#15282d" stroke="{c}"/><text x="{x+12}" y="{y+26}" font-size="15" font-weight="700" fill="#ebf6ef">{title}</text><text x="{x+12}" y="{y+49}" font-size="10.7" fill="#c0d5ce">{sub}</text>' for x,y,w,title,sub,c in labels)
    p=''.join(f'<path d="{d}" marker-end="url(#arrow)"/>' for d in ('M191 97h23','M384 97h23','M505 131v51','M410 219h-23','M217 219h-23'))
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="623" height="305" viewBox="0 0 623 305" role="img" aria-labelledby="a b"><title id="a">D4096 architecture</title><desc id="b">Independent sensor inputs acquire on local analog front end tiles and aggregate in eight sectors. The isolated pocket hub stores optional raw data and sends feature summaries for local confirmed actions.</desc>
<defs><pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0V20" fill="none" stroke="#34524d" stroke-width=".45"/></pattern><marker id="arrow" markerWidth="7" markerHeight="6" refX="6" refY="3" orient="auto"><path d="M0 0l7 3-7 3Z" fill="#8bb7a8"/></marker></defs>
<rect width="623" height="305" rx="8" fill="#132721"/><rect width="623" height="305" rx="8" fill="url(#grid)"/>
<g fill="none" stroke="#8bb7a8" stroke-width="1.5">{p}</g><g font-family="Segoe UI, Arial, sans-serif"><text x="23" y="34" font-size="14" fill="#abd3b9" letter-spacing="1.4">D4096 / DOUBLE-CHECK EVERY LANE</text>{cells}<text x="23" y="281" fill="#c0d5ce" font-size="12">Shared clock and primary / backup reference • no raw EEG to GPT • no stimulation</text></g></svg>'''


CSS='''
:root{--paper:#f1f4eb;--white:#fbfcf7;--ink:#192822;--muted:#3e5449;--line:#c2d0c4;--accent:#215d43;--night:#182d25;font:16px/1.6 'Segoe UI',Arial,sans-serif;color-scheme:light}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink)}a{color:var(--accent);text-underline-offset:4px}a:focus-visible{outline:3px solid currentColor;outline-offset:4px}.shell{width:min(100%,1200px);margin:auto;padding-inline:30px}.banner{border-bottom:1px solid var(--line)}.banner nav{min-height:66px;display:flex;align-items:center;justify-content:space-between;gap:8px}.logo{color:var(--ink);font-weight:760;font-size:1.19rem;letter-spacing:-.05em;text-decoration:none}.label,.note,.eyebrow{font:700 .76rem/1.4 Consolas,monospace;text-transform:uppercase;letter-spacing:.11em;color:var(--accent)}.hero{display:grid;grid-template-columns:.89fr 1.11fr;align-items:center;gap:36px;padding-block:58px 46px}h1,h2{letter-spacing:-.055em;line-height:1.04}.hero h1{font-size:clamp(3rem,8.7vw,7.4rem);margin:.08em 0 .17em}.major{font-size:clamp(1.3rem,2vw,1.9rem);line-height:1.29}.hero p{max-width:43ch}.soft{color:var(--muted)}figure{margin:0}img{display:block;max-width:100%;height:auto}figcaption{font-size:.83rem;line-height:1.45;color:var(--muted);margin-top:6px}.actions{display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin-top:20px}.button{display:inline-flex;min-height:44px;align-items:center;background:var(--accent);color:white;padding:8px 13px;font-weight:700;text-decoration:none}.band{background:var(--night);color:#f2f6ee}.band .shell{display:grid;grid-template-columns:.9fr 1.1fr;gap:46px;padding-block:36px}.band .note,.band a{color:#b4e3bf}.band .soft{color:#cce2d2}.bodypart{padding-block:38px;border-bottom:1px solid var(--line)}.bodypart h2,.band h2{font-size:clamp(2rem,4vw,3rem);margin:.3em 0 .45em}.resources{list-style:none;margin:0;padding:0}.resources li{border-top:1px solid var(--line);display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:9px 0}.resources a{font-weight:680}.resources span{color:var(--muted)}.mini{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.mini p strong{display:block;font-size:1.47rem;color:#edf6eb}.mini p{padding:0;margin:.6em 0}.mini .note{display:inline-block;margin-top:4px}.footer{padding-block:24px}.report{max-width:1020px;background:var(--white);margin:auto;padding:36px 48px 58px}.report h1{font-size:clamp(2.45rem,5.8vw,4.7rem);margin:.34em 0}.report h2{font-size:1.7rem;margin:32px 0 12px;border-top:1px solid var(--line);padding-top:17px;break-after:avoid}.report p,.report li{overflow-wrap:anywhere}.report figure{margin:20px 0}.report figure img{width:min(100%,540px)}.report table{border-collapse:collapse;width:100%;font-size:.87rem;margin:10px 0 18px}.report td,.report th{border:1px solid var(--line);padding:7px 9px;text-align:left;vertical-align:top;overflow-wrap:anywhere}.report th{background:#e1ebe0}.report tr,.report figure{break-inside:avoid}.report thead{display:table-header-group}.report code{font:.87em Consolas,monospace}.report .sources{columns:2;gap:24px;font-size:.91rem}.report .sources li{break-inside:avoid}.report .headlink{padding-bottom:8px;border-bottom:1px solid var(--line)}
@media(max-width:750px){.shell{padding-inline:18px}.hero,.band .shell{grid-template-columns:1fr;gap:18px}.hero{padding-block:34px 30px}.report{padding:22px 16px 35px}.report .sources{columns:1}.report th,.report td{padding:5px}.mini{gap:10px}}@media(max-width:460px){.resources li{grid-template-columns:1fr;gap:0}.mini{grid-template-columns:1fr}.hero figure{width:100%}}
@page{size:A4;margin:14mm 14mm 16mm}@media print{*{print-color-adjust:exact;-webkit-print-color-adjust:exact}body{font:11.4pt/1.43 Arial,sans-serif;background:white}.report{padding:0;background:white}.report h1{font-size:37pt}.report h2{font-size:19pt}.report figure img{max-height:91mm;object-fit:contain;object-position:left}.report table{font-size:9.8pt}a{text-decoration:none}}
'''


def make_html(title, body, page=''):
    return f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{escape(title)} | Rexzen Research</title><meta name="description" content="Research design, software validation and public EEG reanalysis. No Rexzen hardware performance claimed.">
<link rel="canonical" href="{ROUTE}{page}"><style>{CSS}</style></head><body>{body}</body></html>'''


def generate():
    OUT.mkdir(exist_ok=True)
    b=read('results/bench-model.json'); v=read('results/visual-study.json'); refs=read('ledger.json'); spec=(ROOT/'spec-draft.md').read_text(encoding='utf8')
    with (ROOT/'results/electrode-map.csv').open(encoding='utf8') as f: rows=list(csv.DictReader(f))
    assert [int(a['address']) for a in rows]==list(range(4096))
    out('topology.svg',topology(rows));out('signal-path.svg',signal_path())
    for name in ('electrode-map.csv','bench-model.json','visual-study.json'):shutil.copyfile(ROOT/'results'/name,OUT/name)
    loop=b['loopback']; m=b['budgets']; study=v['results']; data='\n'.join(f'| {a["eeg_channels"]} | {percent(a["post_median"])} | '+(f'{percent(a["post_range"][0])}–{percent(a["post_range"][1])}' if a['layout_repeats']>1 else 'All recorded sites')+f' | {percent(a["prestim_median"])} |' for a in study)
    results=f'''**Software loopback:** {loop['synthetic_duration_s']:.0f} s of programmed samples; {loop['packet_count']:,} packets; {loop['signed_values']:,} signed values; {loop['wire_bytes']:,} bytes encoded and reassembled without a clean-frame mismatch. Corruption, duplicate and wrong-time rejection and missing-tile validity checks passed separately. At 250 samples/s the planned payload is **{m['payload_megabits_s']:.3f} Mb/s**, **{m['packet_overhead_wire_megabits_s']:.3f} Mb/s** including our packet wrappers before physical-link overhead ({m['each_sector_on_wire_megabits_s']:.3f} Mb/s per sector). Eight hours is {m['raw_8h_decimal_gb']:.2f} decimal GB raw or {m['packet_wire_8h_decimal_gb']:.2f} GB with packet wrappers.

**Real EEG, one prepared lab session:** {v['tested_trials']} trials for four visual categories; theoretical chance is 25%. Source: the archived author sample, one participant, not Rexzen D4096.[1][13]

| Selected EEG channels | Post-stim balanced accuracy | Range across 12 subsets (not CIs) | Pre-stim control |
|---:|---:|---:|---:|
{data}

The 512-site shuffled-label mean was **{percent(v['shuffle_512']['mean'])}** (32 negative-control runs). This fixed reanalysis found **no monotonic density advantage**; the 512 result was within the ranges of the smaller subsets. It does not overturn the cohort result from the paper, establish equivalence, or justify extrapolating to 4,096. Different decoder, split and montage selection.''' 
    geo='\n'.join(f'| {a} cm² | {row["unrelaxed"]["nearest"]["min_mm"]:.3f} mm | {row["optimized"]["nearest"]["min_mm"]:.3f} mm | {row["optimized"]["nearest"]["median_mm"]:.3f} mm |' for a,row in b['geometry'].items())
    geoplot='![All 4,096 simulated contact centers, colored by sector](topology.svg)\n\n| Modeled active patch | Initial min. center-to-center | Relaxed min. center-to-center | Relaxed median nearest center |\n|---|---:|---:|---:|\n'+geo
    spec=spec.replace('@@RESULTS@@',results).replace('@@GEOMETRY@@',geoplot).replace('@@ARCH@@','![Receive-only topology from scalp contacts to local confirmed actions](signal-path.svg)')
    ids={int(x) for x in re.findall(r'\[(\d+)\]',spec)}; used={r['id']:r for r in refs if r['id'] in ids}
    assert used.keys()==ids and all(r.get('quotes') for r in used.values()) and '@@' not in spec
    reftext='\n'.join(f'[{i}] {r["url"]} — {r["title"]}' for i,r in used.items())
    (ROOT/'D4096-Engineering.md').write_text(spec+'\n\n## Sources\n\n'+reftext+'\n',encoding='utf8')
    out('sources.json',json.dumps(list(used.values()),indent=2,ensure_ascii=False)+'\n')
    text=MarkdownIt('commonmark',{'html':False}).enable('table').render(spec)
    text=re.sub(r'<p>(<img[^>]+>)</p>',r'<figure>\1</figure>',text)
    text=re.sub(r'\[(\d+)\]',lambda m:f'<sup><a href="#s{m[1]}">[{m[1]}]</a></sup>',text)
    links=''.join(f'<li id="s{i}">[{i}] <a href="{escape(r["url"],quote=True)}">{escape(r["title"])}</a></li>' for i,r in used.items())
    out('engineering.html',make_html('D4096 engineering report',f'<main class="report"><nav class="headlink"><a class="label" href="{ROUTE}">Rexzen Research / D4096</a></nav>{text}<h2>Sources</h2><ul class="sources">{links}</ul></main>','engineering.html'))
    final=b['geometry']['560']['optimized']['nearest']; ctrl=percent(v['shuffle_512']['mean'])
    resources=[('engineering.html','Read the engineering report','Noise, reference and timing budgets; manufacturing gates'),('rexzen-d4096.pdf','Download engineering PDF','Investor and technical review'),('electrode-map.csv','Download all 4,096 addresses','Coordinates, sectors, tiles and lanes'),('rexzen-d4096-source.zip','Download source and test suite','Editable report and code, with no raw EEG'),('bench-model.json','Software and geometry results','Packet throughput and modeled electrical budgets'),('visual-study.json','512-channel EEG reanalysis','Results, blinding limits and OSF checksum'),('sources.json','Primary evidence','Sources and supporting excerpts')]
    lr=''.join(f'<li><a href="{p}">{t}</a><span>{m}</span></li>' for p,t,m in resources)
    page=f'''<header class="banner"><nav class="shell" aria-label="Rexzen research"><a class="logo" href="/">Rexzen</a><a class="label" href="/research/bci/">Neural R0 ↗</a></nav></header>
<main><section class="shell hero"><div><p class="eyebrow">Neural research / D4096 / 0.2</p><h1>D4096.</h1><p class="major">4,096 scalp contacts. One separate signal path per contact.</p><p class="soft">A high-density EEG design with separately sampled channels and explicit signal-quality checks. No Rexzen dense headset has been built or tested on people.</p><div class="actions"><a class="button" href="engineering.html">Read the engineering report</a><a href="rexzen-d4096-source.zip">Get the source</a></div></div><figure><img src="topology.svg" width="680" height="530" alt="A spherical surrogate with all 4,096 scalp electrode positions grouped into eight color-coded sectors."><figcaption>Simulated geometry, not a fit scan. At 560 cm² the minimum modeled center spacing is {final['min_mm']:.2f} mm.</figcaption></figure></section>
<section class="band"><div class="shell"><div><p class="note">What we checked</p><h2>Verified in software.<br>Unverified on a head.</h2></div><div><div class="mini"><p><strong>{loop['packet_count']:,}</strong><span class="note">Synthetic packets</span></p><p><strong>{m['payload_megabits_s']:.3f} Mb/s</strong><span class="note">Native sample payload</span></p><p><strong>{v['tested_trials']} trials</strong><span class="note">Real 512-channel session</span></p></div><p class="soft">The clean digital replay round-tripped every signed sample. The separate analysis of a published visual task showed no consistent advantage from adding channels in that one session. The 512-site test scored {percent(study[-1]['post_median'])} balanced accuracy; the shuffled-label mean was {ctrl}. Neither proves 4,096-channel wearable performance.</p></div></div></section>
<section class="shell bodypart"><p class="eyebrow">What would make it better</p><h2>Pass the fit and signal tests first.</h2><p class="soft">The design requires at least 4,000 independently usable contacts in any window labeled full-density. The decisive tests are contact quality through ordinary hair, noise and timing on real 4,096-channel hardware, and a blinded task comparison against established high-density systems. Thought decoding and superiority to implanted BCIs are not claimed.</p></section>
<section class="shell bodypart"><p class="eyebrow">Release files</p><h2>Inspect and reproduce.</h2><ul class="resources">{lr}</ul></section></main><footer class="shell footer"><p class="label">Rexzen Research / November 2026 / concept only</p></footer>'''
    out('index.html',make_html('D4096 dense scalp EEG',page))
    print(f'Generated {len(rows)} sensor locations and {len(used)} evidence-backed sources')

if __name__=='__main__':generate()
