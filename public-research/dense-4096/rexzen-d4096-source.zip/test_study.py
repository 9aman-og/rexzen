import unittest

import numpy as np

try:
    from visual_study import folds, scores
except ModuleNotFoundError as exc:
    if exc.name != 'visual_study': raise
    folds = scores = None


class VisualStudyChecks(unittest.TestCase):
    def test_block_holdout_purges_all_matching_image_filenames(self):
        self.assertIsNotNone(folds,'Implement filename-disjoint time-block folds')
        filenames=np.array(['x','b','c','d','e','f','g','h','i','x','k','l'])
        held=[]
        for train,test in folds(filenames,3):
            self.assertEqual(len(test),4)
            self.assertFalse(set(filenames[train]) & set(filenames[test]))
            self.assertTrue(np.all(np.diff(test)==1))
            held.extend(test)
        self.assertEqual(sorted(held),list(range(12)))

    def test_balanced_accuracy_equal_weights_even_when_classes_differ(self):
        self.assertIsNotNone(scores,'Implement balanced accuracy')
        self.assertAlmostEqual(scores(np.array([0,0,0,1,2,3]),np.zeros(6,dtype=int)),.25)

if __name__=='__main__':unittest.main()
