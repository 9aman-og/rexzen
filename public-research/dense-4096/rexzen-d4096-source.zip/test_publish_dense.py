import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

try:
    from publish_dense_research import ASSETS, publish, ROUTE
except ModuleNotFoundError as exc:
    if exc.name != 'publish_dense_research':raise
    ASSETS=(); publish=None; ROUTE=''

class TestRelease(unittest.TestCase):
    def test_additive_deployment_does_not_replace_r0_download(self):
        self.assertTrue(callable(publish),'Implement additive dense publication')
        with TemporaryDirectory(dir=Path(__file__).parent) as temp:
            d=Path(temp); parent=d/'site/research/bci'; parent.mkdir(parents=True); release=d/'release'; release.mkdir()
            (parent/'index.html').write_text('<main>R0 original</main>',encoding='utf-8')
            (parent/'original.zip').write_bytes(b'never touched')
            (d/'site/sitemap.xml').write_text('<urlset></urlset>',encoding='utf-8')
            for n in ASSETS: (release/n).write_text('artifact',encoding='utf-8')
            (release/'index.html').write_text('<a href="engineering.html">Details</a>',encoding='utf-8')
            publish(release,d/'site')
            self.assertEqual((parent/'original.zip').read_bytes(),b'never touched')
            self.assertIn(ROUTE,(parent/'index.html').read_text(encoding='utf-8'))
            self.assertIn(ROUTE,(d/'site/sitemap.xml').read_text(encoding='utf-8'))
            self.assertEqual({p.name for p in (parent/'dense-4096').iterdir()},set(ASSETS))
            with self.assertRaises(ValueError): publish(release,d/'site')

if __name__=='__main__': unittest.main()
