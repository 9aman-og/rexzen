# Rexzen D4096 — reproducibility bundle

This is a 4,096-channel **research design**, a tested digital loopback, and secondary analysis of one published high-density EEG recording. No Rexzen hardware, trained live decoder, wearable signal or SOTA performance was demonstrated. No released electrical schematics or instructions for on-body connection are included. The 3D map is an idealized spherical surrogate, not an anatomical fit drawing or conformal manufacturing CAD.

- `D4096-Engineering.md`: editable report, figures, and sources.
- `results/electrode-map.csv`: all distinct simulated coordinates and hierarchical electrical addresses. The reference, backup, common-mode and aux inputs are outside these 4,096 rows.
- `results/bench-model.json`: floorplan before and after local relaxation, data/noise/power models and measured software-only fixed-rate replay.
- `results/visual-study.json`: fixed four-class public sample analysis; no raw recordings or image filenames included.
- `verification-matrix.csv`: explicit bench, electrical safety, study and manufacturing acceptance criteria. Thresholds are design targets, not measured.

## Run locally

1. Install Python and NumPy for `dense.py`. The geometry and transport test don't depend on SciPy. The study additionally requires SciPy. Tested version numbers are stored in the two result files.
2. Run `python -m unittest -v`, then `python dense.py --out ./reproduced --seconds 240` for the bit-exact offline packet replay and CSV. The elapsed host time is environment dependent. Digest reproducibility assumes compatible NumPy RNG behavior.
3. For actual EEG reanalysis, download `VisualStim_S03.mat` from the author-provided OSF link in the [paper's data availability section](https://www.nature.com/articles/s44172-026-00611-w#data-availability). The analysis requires SHA-256 `3a8f7f748174d070f0d181722fa6db929b49cd4fae5485c280b1fb2ca727791d`. Run `python visual_study.py path/to/VisualStim_S03.mat --out ./reproduced/visual-study.json`. See the included ledger for data attribution and don't infer rights to redistribute raw data from this release.
4. Install `markdown-it-py` and use `python build_dense_release.py` to rebuild the public HTML/SVG. Print `release/engineering.html` with a Chromium browser to regenerate the PDF. The public page's parent links expect to be hosted on Rexzen.

The 512-channel comparison uses a single prepared recording with 80 trials. Ranges for smaller layouts are variation across nested channel subsets, not uncertainty across members of a population. This release is not an on-body test procedure and does not assert patent protection or freedom to operate.
