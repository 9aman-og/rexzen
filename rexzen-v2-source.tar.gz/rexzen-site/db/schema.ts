import { sql } from "drizzle-orm";
import { sqliteTable, text, integer, primaryKey, index, uniqueIndex, check } from "drizzle-orm/sqlite-core";

// Ciphertext is versioned AES-256-GCM with purpose/user/resource AAD.
// Millisecond timestamps and routing metadata are the only plaintext record fields.
export const accountSettings = sqliteTable("account_settings", {
  userId: text("user_id").primaryKey(),
  preferencesCipher: text("preferences_cipher").notNull(),
  updatedAt: integer("updated_at").notNull(),
});

export const privateKeys = sqliteTable("private_keys", {
  userId: text("user_id").primaryKey(),
  keyCipher: text("key_cipher").notNull(),
  updatedAt: integer("updated_at").notNull(),
});

export const sessions = sqliteTable("sessions", {
  sidHash: text("sid_hash").primaryKey(),
  userId: text("user_id").notNull(),
  tokenCipher: text("token_cipher").notNull(),
  supabaseExpiresAt: integer("supabase_expires_at").notNull(),
  expiresAt: integer("expires_at").notNull(),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
}, (table) => [index("sessions_user_idx").on(table.userId), index("sessions_expiry_idx").on(table.expiresAt)]);

export const records = sqliteTable("records", {
  userId: text("user_id").notNull(),
  id: text("id").notNull(),
  type: text("type").notNull(),
  revision: integer("revision").notNull(),
  archived: integer("archived", { mode: "boolean" }).notNull().default(false),
  cipher: text("cipher").notNull(),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
}, (table) => [
  primaryKey({ columns: [table.userId, table.id] }),
  index("records_user_updated_idx").on(table.userId, table.updatedAt),
  index("records_user_type_idx").on(table.userId, table.type),
  check("records_type_check", sql`${table.type} in ('note','project','task','goal','log','personal')`),
  check("records_revision_check", sql`${table.revision} > 0`),
]);

export const recordRevisions = sqliteTable("record_revisions", {
  userId: text("user_id").notNull(),
  recordId: text("record_id").notNull(),
  revision: integer("revision").notNull(),
  cipher: text("cipher").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => [primaryKey({ columns: [table.userId, table.recordId, table.revision] })]);

export const edges = sqliteTable("edges", {
  userId: text("user_id").notNull(),
  id: text("id").notNull(),
  fromId: text("from_id").notNull(),
  toId: text("to_id").notNull(),
  relation: text("relation").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => [
  primaryKey({ columns: [table.userId, table.id] }),
  uniqueIndex("edges_endpoints_relation_idx").on(table.userId, table.fromId, table.toId, table.relation),
  index("edges_user_to_idx").on(table.userId, table.toId),
  check("edges_relation_check", sql`${table.relation} in ('supports','depends_on','part_of','related')`),
  check("edges_self_check", sql`${table.fromId} <> ${table.toId}`),
]);

export const receipts = sqliteTable("receipts", {
  userId: text("user_id").notNull(),
  id: text("id").notNull(),
  hash: text("hash").notNull(),
  model: text("model").notNull(),
  status: text("status").notNull().default("prepared"),
  cipher: text("cipher").notNull(),
  expiresAt: integer("expires_at").notNull(),
  createdAt: integer("created_at").notNull(),
  sendStartedAt: integer("send_started_at"),
  sentAt: integer("sent_at"),
  conversationId: text("conversation_id"),
  proposalId: text("proposal_id"),
}, (table) => [
  primaryKey({ columns: [table.userId, table.id] }),
  index("receipts_expiry_idx").on(table.expiresAt),
  index("receipts_user_conversation_idx").on(table.userId, table.conversationId),
  check("receipts_status_check", sql`${table.status} in ('prepared','sending','sent','failed')`),
]);

export const conversations = sqliteTable("conversations", {
  userId: text("user_id").notNull(),
  id: text("id").notNull(),
  cipher: text("cipher").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => [primaryKey({ columns: [table.userId, table.id] }), index("conversations_user_created_idx").on(table.userId, table.createdAt)]);

export const proposals = sqliteTable("proposals", {
  userId: text("user_id").notNull(),
  id: text("id").notNull(),
  status: text("status").notNull().default("pending"),
  cipher: text("cipher").notNull(),
  sourceSnapshot: text("source_snapshot").notNull(),
  createdAt: integer("created_at").notNull(),
  appliedAt: integer("applied_at"),
}, (table) => [
  primaryKey({ columns: [table.userId, table.id] }),
  index("proposals_user_status_idx").on(table.userId, table.status),
  check("proposals_status_check", sql`${table.status} in ('pending','applied')`),
]);

export const rateLimitBuckets = sqliteTable("rate_limit_buckets", {
  subject: text("subject").notNull(),
  scope: text("scope").notNull(),
  bucketStart: integer("bucket_start").notNull(),
  requestCount: integer("request_count").notNull(),
}, (table) => [primaryKey({ columns: [table.subject, table.scope, table.bucketStart] }), index("rate_buckets_expiry_idx").on(table.bucketStart)]);
