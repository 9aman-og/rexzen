(() => {
  'use strict';
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const controls = 'button, a.button, a.nav-cta, a.text-link, .chapter-nav a, .project-directory a';
  const timers = new WeakMap();
  function contact(target) {
    if (preference.matches || !(target instanceof Element)) return;
    const control = target.closest(controls);
    if (!control) return;
    clearTimeout(timers.get(control));
    control.setAttribute('data-pressing', '');
    timers.set(control, setTimeout(() => control.removeAttribute('data-pressing'), 300));
  }
  document.addEventListener('pointerdown', event => contact(event.target), {passive:true});
  document.addEventListener('keydown', event => {
    if (!event.repeat && (event.key === 'Enter' || event.key === ' ')) contact(event.target);
  });
  const groups = [...document.querySelectorAll('.nav-group')];
  groups.forEach(group => group.addEventListener('toggle', () => {
    if (group.open) groups.forEach(other => { if (other !== group) other.open = false; });
  }));
  document.addEventListener('click', event => groups.forEach(group => {
    if (!group.contains(event.target)) group.open = false;
  }));
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    const open = groups.find(group => group.open);
    if (open) { open.open = false; open.querySelector('summary').focus(); }
  });
  document.addEventListener('site-menu-open', () => groups.forEach(group => group.open = false));
})();
