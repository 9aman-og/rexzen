(() => {
  'use strict';
  const root = document.documentElement;
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const restored = !!location.hash || performance.getEntriesByType('navigation')[0]?.type === 'back_forward';
  if (!preference.matches && !document.hidden && !restored) root.dataset.brandIntro = 'armed';
  const safety = setTimeout(() => root.removeAttribute('data-brand-intro'), 3000);
  function ready() {
    const scene = document.querySelector('[data-brand-cinema]');
    if (!scene) { clearTimeout(safety); root.removeAttribute('data-brand-intro'); return; }
    const letters = [...scene.querySelectorAll('[data-brand-letter]')];
    const notes = [...scene.querySelectorAll('[data-cinema-note]')];
    const field = scene.querySelector('[data-cinema-field]');
    const layers = [...scene.querySelectorAll('[data-cinema-layer]')];
    const contour = scene.querySelector('[data-cinema-contour]');
    let visible = false, consumed = false, uncovered = false, leaving = false, animations = [];
    let tracer = null, traceMotion = null;
    const syncTrace = () => {
      if (!traceMotion) return;
      const phase = root.dataset.pageMotion;
      const active = visible && !leaving && !document.hidden && !preference.matches &&
        !root.classList.contains('directory-open') && scene.dataset.identityState === 'settled' &&
        (!phase || (phase === 'arriving' && uncovered));
      tracer.style.visibility = active ? 'visible' : 'hidden';
      if (active) traceMotion.play(); else traceMotion.pause();
    };
    const settle = () => {
      animations.forEach(animation => animation.cancel()); animations = [];
      clearTimeout(safety); root.removeAttribute('data-brand-intro');
      scene.dataset.identityState = 'settled';
      syncTrace();
    };
    const stop = () => { consumed = true; settle(); };
    const begin = () => {
      const phase = root.dataset.pageMotion;
      if (consumed || !visible || document.hidden || root.classList.contains('directory-open') ||
          (phase && !(phase === 'arriving' && uncovered))) return;
      consumed = true;
      if (preference.matches || restored || !scene.animate || root.dataset.brandIntro !== 'armed') { settle(); return; }
      scene.dataset.identityState = 'running';
      try {
        notes.forEach((node, i) => animations.push(node.animate([
          {opacity: .1, transform: 'translateY(5px)'}, {opacity: 1, transform: 'none'}
        ], {duration: 700, delay: 100 + i * 70, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'backwards'})));
        letters.forEach((node, i) => animations.push(node.animate([
          // Each SVG path has its own position transform. Keep it intact.
          {opacity: .08, fillOpacity: 0, strokeOpacity: .7},
          {opacity: .7, fillOpacity: 1, strokeOpacity: .2, offset: .3},
          {opacity: 1, fillOpacity: 1, strokeOpacity: 0}
        ], {duration: 800, delay: 160 + i * 75, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'backwards'})));
        if (field) animations.push(field.animate([
          {opacity: .5}, {opacity: 1}
        ], {duration: 1600, easing: 'cubic-bezier(.16,.65,.22,1)', fill: 'backwards'}));
        layers.forEach((layer, i) => animations.push(layer.animate([
          {transform: `translate(${12 - i * 5}px, ${8 - i * 3}px)`},
          {transform: 'translate(0px, 0px)'}
        ], {duration: 4200, delay: i * 90, easing: 'cubic-bezier(.18,.7,.22,1)', fill: 'backwards'})));
        if (contour?.getTotalLength) {
          const length = contour.getTotalLength();
          animations.push(contour.animate([
            {strokeDasharray: `${length} ${length}`, strokeDashoffset: length, opacity: 0},
            {strokeDasharray: `${length} ${length}`, strokeDashoffset: 0, opacity: 1}
          ], {duration: 2800, delay: 450, easing: 'cubic-bezier(.2,.6,.25,1)', fill: 'backwards'}));
        }
        root.removeAttribute('data-brand-intro'); clearTimeout(safety);
        Promise.allSettled(animations.map(animation => animation.finished)).then(settle);
      } catch { settle(); }
    };
    if (contour?.getTotalLength && contour.animate) {
      const length = contour.getTotalLength();
      const highlight = Math.min(140, length * .09);
      tracer = contour.cloneNode(false);
      tracer.removeAttribute('data-cinema-contour');
      tracer.setAttribute('data-cinema-tracer', '');
      tracer.setAttribute('aria-hidden', 'true');
      tracer.setAttribute('stroke', '#8a9dff');
      tracer.setAttribute('stroke-width', '3');
      tracer.setAttribute('stroke-linecap', 'round');
      tracer.setAttribute('stroke-dasharray', `${highlight} ${length + highlight}`);
      tracer.style.visibility = 'hidden';
      contour.after(tracer);
      traceMotion = tracer.animate([
        {strokeDashoffset: length + highlight, opacity: 0},
        {opacity: .75, offset: .12},
        {opacity: .75, offset: .88},
        {strokeDashoffset: -highlight, opacity: 0}
      ], {duration: 11000, iterations: Infinity, easing: 'linear'});
      traceMotion.pause();
    }
    if ('IntersectionObserver' in window) new IntersectionObserver(entries => {
      visible = entries[0].isIntersecting && entries[0].intersectionRatio >= .2;
      if (!visible && consumed) stop(); else begin();
      syncTrace();
    }, {threshold: .2}).observe(scene);
    else { visible = true; begin(); }
    document.addEventListener('site-page-uncover', () => { uncovered = true; begin(); });
    document.addEventListener('site-menu-open', stop);
    document.addEventListener('site-navigation-start', () => { leaving = true; stop(); });
    document.addEventListener('site-menu-close', () => { begin(); syncTrace(); });
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); else begin(); syncTrace(); });
    scene.addEventListener('focusin', stop);
    window.addEventListener('focus', begin);
    window.addEventListener('resize', () => { if (consumed) stop(); }, {passive: true});
    window.addEventListener('pagehide', stop);
    window.addEventListener('pageshow', event => { if (event.persisted) { leaving = false; stop(); } });
    preference.addEventListener('change', stop);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready, {once: true}); else ready();
})();
