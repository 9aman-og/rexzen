/* Local, input-driven renderer. The HTML list is the source of example data. */
const scenes = new WeakMap();
const INITIAL_VIEW = { yaw: 0.12, pitch: -0.10 };
const TYPES = { project: "Project", note: "Source note", task: "Proposed task", goal: "Goal", excluded: "Excluded personal context" };
const RADII = { project: 0.20, note: 0.145, task: 0.155, goal: 0.135, excluded: 0.13 };
const FOV = 44 * Math.PI / 180;
const EASE_MS = 160;
const DRAG_THRESHOLD = 6;
let sceneNumber = 0;

const NODE_VERTEX = `
attribute vec3 aPosition;
attribute vec3 aColor;
attribute float aRadius;
attribute float aEmphasis;
attribute float aExcluded;
uniform mat4 uViewProjection;
uniform mat4 uView;
uniform float uViewportHeight;
uniform float uFocalScale;
uniform float uMaxPointSize;
varying vec3 vColor;
varying float vEmphasis;
varying float vExcluded;
void main() {
  vec4 world = vec4(aPosition, 1.0);
  vec4 view = uView * world;
  gl_Position = uViewProjection * world;
  gl_PointSize = clamp(aRadius * uViewportHeight * uFocalScale / -view.z, 5.0, uMaxPointSize);
  vColor = aColor;
  vEmphasis = aEmphasis;
  vExcluded = aExcluded;
}`;
const NODE_FRAGMENT = `
precision mediump float;
varying vec3 vColor;
varying float vEmphasis;
varying float vExcluded;
void main() {
  vec2 point = gl_PointCoord * 2.0 - 1.0;
  float r2 = dot(point, point);
  if (r2 > 1.0) discard;
  vec3 normal = vec3(point.x, -point.y, sqrt(max(0.0, 1.0 - r2)));
  vec3 light = normalize(vec3(-0.48, 0.62, 0.90));
  float diffuse = max(dot(normal, light), 0.0);
  float specular = pow(max(dot(normal, normalize(light + vec3(0.0, 0.0, 1.0))), 0.0), 32.0);
  vec3 color = vColor * (0.54 + 0.46 * diffuse) + vec3(0.48) * specular;
  color = mix(color, color * 1.12, vEmphasis * 0.45);
  if (vExcluded > 0.5 && r2 > 0.76) color = vec3(0.48, 0.53, 0.62);
  if (vEmphasis > 0.85 && r2 > 0.85) color = vec3(0.12, 0.22, 0.67);
  float alpha = 1.0 - smoothstep(0.92, 1.0, r2);
  gl_FragColor = vec4(color, alpha);
}`;
const EDGE_VERTEX = `
attribute vec3 aPosition;
attribute vec4 aColor;
uniform mat4 uViewProjection;
varying vec4 vColor;
void main() {
  gl_Position = uViewProjection * vec4(aPosition, 1.0);
  vColor = aColor;
}`;
const EDGE_FRAGMENT = `
precision mediump float;
varying vec4 vColor;
void main() { gl_FragColor = vColor; }
`;

function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function multiply(a, b) {
  const result = new Float32Array(16);
  for (let col = 0; col < 4; col += 1) {
    for (let row = 0; row < 4; row += 1) {
      result[col * 4 + row] = a[row] * b[col * 4] + a[4 + row] * b[col * 4 + 1] + a[8 + row] * b[col * 4 + 2] + a[12 + row] * b[col * 4 + 3];
    }
  }
  return result;
}
function camera(width, height, yaw, pitch) {
  const aspect = width / height;
  const distance = 7 * Math.max(1, 1.12 / aspect);
  const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const view = new Float32Array([cy, sp * sy, -cp * sy, 0, 0, cp, sp, 0, sy, -sp * cy, cp * cy, 0, 0, 0, -distance, 1]);
  const focal = 1 / Math.tan(FOV / 2), near = 0.1, far = 60;
  const projection = new Float32Array([focal / aspect, 0, 0, 0, 0, focal, 0, 0, 0, 0, (far + near) / (near - far), -1, 0, 0, 2 * far * near / (near - far), 0]);
  return { view, viewProjection: multiply(projection, view), focal, distance, cy, sy, cp, sp };
}
function project(node, cameraState, width, height) {
  const [x, y, z] = node.position;
  const rx = cameraState.cy * x + cameraState.sy * z;
  const ry = cameraState.sp * cameraState.sy * x + cameraState.cp * y - cameraState.sp * cameraState.cy * z;
  const rz = -cameraState.cp * cameraState.sy * x + cameraState.sp * y + cameraState.cp * cameraState.cy * z;
  const depth = cameraState.distance - rz;
  const scale = height * cameraState.focal / (2 * depth);
  return { node, x: width / 2 + rx * scale, y: height / 2 - ry * scale, depth, radius: node.radius * scale };
}

function createRenderer(canvas) {
  const gl = canvas.getContext("webgl", { alpha: true, antialias: true, depth: true, stencil: false, preserveDrawingBuffer: false, powerPreference: "low-power" });
  if (!gl) throw new Error("WebGL unavailable");
  const programs = [], buffers = [];
  function dispose() {
    if (!gl.isContextLost()) {
      programs.forEach(program => gl.deleteProgram(program));
      buffers.forEach(buffer => gl.deleteBuffer(buffer));
    }
    programs.length = 0;
    buffers.length = 0;
  }
  function program(vertexSource, fragmentSource) {
    const shaders = [];
    let output;
    try {
      for (const [type, source] of [[gl.VERTEX_SHADER, vertexSource], [gl.FRAGMENT_SHADER, fragmentSource]]) {
        const shader = gl.createShader(type);
        if (!shader) throw new Error("Shader unavailable");
        shaders.push(shader);
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error("Shader compilation unavailable");
      }
      output = gl.createProgram();
      if (!output) throw new Error("Program unavailable");
      shaders.forEach(shader => gl.attachShader(output, shader));
      gl.linkProgram(output);
      if (!gl.getProgramParameter(output, gl.LINK_STATUS)) throw new Error("Program linking unavailable");
      programs.push(output);
      return output;
    } catch (error) {
      if (output) gl.deleteProgram(output);
      throw error;
    } finally {
      shaders.forEach(shader => gl.deleteShader(shader));
    }
  }
  function buffer() {
    const output = gl.createBuffer();
    if (!output) throw new Error("Buffer unavailable");
    buffers.push(output);
    return output;
  }
  function attributes(program, specs, stride) {
    for (const [name, count, offset] of specs) {
      const location = gl.getAttribLocation(program, name);
      if (location < 0) continue;
      gl.enableVertexAttribArray(location);
      gl.vertexAttribPointer(location, count, gl.FLOAT, false, stride * 4, offset * 4);
    }
  }
  try {
    const nodeProgram = program(NODE_VERTEX, NODE_FRAGMENT);
    const edgeProgram = program(EDGE_VERTEX, EDGE_FRAGMENT);
    const nodeBuffer = buffer(), edgeBuffer = buffer();
    const maxPointSize = gl.getParameter(gl.ALIASED_POINT_SIZE_RANGE)[1];
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.clearColor(0, 0, 0, 0);
    return {
      draw(nodes, edges, cameraState, selected, hovered) {
        if (gl.isContextLost()) return;
        gl.viewport(0, 0, canvas.width, canvas.height);
        gl.depthMask(true);
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
        const edgeData = [];
        for (const edge of edges) {
          const active = edge.from.id === selected || edge.to.id === selected;
          const hover = edge.from.id === hovered || edge.to.id === hovered;
          const color = active ? [0.15, 0.28, 0.91, 0.58] : hover ? [0.31, 0.41, 0.73, 0.45] : [0.53, 0.61, 0.78, edge.type === "depends_on" ? 0.39 : 0.27];
          edgeData.push(...edge.from.position, ...color, ...edge.to.position, ...color);
        }
        gl.useProgram(edgeProgram);
        gl.bindBuffer(gl.ARRAY_BUFFER, edgeBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(edgeData), gl.DYNAMIC_DRAW);
        attributes(edgeProgram, [["aPosition", 3, 0], ["aColor", 4, 3]], 7);
        gl.uniformMatrix4fv(gl.getUniformLocation(edgeProgram, "uViewProjection"), false, cameraState.viewProjection);
        gl.depthMask(false);
        gl.drawArrays(gl.LINES, 0, edges.length * 2);

        const nodeData = [];
        const ordered = [...nodes].sort((a, b) => project(b, cameraState, 1, 1).depth - project(a, cameraState, 1, 1).depth);
        for (const node of ordered) {
          const color = node.type === "excluded" ? [0.68, 0.72, 0.80] : node.type === "note" ? [0.26, 0.39, 0.84] : [0.153, 0.278, 0.906];
          nodeData.push(...node.position, ...color, node.radius, node.id === selected ? 1 : node.id === hovered ? 0.5 : 0, node.type === "excluded" ? 1 : 0);
        }
        gl.useProgram(nodeProgram);
        gl.bindBuffer(gl.ARRAY_BUFFER, nodeBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(nodeData), gl.DYNAMIC_DRAW);
        attributes(nodeProgram, [["aPosition", 3, 0], ["aColor", 3, 3], ["aRadius", 1, 6], ["aEmphasis", 1, 7], ["aExcluded", 1, 8]], 9);
        gl.uniformMatrix4fv(gl.getUniformLocation(nodeProgram, "uViewProjection"), false, cameraState.viewProjection);
        gl.uniformMatrix4fv(gl.getUniformLocation(nodeProgram, "uView"), false, cameraState.view);
        gl.uniform1f(gl.getUniformLocation(nodeProgram, "uViewportHeight"), canvas.height);
        gl.uniform1f(gl.getUniformLocation(nodeProgram, "uFocalScale"), cameraState.focal);
        gl.uniform1f(gl.getUniformLocation(nodeProgram, "uMaxPointSize"), maxPointSize);
        gl.depthMask(true);
        gl.drawArrays(gl.POINTS, 0, nodes.length);
      },
      dispose
    };
  } catch (error) {
    dispose();
    throw error;
  }
}

function readExample(root) {
  const nodes = [...root.querySelectorAll("[data-rx-node]")].map(element => {
    const type = element.dataset.rxType;
    const position = (element.dataset.rxPosition || "").split(",").map(Number);
    return { id: element.dataset.rxNode, type, title: element.querySelector("[data-rx-node-title]")?.textContent.trim(), description: element.querySelector("[data-rx-node-description]")?.textContent.trim(), position, radius: RADII[type] || 0.14, element };
  });
  if (!nodes.length || nodes.some(node => !node.id || !node.title || node.position.length !== 3 || !node.position.every(Number.isFinite))) throw new Error("Example data unavailable");
  const byId = new Map(nodes.map(node => [node.id, node]));
  const edges = [];
  for (const from of nodes) {
    for (const relation of from.element.querySelectorAll("[data-rx-relation]")) {
      const to = byId.get(relation.dataset.rxTarget);
      if (to && from.type !== "excluded" && to.type !== "excluded") edges.push({ from, to, type: relation.dataset.rxRelation });
    }
  }
  return { nodes, byId, edges };
}

function createScene(root) {
  const stage = root.querySelector("[data-rx-context-stage]");
  const canvas = root.querySelector("[data-rx-context-canvas]");
  const figure = root.querySelector("[data-rx-context-figure]");
  const labels = root.querySelector("[data-rx-context-labels]");
  const leaders = root.querySelector("[data-rx-context-leaders]");
  const list = root.querySelector("[data-rx-context-list]");
  const inspector = root.querySelector("[data-rx-context-inspector]");
  if (!stage || !canvas || !figure || !labels || !leaders || !list || !inspector) return null;
  let example;
  try { example = readExample(root); } catch { return null; }
  const { nodes, byId, edges } = example;
  const doc = root.ownerDocument, win = doc.defaultView;
  const media = win.matchMedia("(prefers-reduced-motion: reduce)");
  const cleanups = [];
  const originalInspectorId = inspector.id;
  inspector.id ||= `rx-context-inspector-${++sceneNumber}`;
  let renderer = null, destroyed = false, visible = false;
  let reduced = media.matches, selected = nodes[0].id, hovered = null;
  let yaw = INITIAL_VIEW.yaw, pitch = INITIAL_VIEW.pitch;
  let renderFrame = 0, easeFrame = 0, drag = null, suppressClickUntil = 0;
  let projected = [], width = 0, height = 0;

  function listen(target, type, handler, options) {
    target.addEventListener(type, handler, options);
    cleanups.push(() => target.removeEventListener(type, handler, options));
  }
  function cancelFrames() {
    if (renderFrame) win.cancelAnimationFrame(renderFrame);
    if (easeFrame) win.cancelAnimationFrame(easeFrame);
    renderFrame = 0;
    easeFrame = 0;
  }
  function canRender() { return !!renderer && !destroyed && visible && !doc.hidden && !doc.documentElement.classList.contains('directory-open') && root.isConnected; }
  function inViewport() {
    const rect = stage.getBoundingClientRect();
    return rect.bottom > 0 && rect.right > 0 && rect.top < win.innerHeight && rect.left < win.innerWidth;
  }
  function placeLabels() {
    const margin = 12;
    const boxes = projected.map(point => {
      const button = point.node.button;
      const w = button.offsetWidth, h = button.offsetHeight;
      let x = point.x < width / 2 - 20 ? point.x - point.radius - 12 - w : point.x + point.radius + 12;
      let y = point.y - h / 2;
      if (point.node.type === "project") { x = point.x - w / 2; y = point.y + point.radius + 12; }
      return { point, w, h, x: clamp(x, margin, Math.max(margin, width - margin - w)), y: clamp(y, margin, Math.max(margin, height - 44 - h)) };
    });
    // Labels face the reader. Only their screen positions change; controls never scale or rotate.
    for (let pass = 0; pass < 12; pass += 1) {
      let moved = false;
      for (let a = 0; a < boxes.length; a += 1) {
        for (let b = a + 1; b < boxes.length; b += 1) {
          const first = boxes[a], second = boxes[b];
          if (first.x + first.w + 8 <= second.x || second.x + second.w + 8 <= first.x || first.y + first.h + 8 <= second.y || second.y + second.h + 8 <= first.y) continue;
          const upper = first.point.y <= second.point.y ? first : second;
          const lower = upper === first ? second : first;
          const overlap = upper.y + upper.h + 8 - lower.y;
          upper.y = clamp(upper.y - overlap / 2, margin, Math.max(margin, height - 44 - upper.h));
          lower.y = clamp(lower.y + overlap / 2, margin, Math.max(margin, height - 44 - lower.h));
          moved = true;
        }
      }
      if (!moved) break;
    }
    const depthOrder = [...projected].sort((a, b) => b.depth - a.depth);
    const zIndexes = new Map(depthOrder.map((point, index) => [point.node.id, index + 2]));
    for (const box of boxes) {
      const { point, x, y, w, h } = box;
      const button = point.node.button, line = point.node.leader;
      button.style.left = `${Math.round(x)}px`;
      button.style.top = `${Math.round(y)}px`;
      button.style.zIndex = String(zIndexes.get(point.node.id));
      const endX = clamp(point.x, x, x + w), endY = clamp(point.y, y, y + h);
      const dx = endX - point.x, dy = endY - point.y;
      const length = Math.hypot(dx, dy);
      const startScale = length > 0 ? Math.min(1, (point.radius + 2) / length) : 0;
      line.setAttribute("x1", String(point.x + dx * startScale));
      line.setAttribute("y1", String(point.y + dy * startScale));
      line.setAttribute("x2", String(endX));
      line.setAttribute("y2", String(endY));
      line.style.display = length > point.radius + 4 ? "" : "none";
    }
  }
  function renderNow() {
    if (!canRender()) return;
    width = stage.clientWidth;
    height = stage.clientHeight;
    if (width < 1 || height < 1) return;
    const dpr = clamp(win.devicePixelRatio || 1, 1, 1.5);
    const pixelWidth = Math.round(width * dpr), pixelHeight = Math.round(height * dpr);
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) { canvas.width = pixelWidth; canvas.height = pixelHeight; }
    const cameraState = camera(width, height, yaw, pitch);
    projected = nodes.map(node => project(node, cameraState, width, height));
    renderer.draw(nodes, edges, cameraState, selected, hovered);
    leaders.setAttribute("viewBox", `0 0 ${width} ${height}`);
    placeLabels();
  }
  function requestRender() {
    if (!canRender() || renderFrame || easeFrame) return;
    if (reduced) { renderNow(); return; }
    renderFrame = win.requestAnimationFrame(() => { renderFrame = 0; renderNow(); });
  }
  function turnTo(nextYaw, nextPitch) {
    cancelFrames();
    nextPitch = clamp(nextPitch, -0.85, 0.85);
    if (reduced || !canRender()) { yaw = nextYaw; pitch = nextPitch; requestRender(); return; }
    const fromYaw = yaw, fromPitch = pitch, started = win.performance.now();
    function tick(now) {
      easeFrame = 0;
      if (!canRender()) return;
      const progress = clamp((now - started) / EASE_MS, 0, 1);
      const amount = 1 - Math.pow(1 - progress, 3);
      yaw = fromYaw + (nextYaw - fromYaw) * amount;
      pitch = fromPitch + (nextPitch - fromPitch) * amount;
      renderNow();
      if (progress < 1) easeFrame = win.requestAnimationFrame(tick);
    }
    easeFrame = win.requestAnimationFrame(tick);
  }
  function inspect(id, announce = true) {
    const node = byId.get(id);
    if (!node) return;
    selected = id;
    const title = inspector.querySelector("[data-rx-inspector-title]");
    const type = inspector.querySelector("[data-rx-inspector-type]");
    const description = inspector.querySelector("[data-rx-inspector-description]");
    const relations = inspector.querySelector("[data-rx-inspector-relations]");
    if (title) title.textContent = node.title;
    if (type) type.textContent = `${TYPES[node.type] || node.type} · ${node.type === "excluded" ? "Excluded from this example" : "Included in this example"}`;
    if (description) description.textContent = node.description;
    const related = edges.filter(edge => edge.from.id === id || edge.to.id === id);
    if (relations) {
      relations.replaceChildren();
      if (!related.length) {
        const item = doc.createElement("li");
        item.textContent = node.type === "excluded" ? "No relationships. This personal item is excluded and disconnected." : "No outgoing or incoming relationships in this example.";
        relations.append(item);
      }
      for (const edge of related) {
        const item = doc.createElement("li");
        const from = doc.createElement("span"), relation = doc.createElement("span"), to = doc.createElement("span");
        from.className = "rx-context-relation-endpoint";
        to.className = "rx-context-relation-endpoint";
        relation.className = "rx-context-relation-type";
        from.textContent = edge.from.title;
        relation.textContent = { supports: "supports", part_of: "part of", depends_on: "depends on" }[edge.type] || edge.type;
        to.textContent = edge.to.title;
        item.append(from, doc.createTextNode(" "), relation, doc.createTextNode(" → "), to);
        relations.append(item);
      }
    }
    for (const entry of nodes) {
      if (!entry.button) continue;
      entry.button.setAttribute("aria-pressed", String(entry.id === id));
      entry.button.classList.toggle("is-selected", entry.id === id);
      entry.leader.classList.toggle("is-selected", entry.id === id);
    }
    if (announce) {
      const announcement = inspector.querySelector("[data-rx-context-announcement]");
      if (announcement) announcement.textContent = `Selected ${node.title}. ${TYPES[node.type] || node.type}. ${related.length} relationships. Fictional example.`;
    }
    requestRender();
  }
  function fallback(message = "The example is available below as a readable list.") {
    cancelFrames();
    endDrag();
    if (renderer) renderer.dispose();
    renderer = null;
    root.dataset.rxRenderer = "list";
    figure.hidden = true;
    list.open = true;
    const status = root.querySelector("[data-rx-context-fallback-status]");
    if (status) { status.textContent = message; status.hidden = false; }
  }
  function hitTest(event) {
    const rect = stage.getBoundingClientRect();
    const x = event.clientX - rect.left, y = event.clientY - rect.top;
    return [...projected].sort((a, b) => a.depth - b.depth).find(point => Math.hypot(point.x - x, point.y - y) <= point.radius + 10)?.node.id || null;
  }
  function endDrag(event) {
    if (!drag) return;
    if (drag.moved) suppressClickUntil = win.performance.now() + 350;
    const pointerId = drag.id;
    drag = null;
    stage.classList.remove("is-dragging");
    if (stage.hasPointerCapture?.(pointerId)) stage.releasePointerCapture(pointerId);
    if (event?.type === "pointercancel") hovered = null;
  }
  function setHovered(id) { if (hovered !== id) { hovered = id; requestRender(); } }

  for (const node of nodes) {
    const button = doc.createElement("button");
    button.type = "button";
    button.className = `rx-context-node-label${node.type === "excluded" ? " is-excluded" : ""}`;
    button.dataset.rxLabel = node.id;
    button.setAttribute("aria-controls", inspector.id);
    button.setAttribute("aria-label", `${node.title}, ${TYPES[node.type] || node.type}, ${node.type === "excluded" ? "excluded" : "included"} in this fictional example. Inspect relationships.`);
    const title = doc.createElement("span"), type = doc.createElement("span");
    title.className = "rx-context-node-title";
    type.className = "rx-context-node-type";
    title.textContent = node.title;
    type.textContent = node.type === "excluded" ? "Excluded" : TYPES[node.type] || node.type;
    button.append(title, type);
    labels.append(button);
    const leader = doc.createElementNS("http://www.w3.org/2000/svg", "line");
    if (node.type === "excluded") leader.classList.add("is-excluded");
    leaders.append(leader);
    node.button = button;
    node.leader = leader;
    listen(button, "pointerenter", () => setHovered(node.id));
    listen(button, "pointerleave", () => setHovered(null));
    listen(button, "focus", () => setHovered(node.id));
    listen(button, "blur", () => setHovered(null));
  }
  const inspectButtons = [...root.querySelectorAll("[data-rx-inspect]")];
  inspectButtons.forEach(button => { button.hidden = false; button.setAttribute("aria-controls", inspector.id); });
  listen(root, "click", event => {
    const target = event.target instanceof win.Element ? event.target : null;
    const inspection = target?.closest("[data-rx-label], [data-rx-inspect]");
    if (inspection && root.contains(inspection)) {
      if (event.detail > 0 && win.performance.now() < suppressClickUntil) { event.preventDefault(); return; }
      inspect(inspection.dataset.rxLabel || inspection.dataset.rxInspect);
      return;
    }
    const turn = target?.closest("[data-rx-turn]")?.dataset.rxTurn;
    if (turn) {
      const steps = { left: [-0.32, 0], right: [0.32, 0], up: [0, -0.23], down: [0, 0.23] };
      const step = steps[turn];
      if (step) turnTo(yaw + step[0], pitch + step[1]);
    } else if (target?.closest("[data-rx-reset]")) turnTo(INITIAL_VIEW.yaw, INITIAL_VIEW.pitch);
  });
  listen(stage, "keydown", event => {
    if (event.target !== stage) return;
    const steps = { ArrowLeft: [-0.32, 0], ArrowRight: [0.32, 0], ArrowUp: [0, -0.23], ArrowDown: [0, 0.23] };
    const step = steps[event.key];
    if (!step) return;
    event.preventDefault();
    turnTo(yaw + step[0], pitch + step[1]);
  });
  listen(stage, "pointerdown", event => {
    if (!renderer || event.button !== 0 || event.target.closest?.("button")) return;
    cancelFrames();
    drag = { id: event.pointerId, type: event.pointerType, startX: event.clientX, startY: event.clientY, lastX: event.clientX, lastY: event.clientY, moved: false };
    if (event.pointerType !== "touch") {
      stage.focus({ preventScroll: true });
      stage.setPointerCapture(event.pointerId);
      event.preventDefault();
    }
  });
  listen(stage, "pointermove", event => {
    if (!drag || drag.id !== event.pointerId) {
      if (event.pointerType !== "touch" && !event.target.closest?.("button")) setHovered(hitTest(event));
      return;
    }
    const totalX = event.clientX - drag.startX, totalY = event.clientY - drag.startY;
    if (!drag.moved) {
      if (drag.type === "touch" && Math.abs(totalY) >= DRAG_THRESHOLD && Math.abs(totalY) > Math.abs(totalX)) { endDrag(); return; }
      const distance = drag.type === "touch" ? Math.abs(totalX) : Math.hypot(totalX, totalY);
      if (distance < DRAG_THRESHOLD) return;
      drag.moved = true;
      stage.classList.add("is-dragging");
      if (drag.type === "touch") {
        stage.focus({ preventScroll: true });
        stage.setPointerCapture(event.pointerId);
      }
    }
    yaw += (event.clientX - drag.lastX) * 0.008;
    if (drag.type !== "touch") pitch = clamp(pitch + (event.clientY - drag.lastY) * 0.006, -0.85, 0.85);
    drag.lastX = event.clientX;
    drag.lastY = event.clientY;
    hovered = null;
    requestRender();
  });
  listen(stage, "pointerup", endDrag);
  listen(stage, "pointercancel", endDrag);
  listen(stage, "lostpointercapture", endDrag);
  listen(stage, "pointerleave", () => { if (!drag) setHovered(null); });
  listen(stage, "click", event => {
    if (event.target.closest?.("button") || win.performance.now() < suppressClickUntil) return;
    const id = hitTest(event);
    if (id) inspect(id);
  });
  listen(canvas, "webglcontextlost", event => {
    event.preventDefault();
    fallback("The 3D view is unavailable. All fictional pieces and their relationships remain in the list below.");
  });
  listen(doc, "visibilitychange", () => { if (doc.hidden) { cancelFrames(); endDrag(); } else requestRender(); });
  listen(doc, "site-menu-open", () => { cancelFrames(); endDrag(); });
  listen(doc, "site-menu-close", requestRender);
  const motionChanged = event => { reduced = event.matches; cancelFrames(); if (reduced) list.open = true; requestRender(); };
  if (media.addEventListener) listen(media, "change", motionChanged);
  else { media.addListener(motionChanged); cleanups.push(() => media.removeListener(motionChanged)); }
  listen(win, "resize", () => { visible = inViewport(); requestRender(); }, { passive: true });
  if (win.ResizeObserver) {
    const resizeObserver = new win.ResizeObserver(() => requestRender());
    resizeObserver.observe(stage);
    cleanups.push(() => resizeObserver.disconnect());
  }
  if (win.IntersectionObserver) {
    const intersectionObserver = new win.IntersectionObserver(entries => {
      visible = entries.some(entry => entry.isIntersecting);
      if (visible) requestRender(); else { cancelFrames(); endDrag(); }
    }, { threshold: 0 });
    intersectionObserver.observe(stage);
    cleanups.push(() => intersectionObserver.disconnect());
  } else {
    listen(win, "scroll", () => { const next = inViewport(); if (next !== visible) { visible = next; if (visible) requestRender(); else { cancelFrames(); endDrag(); } } }, { passive: true });
  }
  try {
    renderer = createRenderer(canvas);
    root.dataset.rxRenderer = "webgl";
    figure.hidden = false;
    list.open = reduced;
    const status = root.querySelector("[data-rx-context-fallback-status]");
    if (status) status.hidden = true;
    visible = inViewport();
  } catch {
    fallback();
  }
  inspect(selected, false);

  function destroy() {
    if (destroyed) return;
    destroyed = true;
    cancelFrames();
    endDrag();
    cleanups.splice(0).forEach(cleanup => cleanup());
    if (renderer) renderer.dispose();
    renderer = null;
    labels.replaceChildren();
    leaders.replaceChildren();
    inspectButtons.forEach(button => { button.hidden = true; button.removeAttribute("aria-controls"); });
    figure.hidden = true;
    list.open = true;
    delete root.dataset.rxRenderer;
    if (!originalInspectorId) inspector.removeAttribute("id");
    scenes.delete(root);
  }
  if (win.MutationObserver && root.isConnected && doc.body) {
    const removalObserver = new win.MutationObserver(() => { if (!root.isConnected) destroy(); });
    removalObserver.observe(doc.body, { childList: true, subtree: true });
    cleanups.push(() => removalObserver.disconnect());
  }
  return { root, inspect, destroy };
}

/** Mount once; returns { root, inspect(id), destroy() }. */
export function mountContextScene(root) {
  if (!root?.matches?.("[data-rx-context-scene]")) return null;
  if (scenes.has(root)) return scenes.get(root);
  const scene = createScene(root);
  if (scene) scenes.set(root, scene);
  return scene;
}

/** Mount every example in a page or container; destroy() releases observers and GPU resources. */
export function mountContextScenes(scope = document) {
  const roots = [...scope.querySelectorAll("[data-rx-context-scene]")];
  if (scope.matches?.("[data-rx-context-scene]")) roots.unshift(scope);
  const mounted = roots.map(mountContextScene).filter(Boolean);
  return { scenes: mounted, destroy() { mounted.forEach(scene => scene.destroy()); } };
}

export function destroyContextScene(root) { scenes.get(root)?.destroy(); }

// A module script works without an application framework; explicit mounts are idempotent.
if (typeof document !== "undefined") {
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => mountContextScenes(document), { once: true });
  else mountContextScenes(document);
}
