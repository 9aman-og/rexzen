/* Rexzen motion. Parameters trace to the coverage ledger; no reference-site code is executed. */
(() => {
  'use strict';
  const root=document.documentElement, gsap=window.gsap, ST=window.ScrollTrigger;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const menu=document.querySelector('#site-directory'),search=document.querySelector('#site-search');
  const enabled=()=>!reduced.matches&&!root.classList.contains('motion-paused');
  let media=null, menuTween=null, menuWasOpen=false, rebuildFrame=null, refreshTimer=null;
  let destroyed=false,searchTween=null,searchWasOpen=false,lastPinAnchor=null,interactionRevision=0;
  const evidenceControllers=[],previewControllers=[];
  const cleanups=[], families=new Set(), splitRecords=new Map(),pinSnapshots=new WeakMap();
  const $$=(selector,parent=document)=>[...parent.querySelectorAll(selector)];
  const arrivalReady=window.RexzenPageTransition?.ready||Promise.resolve();
  const afterArrival=animation=>{arrivalReady.then(()=>{if(enabled()&&root.dataset.motionState==='active')animation.play();else animation.progress(1);});return animation;};
  const refresh=()=>{clearTimeout(refreshTimer);refreshTimer=setTimeout(()=>{if(!destroyed)ST?.refresh();},100);};
  if(gsap&&ST){gsap.registerPlugin(ST);if(window.RoughEase)gsap.registerPlugin(window.RoughEase);ST.config({ignoreMobileResize:true});}

  function splitText(node){
    if(splitRecords.has(node))return $$('.motion-char',node);
    splitRecords.set(node,{html:node.innerHTML,label:node.getAttribute('aria-label')});
    const labelClone=node.cloneNode(true);$$('br',labelClone).forEach(br=>br.replaceWith(document.createTextNode(' ')));node.setAttribute('aria-label',labelClone.textContent.replace(/\s+/g,' ').trim());
    const walker=document.createTreeWalker(node,NodeFilter.SHOW_TEXT);
    const texts=[];while(walker.nextNode())texts.push(walker.currentNode);
    const segmenter=window.Intl?.Segmenter?new Intl.Segmenter(undefined,{granularity:'grapheme'}):null;
    for(const text of texts){
      const fragment=document.createDocumentFragment();
      for(const word of text.textContent.split(/(\s+)/)){
        if(!word)continue;
        if(/^\s+$/.test(word)){fragment.append(document.createTextNode(word));continue;}
        const wrapper=document.createElement('span');wrapper.className='motion-word';wrapper.setAttribute('aria-hidden','true');
        for(const letter of segmenter?[...segmenter.segment(word)].map(x=>x.segment):Array.from(word)){
          const char=document.createElement('span');char.className='motion-char';char.textContent=letter;wrapper.append(char);
        }
        fragment.append(wrapper);
      }
      text.replaceWith(fragment);
    }
    return $$('.motion-char',node);
  }
  function restoreText(){
    for(const [node,record]of splitRecords){node.innerHTML=record.html;if(record.label===null)node.removeAttribute('aria-label');else node.setAttribute('aria-label',record.label);}
    splitRecords.clear();
  }
  function releaseText(node){
    const record=splitRecords.get(node);if(!record)return;
    node.innerHTML=record.html;if(record.label===null)node.removeAttribute('aria-label');else node.setAttribute('aria-label',record.label);
    splitRecords.delete(node);
  }
  function rules(){
    for(const node of $$('.rule-label,.project-row,.steps-grid>li,.statement-list>li,.paper-record,.paper-list>li')){
      let window=node.querySelector(':scope > .rule-window');
      if(!window){window=document.createElement('span');window.className='rule-window';window.setAttribute('aria-hidden','true');const line=document.createElement('span');line.className='motion-rule';window.append(line);node.prepend(window);}
      const line=window.firstElementChild;
      gsap.fromTo(line,{xPercent:-100},{xPercent:0,duration:.4,ease:'power1.out',scrollTrigger:{trigger:node,start:'top 85%',once:true}});
    }
    families.add('PM-003');
  }
  function characters(){
    const nodes=$$('[data-motion-characters]:not(.sr-only),[data-motion-brand],.arc-scene-head h2,.feature-heading h2,.narrative-quote .eyebrow');
    const running=new Map(),visible=new WeakSet();let observer;
    const reveal=node=>{
      if(!enabled()||running.has(node))return;
      const brand=node.hasAttribute('data-motion-brand');
      if(!brand&&node.dataset.motionRevealed==='true')return;
      const chars=splitText(node);if(!chars.length)return;
      node.dataset.textReveal='playing';
      const onArrival=node.getBoundingClientRect().top<innerHeight*.9&&node.closest('main')&&scrollY<innerHeight;
      const finish=()=>{releaseText(node);running.delete(node);node.dataset.textReveal=brand&&!visible.has(node)?'armed':'complete';node.dataset.motionRevealed='true';if(!brand)observer?.unobserve(node);};
      const animation=gsap.fromTo(chars,{opacity:0},{opacity:1,duration:brand ? .5 : .08,stagger:brand?{each:.05,from:'random'}:.027,ease:brand?roughEase():'steps(1)',paused:!!onArrival,onComplete:finish});
      running.set(node,animation);
      if(onArrival)afterArrival(animation);
    };
    if('IntersectionObserver' in window)observer=new IntersectionObserver(entries=>{for(const entry of entries){const node=entry.target;if(entry.isIntersecting){visible.add(node);reveal(node);}else{visible.delete(node);if(node.hasAttribute('data-motion-brand')&&!running.has(node))node.dataset.textReveal='armed';}}},{rootMargin:'0px 0px -8% 0px',threshold:0});
    for(const node of nodes){
      if(node.hasAttribute('data-motion-lines'))continue;
      node.dataset.motionRevealReady='';
      if(node.hasAttribute('data-motion-brand')||node.dataset.motionRevealed!=='true')node.dataset.textReveal='armed';
      if(observer)observer.observe(node);else{visible.add(node);reveal(node);}
    }
    cleanups.push(()=>{observer?.disconnect();for(const [node,animation]of running){animation.kill();releaseText(node);node.dataset.textReveal='complete';}running.clear();});
    families.add('PM-004');
    families.add('RX-GOTHAM-BRAND');
  }
  function callouts(wide){
    for(const node of $$('[data-motion-callout]')){
      gsap.fromTo(node,{y:48,opacity:.4},{y:0,opacity:1,ease:'none',scrollTrigger:{trigger:node,start:'top bottom',end:'center center',scrub:.6,invalidateOnRefresh:true}});
    }
    families.add('PM-002');
  }
  function headerPins(wide){
    if(!wide)return;
    for(const section of $$('[data-motion-pin-header]')){
      section.classList.add('is-pin-enabled');
      const overlay=section.querySelector('.pin-overlay'),base=section.querySelector('.pin-headline-base'),highlight=section.querySelector('.pin-headline-highlight'),footer=section.querySelector('.pin-footer');
      const chars=splitText(base);
      gsap.set(highlight,{yPercent:50,opacity:0,backgroundImage:'linear-gradient(122deg,#202326,#202326)'});
      gsap.set(footer,{yPercent:50,opacity:0});
      const timeline=gsap.timeline({scrollTrigger:{trigger:section,pin:true,start:'top top',end:'+=100%',scrub:1,anticipatePin:1,invalidateOnRefresh:true}});
      timeline.fromTo(overlay,{opacity:1},{opacity:0,duration:.5})
        .fromTo(chars,{opacity:0,yPercent:20},{opacity:1,yPercent:0,duration:.05,stagger:{each:.05}},'>+=0.1')
        .to(highlight,{yPercent:0,opacity:1,duration:.5},'>+=0.3')
        .to(highlight,{backgroundImage:'linear-gradient(122deg,#202326 -100%,#344b8f 20%,#c83b32 150%)',duration:.5})
        .to(footer,{yPercent:0,opacity:1,duration:.5});
      timeline.eventCallback('onUpdate',()=>rememberPin(section,base,timeline.scrollTrigger));
    }
    families.add('PM-006');
  }
  function metadata(){
    for(const node of $$('.product-meta'))gsap.fromTo(node,{y:0,opacity:0},{y:0,opacity:1,ease:'none',scrollTrigger:{trigger:node,scrub:1.5,start:'top bottom-=200',end:'+=200'}});
    families.add('PM-007');
  }
  function lineHeaders(){
    for(const node of $$('[data-motion-lines]')){
      if(!splitRecords.has(node))splitRecords.set(node,{html:node.innerHTML,label:node.getAttribute('aria-label')});
      const original=splitRecords.get(node).html;
      const labelClone=node.cloneNode(true);$$('br',labelClone).forEach(br=>br.replaceWith(document.createTextNode(' ')));node.setAttribute('aria-label',labelClone.textContent.replace(/\s+/g,' ').trim());
      node.innerHTML=original.split(/<br\s*\/?>/i).map(line=>'<span class="motion-line-window" aria-hidden="true"><span class="motion-line">'+line+'</span></span>').join('');
      gsap.fromTo($$('.motion-line',node),{clipPath:'inset(0% 0% 100% 0%)',y:50},{clipPath:'inset(0% 0% 0% 0%)',y:0,stagger:{each:.1},ease:'none',scrollTrigger:{trigger:node.closest('section'),start:'top center+=100px',end:'top top',scrub:1,invalidateOnRefresh:true}});
    }
    for(const section of $$('[data-motion-lines-section]')){const sub=section.querySelector('.actions');if(sub){sub.dataset.motionFocusBlock='';gsap.fromTo(sub,{y:30,opacity:0},{y:0,opacity:1,scrollTrigger:{trigger:sub,start:'center bottom',end:'bottom bottom',scrub:1}});}}
    families.add('PM-014');
  }
  function listWipes(){
    for(const list of $$('[data-motion-list]')){
      const links=$$('a',list),labels=[],masks=[];
      for(const link of links){
        splitRecords.set(link,{html:link.innerHTML,label:link.getAttribute('aria-label')});
        const label=document.createElement('span');label.className='motion-link-label';while(link.firstChild)label.append(link.firstChild);
        const mask=document.createElement('span');mask.className='motion-link-mask';mask.setAttribute('aria-hidden','true');link.append(label,mask);labels.push(label);masks.push(mask);
      }
      gsap.set(labels,{opacity:0});
      gsap.timeline({scrollTrigger:{trigger:list,start:'top 85%',once:true}})
        .to(masks,{xPercent:100,stagger:.3,ease:'sine.out',duration:.7},0)
        .to(labels,{opacity:1,stagger:.25,ease:'sine.out',duration:.15},0)
        .to(masks,{opacity:0,duration:.2,ease:'sine.out'},'>+=1');
    }
    families.add('PM-012');
  }
  function mediaReveals(){
    for(const node of $$('[data-motion-media]')){
      const kind=node.dataset.motionMedia,trigger=node.closest('figure');
      if(kind==='inset')gsap.fromTo(node,{clipPath:'inset(0% 100% 0% 0%)'},{clipPath:'inset(0% 0% 0% 0%)',ease:'none',scrollTrigger:{trigger,start:'center bottom',end:'center center',scrub:true}});
      else if(kind==='slide')gsap.fromTo(node,{clipPath:'inset(10% 22% 75% 21%)'},{clipPath:'inset(0% 0% 0% 0%)',ease:'none',scrollTrigger:{trigger,start:'top center',end:'+=200',scrub:1}});
      else if(kind==='window')gsap.fromTo(node,{clipPath:'inset(15% 35% 15% 35%)'},{clipPath:'inset(0% 0% 0% 0%)',ease:'none',scrollTrigger:{trigger,start:'top center',end:'top top',scrub:1}});
      else gsap.fromTo(node,{clipPath:kind==='reverse'?'polygon(25% 0%,45% 0%,75% 100%,55% 100%)':'polygon(55% 0%,77% 0%,45% 100%,25% 100%)'},{clipPath:'polygon(0% 0%,100% 0%,100% 100%,0% 100%)',ease:'none',scrollTrigger:{trigger,start:'top center',end:'top top',scrub:1}});
      const title=trigger.closest('.photo-spread')?.querySelector('h2');
      if(title)gsap.fromTo(title,{y:60,opacity:0},{y:0,opacity:1,ease:'none',scrollTrigger:{trigger:trigger.closest('section'),start:'top bottom',end:'top top+=200',scrub:1.5}});
    }
    families.add('PM-015');
  }
  function opening(){
    const configure=window.RoughEase?.config||window.RoughEase?.ease?.config;
    const rough=configure?configure({template:gsap.parseEase('circ.out'),strength:4,points:50,taper:'out',randomize:true,clamp:true}):'circ.out';
    for(const node of $$('[data-motion-opening]')){
      const target=node.querySelector('[data-motion-rough]'),chars=target?splitText(target):[],lines=$$('[data-flow-line]',node);
      const timeline=gsap.timeline({scrollTrigger:{trigger:node,start:'top 80%',once:true}});
      timeline.fromTo(lines,{clipPath:'polygon(0% 0%,0% 0%,0% 100%,0% 100%)'},{clipPath:'polygon(0% 0%,100% 0%,100% 100%,0% 100%)',delay:.25,duration:.05,stagger:{each:.05,from:'end'}},0);
      if(chars.length)timeline.fromTo(chars,{opacity:0},{opacity:1,duration:1,ease:rough,stagger:{each:.05,from:'random'}},.15);
    }
    for(const film of $$('.cinema-hero .cover-media'))afterArrival(gsap.fromTo(film,{opacity:0},{opacity:1,duration:.75,ease:'power4.in',paused:true}));
    families.add('PM-008');
  }
  function spotlightStories(wide){
    if(!wide)return;
    for(const section of $$('[data-scroll-story]')){
      section.classList.add('is-stage-pinned');
      const stage=section.querySelector('[data-story-pin]'),copy=$$('[data-story-stage]',section),labels=$$('.scope-stage-labels>span',section),beacons=$$('[data-beacon]',section),spotlight=section.querySelector('[data-spotlight]');
      gsap.set(copy.slice(1),{opacity:0,y:48});gsap.set(beacons.slice(1),{opacity:.2});gsap.set(labels.slice(1),{opacity:.2});
      const polygon=['55,75 335,75 335,455 55,455','355,75 645,75 645,455 355,455','655,75 945,75 945,455 655,455'];
      const coordinates=[[[150,82],[500,82],[850,82]],[[165,95],[500,72],[835,95]],[[180,110],[500,95],[820,72]]];
      const timeline=gsap.timeline({defaults:{ease:'none'},scrollTrigger:{trigger:stage,pin:true,start:'top top',end:'+=375%',scrub:1,anticipatePin:1,invalidateOnRefresh:true}});
      timeline.addLabel('stage-0').to({},{duration:1});
      for(let i=1;i<copy.length;i++){
        const time=timeline.duration();
        timeline.to(copy[i-1],{y:-48,opacity:0,duration:.5},time)
          .to(labels[i-1],{opacity:.2,duration:.5},time)
          .to(spotlight,{attr:{points:polygon[i]},duration:.8},time+.3)
          .to(copy[i],{y:0,opacity:1,duration:.5},time+.3)
          .to(labels[i],{opacity:1,duration:.5},time+.3);
        beacons.forEach((beacon,j)=>timeline.to(beacon,{attr:{cx:coordinates[i][j][0],cy:coordinates[i][j][1]},opacity:j===i?1:.2,duration:.8},time+.3));
        timeline.addLabel('stage-'+i).to({},{duration:1});
      }
      timeline.eventCallback('onUpdate',()=>{const active=timeline.progress()<.34?0:timeline.progress()<.67?1:2;section.dataset.storyStage=String(active);rememberPin(section,copy[active],timeline.scrollTrigger);});
    }
    families.add('PM-009');
  }
  function roughEase(){const configure=window.RoughEase?.config||window.RoughEase?.ease?.config;return configure?configure({template:gsap.parseEase('circ.out'),strength:4,points:50,taper:'out',randomize:true,clamp:true}):'circ.out';}
  function indexedSections(){
    for(const section of $$('[data-indexed-section]')){
      const index=section.querySelector('[data-index-display]'),heading=section.querySelector('[data-index-heading]'),divider=section.querySelector('.index-divider'),body=section.querySelector('.film-heading>p');
      const chars=heading?splitText(heading):[];
      gsap.timeline({scrollTrigger:{trigger:section,start:'top center',end:'top bottom',toggleActions:'play none none reverse'}})
        .fromTo(chars,{opacity:0},{opacity:1,duration:.05,stagger:{each:.05}},0)
        .fromTo(index,{opacity:0},{opacity:1,duration:1,ease:roughEase()},0)
        .fromTo(divider,{xPercent:-100},{xPercent:0,duration:.75},0)
        .fromTo(body,{opacity:0},{opacity:1,duration:.5},.15);
    }
    families.add('PM-010');
  }
  function ctaSections(){
    const section=document.querySelector('.next-step');if(!section)return;
    let edges=section.querySelector('.cta-edges');if(!edges){edges=document.createElement('span');edges.className='cta-edges';edges.setAttribute('aria-hidden','true');section.prepend(edges);}
    const body=$$(':scope>div',section);body.forEach(node=>node.dataset.motionFocusBlock='');
    const timeline=gsap.timeline({scrollTrigger:{trigger:section,start:'top 80%',once:true,toggleActions:'play none none none'}});
    timeline.fromTo(body,{yPercent:15,opacity:0},{yPercent:0,opacity:1,duration:.6,delay:.1,ease:'sine.out'},0)
      .fromTo(section,{'--ctaHeroBorders':'0px'},{'--ctaHeroBorders':'50px',duration:.7,ease:'sine.out'},.4);
    // The source flash is confined to a one-pixel decoration, never the page/text.
    for(const [opacity,duration]of [[.8,.1],[0,.05],[.7,.1],[0,.05],[1,.1]])timeline.to(edges,{opacity,duration,ease:'steps(1)'},'>');
    families.add('PM-011');
  }
  function featureBodies(){
    for(const parent of $$('.spread-copy>div:last-child')){
      const body=[...parent.children];body.forEach(node=>node.dataset.motionFocusBlock='');
      gsap.fromTo(body,{opacity:0,yPercent:10},{opacity:1,yPercent:0,delay:.6,stagger:.3,ease:'sine.out',duration:.5,scrollTrigger:{trigger:parent,start:'top 90%',once:true}});
    }
    families.add('PM-013');
  }
  function assemblies(){
    for(const section of $$('[data-layer-assembly]')){
      const layers=$$('[data-model-layer]',section),step=100/layers.length;
      const timeline=gsap.timeline({scrollTrigger:{trigger:section.querySelector('svg'),start:'top 80%',end:'top 30%',scrub:1,invalidateOnRefresh:true}});
      layers.forEach((layer,i)=>{
        const line=layer.querySelector('[data-layer-line]'),label=layer.querySelector('[data-layer-label]'),length=line.getTotalLength(),part=.7*step;
        timeline.fromTo(layer,{opacity:0,y:15},{opacity:1,y:0,duration:.6*step,ease:'power2.out'},i*step)
          .fromTo(line,{strokeDasharray:length,strokeDashoffset:length},{strokeDashoffset:0,duration:.6*part,ease:'power2.out'},i*step+.2*step)
          .fromTo(label,{x:label.dataset.side==='right'?15:-15,opacity:0},{x:0,opacity:1,duration:.5*part,ease:'power2.out'},i*step+.2*step+.15*part);
      });
    }
    families.add('PM-017');
  }
  function connectorDraws(){
    for(const section of $$('[data-connector-draw]')){
      const timeline=gsap.timeline({scrollTrigger:{trigger:section,start:'top 80%',end:'50% 50%',scrub:1}});
      $$('[data-connector]',section).forEach((line,i)=>timeline.fromTo(line,{'--draw-progress':'0%'},{'--draw-progress':'100%',duration:.8,ease:'power2.inOut'},.08*i));
    }
    families.add('PM-018');
  }
  function opposedLayers(){
    for(const section of $$('[data-opposed-layers]')){
      const layers=[...section.children],timeline=gsap.timeline({scrollTrigger:{trigger:section,start:'top 40%',end:()=>'+='+Math.max(section.offsetHeight-innerHeight*.5,innerHeight*.45),scrub:2,invalidateOnRefresh:true}});
      layers.forEach((node,i)=>timeline.fromTo(node,{opacity:0,x:i===0?-50:i===2?50:0,y:i===1?15:0},{opacity:1,x:0,y:0,duration:36,ease:'power2.out'},45*i));
      if(layers.length<3)timeline.to({},{duration:135-45*layers.length});
    }
    families.add('PM-019');
  }
  function parallax(context){
    const controller=new AbortController();cleanups.push(()=>controller.abort());
    for(const image of $$('[data-motion-parallax]')){
      const setup=()=>{image.classList.add('parallax-bleed');gsap.fromTo(image,{y:()=>-innerHeight*.1},{y:()=>innerHeight*.1,ease:'none',scrollTrigger:{trigger:image.closest('figure'),start:'top bottom',end:'bottom top',scrub:true,invalidateOnRefresh:true}});};
      if(image.complete&&image.naturalWidth)setup();else image.addEventListener('load',()=>context.add(setup),{once:true,signal:controller.signal});
    }
    families.add('PM-020');
  }
  function loopRails(){
    for(const section of $$('[data-theme-rail]')){
      const flow=section.querySelector('.rail-flow'),track=section.querySelector('.rail-track'),button=section.querySelector('[data-rail-pause]'),clone=track.cloneNode(true),controller=new AbortController();
      clone.setAttribute('aria-hidden','true');clone.inert=true;flow.append(clone);section.classList.add('is-rail-loop');
      let visible=false,hover=false;
      const loop=gsap.to(flow,{xPercent:-50,duration:12*track.children.length,ease:'none',repeat:-1,paused:true});
      const sync=()=>{const paused=section.dataset.railPaused==='true';button.textContent=paused?'Play themes':'Pause themes';button.setAttribute('aria-pressed',String(paused));button.disabled=false;if(visible&&!hover&&!document.hidden&&!root.classList.contains('modal-open')&&!paused&&enabled())loop.resume();else loop.pause();};
      const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;sync();});observer.observe(section);
      button.addEventListener('click',()=>{section.dataset.railPaused=String(section.dataset.railPaused!=='true');sync();},{signal:controller.signal});
      section.addEventListener('pointerenter',event=>{if(event.pointerType!=='touch'){hover=true;sync();}},{signal:controller.signal});section.addEventListener('pointerleave',()=>{hover=false;sync();},{signal:controller.signal});
      document.addEventListener('visibilitychange',sync,{signal:controller.signal});document.addEventListener('site-menu-open',sync,{signal:controller.signal});document.addEventListener('site-menu-close',sync,{signal:controller.signal});sync();
      cleanups.push(()=>{controller.abort();observer.disconnect();loop.kill();clone.remove();section.classList.remove('is-rail-loop');button.textContent='Themes are still';button.disabled=true;});
    }
    families.add('PM-022');
  }
  function navVisibility(){
    for(const nav of $$('[data-section-nav]')){
      const first=document.querySelector('#recorded-run'),last=document.querySelector('#release');
      if(first&&last)gsap.fromTo(nav,{opacity:0,xPercent:-100},{opacity:1,xPercent:0,duration:.4,scrollTrigger:{trigger:first,endTrigger:last,start:'top center',end:'bottom bottom-=100',toggleActions:'play reverse play reverse'}});
    }
    families.add('PM-016');
  }
  function menuMotion(){
    if(!menu?.open){menuWasOpen=false;menuTween?.kill();menuTween=null;return;}
    if(menuWasOpen)return;menuWasOpen=true;
    if(!gsap||!enabled()||document.hidden)return;
    const columns=$$('.menu-column',menu), links=$$('.menu-primary a',menu), quick=$$('.menu-quick a',menu);
    menuTween=gsap.timeline({defaults:{overwrite:'auto'}});
    menuTween.fromTo(columns,{opacity:0,yPercent:10},{opacity:1,yPercent:0,duration:.5,stagger:.2,ease:'sine.out'},0)
      .fromTo(links,{opacity:0,yPercent:20},{opacity:1,yPercent:0,duration:.4,stagger:.14,ease:'power1.out'},.06)
      .fromTo(quick,{opacity:0,yPercent:10},{opacity:1,yPercent:0,duration:.3,stagger:.2,ease:'sine.out'},.4);
    families.add('PM-001');
  }
  function clearMenu(){menuTween?.kill();menuTween=null;menuWasOpen=false;if(gsap&&menu)gsap.set($$('.menu-column,.menu-primary a,.menu-quick a',menu),{clearProps:'transform,opacity,visibility'});}
  function headerSurface(){
    const header=document.querySelector('.site-header'),light=document.querySelector('.manifesto,.product-scroll-header,.page-intro');
    if(header&&light)gsap.fromTo(header,{'--header-surface-opacity':0},{'--header-surface-opacity':1,scrollTrigger:{trigger:light,start:'top top',end:'+=100',scrub:1,toggleActions:'play none none reverse'}});
    families.add('PM-027');
  }
  function arrivalCopy(){
    const items=$$('.hero-copy>.eyebrow,.hero-copy>p,.hero-copy>.actions,.page-intro .breadcrumbs,.page-intro>.eyebrow,.page-intro>.lead,.page-intro>p,.arc-hero .arc-scene-head>p').filter(node=>node.getBoundingClientRect().top<innerHeight);
    if(!items.length||scrollY>innerHeight)return;
    items.forEach(node=>node.dataset.motionFocusBlock='');
    afterArrival(gsap.fromTo(items,{opacity:0,yPercent:15,clipPath:'inset(0% 0% 100% 0%)'},{opacity:1,yPercent:0,clipPath:'inset(0% 0% 0% 0%)',duration:.5,delay:.18,stagger:.1,ease:'sine.out',paused:true}));
    families.add('RX-ARRIVAL');
  }
  function searchMotion(){
    if(!search?.open){clearSearch();return;}if(searchWasOpen)return;searchWasOpen=true;
    if(!gsap||!enabled()||document.hidden)return;
    const items=$$('.search-top,.search-label,.search-input,.search-results',search);items.forEach(node=>node.dataset.motionFocusBlock='');
    searchTween=gsap.fromTo(items,{opacity:0,y:'2.2222222222rem'},{opacity:1,y:0,duration:.4,stagger:.1,ease:'power1.out'});families.add('PM-028');
  }
  function clearSearch(){searchTween?.kill();searchTween=null;searchWasOpen=false;if(gsap&&search)gsap.set($$('.search-top,.search-label,.search-input,.search-results',search),{clearProps:'transform,opacity'});}
  function rememberPin(section,target,knownTrigger){
    if(!enabled())return;
    const trigger=knownTrigger?.isActive?knownTrigger:null;
    if(trigger&&target){pinSnapshots.set(section,trigger.progress);lastPinAnchor={section,target,top:target.getBoundingClientRect().top,progress:trigger.progress,hash:location.hash,revision:interactionRevision};}
    else if(lastPinAnchor?.section===section)lastPinAnchor=null;
  }
  function restorePinAnchor(anchor){
    root.dataset.motionAnchor=anchor?'queued:'+anchor.top:'none';
    if(!anchor)return;let attempts=4;
    const settle=()=>{
      if(!anchor.target.isConnected||anchor.hash!==location.hash||anchor.revision!==interactionRevision){root.dataset.motionAnchor='stale';return;}
      const delta=anchor.target.getBoundingClientRect().top-anchor.top;
      if(Math.abs(delta)>1){const position=Math.max(0,scrollY+delta);if(ST){ST.getScrollFunc(window)(position);ST.clearScrollMemory();ST.update();}else window.scrollTo({top:position,behavior:'auto'});}
      if(--attempts&&Math.abs(delta)>1)requestAnimationFrame(settle);else root.dataset.motionAnchor='restored';
    };
    requestAnimationFrame(()=>{
      if(!anchor.target.isConnected||anchor.hash!==location.hash||anchor.revision!==interactionRevision){root.dataset.motionAnchor='stale';return;}
      ST?.refresh();
      const pin=ST?.getAll().find(item=>item.pin&&(item.trigger===anchor.section||anchor.section.contains(item.trigger)));
      if(pin&&Number.isFinite(anchor.progress)&&anchor.revision===interactionRevision){
        ST.getScrollFunc(window)(pin.start+(pin.end-pin.start)*anchor.progress);ST.clearScrollMemory();ST.update();pin.animation?.progress(anchor.progress);pin.getTween()?.progress(1);root.dataset.motionAnchor='restored';
      }else settle();
    });
  }
  function capturePinAnchor(){
    const trigger=ST?.getAll().find(item=>item.isActive&&item.pin);
    const section=trigger?.trigger.closest('[data-motion-pin-header],[data-scroll-story]')||document.activeElement?.closest?.('[data-motion-pin-header],[data-scroll-story]');if(!section)return null;
    const target=section.querySelector('.pin-headline-base')||$$('.scope-copy [data-story-stage]',section)[Number(section.dataset.storyStage)||0];
    if(!target)return null;const bounds=target.getBoundingClientRect();
    if(trigger)pinSnapshots.set(section,trigger.progress);
    return bounds.bottom>0&&bounds.top<innerHeight?{section,target,top:bounds.top,progress:trigger?.progress??pinSnapshots.get(section),hash:location.hash,revision:interactionRevision}:null;
  }
  function rebuild(){
    rebuildFrame=null;if(destroyed)return;
    const anchor=capturePinAnchor()||lastPinAnchor;lastPinAnchor=null;media?.revert();media=null;restoreText();clearMenu();clearSearch();
    $$('[data-motion-pin-header]').forEach(node=>node.classList.remove('is-pin-enabled'));
    families.clear();root.dataset.motionState='static';$$('[data-rail-pause]').forEach(button=>{button.textContent='Themes are still';button.disabled=true;});
    if(!gsap||!ST){root.dataset.motionLibrary='unavailable';return;}
    root.dataset.motionLibrary=`gsap-${gsap.version}`;
    media=gsap.matchMedia();
    media.add({all:'all',wide:'(min-width: 1000px)',reduced:'(prefers-reduced-motion: reduce)'},context=>{
      if(context.conditions.reduced||!enabled())return;
      root.dataset.motionState='active';
      rules();characters();arrivalCopy();callouts(context.conditions.wide);lineHeaders();metadata();listWipes();mediaReveals();opening();headerPins(context.conditions.wide);spotlightStories(context.conditions.wide);indexedSections();ctaSections();featureBodies();assemblies();connectorDraws();opposedLayers();parallax(context);loopRails();navVisibility();headerSurface();families.add('PM-021');families.add('PM-005');menuMotion();searchMotion();
      return ()=>{cleanups.splice(0).forEach(clean=>clean());$$('.parallax-bleed').forEach(node=>node.classList.remove('parallax-bleed'));$$('[data-scroll-story]').forEach(node=>{node.classList.remove('is-stage-pinned');delete node.dataset.storyStage;});restoreText();$$('[data-motion-pin-header]').forEach(node=>{node.classList.remove('is-pin-enabled');node.querySelector('.hero-copy')?.removeAttribute('inert');});};
    });
    refresh();restorePinAnchor(anchor);
  }
  function scheduleRebuild(){if(rebuildFrame===null)rebuildFrame=requestAnimationFrame(rebuild);}

  // Actual eight-second progression, with manual selection and independent pause.
  const carousels=$$('[data-feature-player]').map(player=>{
    const tabs=$$('[role=tab]',player),panels=$$('[role=tabpanel]',player),button=player.querySelector('[data-feature-playback]'),status=player.querySelector('[data-feature-status]');
    let index=0,localPaused=false,inView=false,hover=false,timer=null,transition=null;
    const controller=new AbortController(), signal=controller.signal;
    const active=()=>enabled()&&!localPaused&&!document.hidden&&!root.classList.contains('modal-open')&&inView&&!hover&&!player.contains(document.activeElement);
    function reflect(){
      if(!button)return;const stopped=localPaused||!enabled();button.disabled=!enabled();button.textContent=!enabled()?'Stories paused':localPaused?'Play stories':'Pause stories';button.setAttribute('aria-pressed',String(stopped));
      status?.setAttribute('aria-live',active()?'off':'polite');
      if(timer){if(active())timer.resume();else timer.pause();}
    }
    function begin(){
      timer?.kill();timer=null;
      if(gsap){gsap.set($$('.feature-progress',player),{scaleX:0});timer=gsap.to(tabs[index].querySelector('.feature-progress'),{scaleX:1,duration:8,ease:'none',paused:true,onComplete:()=>select((index+1)%tabs.length,false)});}
      reflect();
    }
    function select(next,focus=false){
      index=(next+tabs.length)%tabs.length;
      tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;panels[i].hidden=i!==index;});
      if(status)status.textContent=`Feature ${index+1} of ${tabs.length}: ${tabs[index].textContent.trim()}`;
      transition?.kill();
      if(gsap&&enabled())transition=gsap.fromTo($$('.feature-art,.feature-story-copy>*',panels[index]),{opacity:0,y:24},{opacity:1,y:0,duration:.5,stagger:.07,ease:'power1.out',clearProps:'transform,opacity'});
      if(focus)tabs[index].focus({preventScroll:true});begin();refresh();
    }
    tabs.forEach((tab,i)=>tab.addEventListener('click',()=>select(i),{signal}));
    player.querySelector('[role=tablist]')?.addEventListener('keydown',event=>{
      let next=null;if(event.key==='ArrowRight')next=index+1;if(event.key==='ArrowLeft')next=index-1;if(event.key==='Home')next=0;if(event.key==='End')next=tabs.length-1;
      if(next!==null){event.preventDefault();select(next,true);}
    },{signal});
    button?.addEventListener('click',()=>{localPaused=!localPaused;reflect();},{signal});
    player.addEventListener('pointerenter',event=>{if(event.pointerType!=='touch'&&matchMedia('(hover:hover)').matches){hover=true;reflect();}},{signal});
    player.addEventListener('pointerleave',()=>{hover=false;reflect();},{signal});
    player.addEventListener('focusin',reflect,{signal});player.addEventListener('focusout',()=>queueMicrotask(reflect),{signal});
    const observer=new IntersectionObserver(entries=>{inView=entries[0].isIntersecting&&entries[0].intersectionRatio>.3;reflect();},{threshold:[0,.3]});observer.observe(player);
    begin();
    return {sync:()=>{if(!enabled()){transition?.progress(1);timer?.pause();}reflect();},destroy:()=>{controller.abort();observer.disconnect();timer?.kill();transition?.kill();}};
  });
  for(const group of $$('[data-evidence-tabs]')){
    const tabs=$$('[role=tab]',group),panels=$$('[role=tabpanel]',group),mask=group.querySelector('.tab-panel-mask');let selected=0,transition=null;
    tabs.forEach(tab=>{const pip=document.createElement('span');pip.className='tab-selection-pip';pip.setAttribute('aria-hidden','true');tab.append(pip);});
    const display=()=>{tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===selected));tab.tabIndex=i===selected?0:-1;panels[i].hidden=i!==selected;if(i!==selected)$$('video',panels[i]).forEach(video=>video.pause());});};
    const finish=()=>{transition?.progress(1).kill();transition=null;display();if(gsap){gsap.set(mask,{x:0,xPercent:100});gsap.set(panels,{opacity:1});}};
    const select=(index,focus=false)=>{
      transition?.progress(1).kill();selected=(index+tabs.length)%tabs.length;
      if(focus)tabs[selected].focus({preventScroll:true});
      if(!gsap||!enabled()){finish();refresh();return;}
      const panel=panels[selected];gsap.set(mask,{x:0,xPercent:100});
      transition=gsap.timeline({onComplete:refresh}).to(mask,{xPercent:0,duration:.25})
        .call(display).fromTo(panel,{opacity:0},{opacity:0,duration:.15,immediateRender:false})
        .to(mask,{xPercent:-100,duration:.25}).to(panel,{opacity:1,duration:.25});
      gsap.fromTo(tabs[selected].querySelector('.tab-selection-pip'),{opacity:0},{opacity:1,duration:.5,ease:roughEase()});
    };
    tabs.forEach((tab,i)=>tab.addEventListener('click',()=>select(i)));
    group.querySelector('[role=tablist]').addEventListener('keydown',event=>{let target=null;if(event.key==='ArrowRight')target=selected+1;if(event.key==='ArrowLeft')target=selected-1;if(event.key==='Home')target=0;if(event.key==='End')target=tabs.length-1;if(target!==null){event.preventDefault();select(target,true);}});
    evidenceControllers.push({sync:()=>{if(!enabled()||document.hidden)finish();},finish});
  }
  for(const nav of $$('[data-section-nav]')){
    const links=$$('a[href^="#"]',nav),sections=links.map(link=>document.getElementById(link.hash.slice(1)));let scheduled=false;
    const update=()=>{scheduled=false;const cutoff=(document.querySelector('.site-header')?.getBoundingClientRect().bottom||80)+130;let active=0;sections.forEach((node,i)=>{if(node&&node.getBoundingClientRect().top<=cutoff)active=i;});links.forEach((link,i)=>{link.classList.toggle('is-active',i===active);if(i===active)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});};
    window.addEventListener('scroll',()=>{if(!scheduled){scheduled=true;requestAnimationFrame(update);}},{passive:true});window.addEventListener('resize',update,{passive:true});update();
  }
  const previewWide=matchMedia('(min-width:1500px)');
  for(const row of $$('.project-row')){
    const video=row.querySelector('[data-product-preview]');let pointer=false,focused=false,visible=true,requested=false;
    const wanted=()=>!!(video&&enabled()&&previewWide.matches&&(pointer||focused)&&visible&&!document.hidden&&!root.classList.contains('modal-open'));
    async function sync(){
      row.dataset.active=String(pointer||focused);
      if(!wanted()){requested=false;video?.pause();row.dataset.previewPlaying='false';return;}
      if(requested)return;requested=true;
      if(!video.hasAttribute('src')){video.src=video.dataset.src;video.load();}try{video.currentTime=0;}catch{}
      try{await video.play();if(wanted())row.dataset.previewPlaying='true';else video.pause();}catch{requested=false;row.dataset.previewPlaying='false';}
    }
    row.addEventListener('pointerenter',event=>{if(event.pointerType!=='touch'){pointer=true;sync();}});row.addEventListener('pointerleave',()=>{pointer=false;sync();});
    row.addEventListener('focusin',()=>{focused=true;sync();});row.addEventListener('focusout',()=>queueMicrotask(()=>{focused=row.contains(document.activeElement);sync();}));
    const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;sync();});observer.observe(row);previewWide.addEventListener('change',sync);previewControllers.push({sync});
  }
  search?.querySelector('input')?.addEventListener('input',event=>search.classList.toggle('is-searching',!!event.target.value.trim()));
  const countInteraction=()=>interactionRevision++;
  window.addEventListener('wheel',countInteraction,{passive:true});window.addEventListener('touchmove',countInteraction,{passive:true});window.addEventListener('keydown',countInteraction);
  window.addEventListener('resize',()=>{const anchor=lastPinAnchor;if(anchor){lastPinAnchor=null;restorePinAnchor(anchor);}},{passive:true});
  function syncCarousels(){carousels.forEach(carousel=>carousel.sync());evidenceControllers.forEach(controller=>controller.sync());previewControllers.forEach(controller=>controller.sync());}
  document.addEventListener('rexzen-motion-change',()=>{syncCarousels();scheduleRebuild();});
  document.addEventListener('site-menu-open',()=>{menuMotion();searchMotion();syncCarousels();});
  document.addEventListener('site-menu-close',()=>{if(!menu?.open)clearMenu();if(!search?.open)clearSearch();syncCarousels();});
  reduced.addEventListener('change',()=>{syncCarousels();scheduleRebuild();});
  document.addEventListener('visibilitychange',()=>{syncCarousels();if(document.hidden){menuTween?.pause();searchTween?.pause();}else{menuTween?.resume();searchTween?.resume();}});
  document.addEventListener('focusin',event=>{
    if(!gsap)return;
    for(let parent=event.target;parent;parent=parent.parentElement){if(parent.hasAttribute?.('data-motion-focus-block')){gsap.killTweensOf(parent);gsap.set(parent,{opacity:1,yPercent:0,y:0,clipPath:'none'});}}
    const column=event.target.closest?.('.menu-column');if(column){gsap.killTweensOf(column);gsap.set(column,{opacity:1,yPercent:0});}
    const chapter=event.target.closest?.('.chapter-nav');if(chapter){gsap.killTweensOf(chapter);gsap.set(chapter,{opacity:1,xPercent:0});}
    const meta=event.target.closest?.('.product-meta');if(meta){gsap.killTweensOf(meta);gsap.set(meta,{opacity:1,y:0});}
    const wipe=event.target.closest?.('[data-motion-list] a');if(wipe){const label=wipe.querySelector('.motion-link-label'),mask=wipe.querySelector('.motion-link-mask');if(label){gsap.killTweensOf([label,mask]);gsap.set(label,{opacity:1});gsap.set(mask,{xPercent:100,opacity:0});}}
    if(menu?.contains(event.target)){gsap.killTweensOf(event.target);gsap.set(event.target,{opacity:1,yPercent:0});}
  });
  document.fonts?.ready.then(refresh);
  window.addEventListener('load',refresh,{once:true});
  window.addEventListener('pagehide',()=>{media?.revert();restoreText();clearMenu();clearSearch();carousels.forEach(c=>c.sync());evidenceControllers.forEach(c=>c.finish());});
  window.addEventListener('pageshow',event=>{if(event.persisted)scheduleRebuild();});
  window.RexzenMotion=Object.freeze({version:'rea-motion-33-v1',diagnostics:()=>({library:gsap?.version||null,state:root.dataset.motionState,registeredScrollFamilies:[...families],scrollTriggers:ST?.getAll().length||0,pinnedHeaders:$$('.is-pin-enabled').length,carouselCount:carousels.length,reduced:reduced.matches,paused:root.classList.contains('motion-paused')})});
  rebuild();
})();
