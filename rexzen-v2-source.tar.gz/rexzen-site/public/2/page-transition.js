/* A native-document adaptation of the reference's rotating gray page wipe. */
(() => {
  'use strict';
  const root=document.documentElement,key='rexzen.page-transition';
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const routes=new Set(['/2/','/2/projects','/2/focus','/2/rex-wm','/2/2piarc','/2/eos','/2/research','/2/about','/2/privacy','/2/aman-agarwal']);
  let complete,arrivalFinished=false,navigating=false,timeline=null,watchdog=null,destination=null,readyWatchdog=null;
  const ready=new Promise(resolve=>complete=resolve);
  const allowed=()=>!reduced.matches&&!root.classList.contains('motion-paused')&&!document.hidden;
  const marker=()=>{try{return JSON.parse(sessionStorage.getItem(key)||'null');}catch{return null;}};
  const forget=()=>{try{sessionStorage.removeItem(key);}catch{}};
  const stored=marker();
  let userPaused=false;try{userPaused=sessionStorage.getItem('rexzen.motion-paused')==='true';}catch{}
  const arriving=!!(stored&&stored.url===location.pathname+location.search+location.hash&&Date.now()-stored.at<8000&&!reduced.matches&&!userPaused);
  forget();
  if(!reduced.matches&&!userPaused)root.dataset.pageArrival='pending';
  if(arriving)root.dataset.navigationPhase='arriving';
  function finishArrival(){
    if(arrivalFinished)return;arrivalFinished=true;clearTimeout(readyWatchdog);delete root.dataset.navigationPhase;
    root.dataset.pageArrival='complete';complete();document.dispatchEvent(new Event('rexzen-page-arrived'));
  }
  // A failed/blocked animation dependency always leaves an ordinary readable page.
  readyWatchdog=setTimeout(finishArrival,1800);
  function elements(){return {overlay:document.querySelector('.page-transition'),logo:document.querySelector('.page-transition-logo')};}
  function reset(){
    clearTimeout(watchdog);timeline?.kill();timeline=null;navigating=false;destination=null;delete root.dataset.navigationPhase;
    const {overlay,logo}=elements();if(window.gsap&&overlay)window.gsap.set(overlay,{'--gray-wipe-x':'-110%','--wipe-rotate':'28deg'});
    if(logo)logo.style.opacity='0';
  }
  function reveal(){
    const {overlay,logo}=elements(),gsap=window.gsap;
    if(!arriving||!allowed()||!overlay||!gsap){finishArrival();return;}
    root.dataset.navigationPhase='arriving';
    timeline=gsap.timeline({onComplete:()=>{reset();finishArrival();}})
      .set(logo,{opacity:0})
      .set(overlay,{'--wipe-rotate':'6deg','--gray-wipe-x':'5%'})
      .to(overlay,{'--gray-wipe-x':'60%',duration:.4,ease:'sine.out'})
      .to(overlay,{'--wipe-rotate':'0deg',duration:.3,ease:'power1.in'},'-=.2');
  }
  function commit(){
    if(!navigating||!destination)return;
    const url=destination;try{sessionStorage.setItem(key,JSON.stringify({url:url.pathname+url.search+url.hash,at:Date.now()}));}catch{}
    location.assign(url.href);
  }
  function depart(url){
    const {overlay,logo}=elements(),gsap=window.gsap;
    if(!overlay||!gsap||!allowed()){location.assign(url.href);return;}
    navigating=true;destination=url;root.dataset.navigationPhase='departing';
    // Native navigation remains the fallback if the ticker or page is suspended.
    watchdog=setTimeout(commit,1200);
    timeline=gsap.timeline({onComplete:commit})
      .set(overlay,{'--gray-wipe-x':'-110%','--wipe-rotate':'28deg'})
      .to(overlay,{'--gray-wipe-x':'-50%',duration:.3,ease:'sine.out'},0)
      .to(overlay,{'--wipe-rotate':'0deg',duration:.2,ease:'power1.in'},.1)
      .set(logo,{opacity:0},.1)
      .to(logo,{opacity:.8,duration:.1,ease:'steps(1)'},.1)
      .to(logo,{opacity:.2,duration:.1,ease:'steps(1)'},.2)
      .to(logo,{opacity:1,duration:.1,ease:'steps(1)'},.3)
      .set(logo,{opacity:0},.4)
      .to({},{duration:.15},.4);
  }
  document.addEventListener('DOMContentLoaded',()=>{
    reveal();
    document.addEventListener('click',event=>{
      const link=event.target.closest?.('a[href]');
      if(!link||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||link.hasAttribute('download')||link.target&&link.target!=='_self')return;
      const url=new URL(link.href,location.href);
      if(url.origin!==location.origin||!routes.has(url.pathname)||url.pathname===location.pathname&&url.search===location.search||!allowed()||!window.gsap)return;
      event.preventDefault();if(navigating)return;depart(url);
    });
  },{once:true});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&navigating){forget();reset();}});
  const motionChanged=()=>{if(allowed())return;if(navigating)commit();else{timeline?.kill();reset();finishArrival();}};
  reduced.addEventListener('change',motionChanged);document.addEventListener('rexzen-motion-change',motionChanged);
  window.addEventListener('pageshow',event=>{if(event.persisted){reset();finishArrival();}});
  window.addEventListener('pagehide',reset);
  window.RexzenPageTransition=Object.freeze({ready,diagnostics:()=>({phase:root.dataset.navigationPhase||'idle',arriving,arrivalFinished,navigating})});
})();
