(() => {
  'use strict';
  const root=document.documentElement;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const header=document.querySelector('.site-header');
  const announcement=document.querySelector('.announcement');
  const hero=document.querySelector('.cinema-hero');
  const menu=document.querySelector('#site-directory');
  const search=document.querySelector('#site-search');
  const dialogs=[...document.querySelectorAll('dialog')];
  const menuButtons=[...document.querySelectorAll('.nav-toggle')];
  const searchButtons=[...document.querySelectorAll('[data-search-open]')];
  const motionButtons=[...document.querySelectorAll('[data-motion-toggle]')];
  const videos=[...document.querySelectorAll('video[data-ambient]')];
  const mediaQuery=matchMedia('(max-width:768px)');
  const chromeQuery=matchMedia('(max-width:760px)');
  const videoVisibility=new Map();
  const pendingVideos=new WeakMap();
  let paused=false,frame=null,menuReturn=null,searchReturn=null;
  let heroBottom=0,announcementHeight=0,lastOffset=-1,lastScrolled=null,lastChrome=-1;
  try{paused=sessionStorage.getItem('rexzen.motion-paused')==='true';}catch{}
  function usableControl(node){
    if(!node?.isConnected||!node.getClientRects().length||node.matches(':disabled,[aria-disabled="true"]')||node.closest('[hidden],[inert]'))return false;
    const style=getComputedStyle(node);
    return style.visibility!=='hidden'&&style.visibility!=='collapse'&&style.display!=='none';
  }
  const visibleControl=buttons=>buttons.find(button=>usableControl(button)&&!button.closest('dialog'));
  const returnFocus=(preferred,buttons)=>(usableControl(preferred)?preferred:visibleControl(buttons))?.focus({preventScroll:true});
  const allowedMotion=()=>!paused&&!reduced.matches&&!document.hidden&&!root.classList.contains('modal-open');

  document.querySelectorAll('[data-current-year]').forEach(node=>node.textContent=String(new Date().getFullYear()));
  document.querySelectorAll('a[href]').forEach(link=>{
    const url=new URL(link.href);
    if(url.origin===location.origin&&url.pathname===location.pathname&&!url.hash)link.setAttribute('aria-current','page');
  });
  function syncScroll(){
    frame=null;if(!header)return;
    const offset=Math.max(0,announcementHeight-scrollY);
    const scrolled=scrollY>(hero?heroBottom:100);
    if(offset!==lastOffset){header.style.setProperty('--announcement-offset',`${offset}px`);lastOffset=offset;}
    if(scrolled!==lastScrolled){header.classList.toggle('is-scrolled',scrolled);lastScrolled=scrolled;}
    if(offset!==lastChrome){root.style.setProperty('--chrome-bottom',`${Math.ceil(header.offsetHeight+offset+(chromeQuery.matches?8:14))}px`);lastChrome=offset;}
  }
  function measureChrome(){announcementHeight=announcement?.offsetHeight||0;heroBottom=hero?Math.max(80,hero.offsetHeight-120):100;lastChrome=-1;scheduleScroll();}
  function scheduleScroll(){if(frame===null)frame=requestAnimationFrame(syncScroll);}
  window.addEventListener('scroll',scheduleScroll,{passive:true});window.addEventListener('resize',measureChrome,{passive:true});
  if('ResizeObserver' in window){const observer=new ResizeObserver(measureChrome);if(header)observer.observe(header);if(announcement)observer.observe(announcement);if(hero)observer.observe(hero);}
  measureChrome();
  syncScroll();

  function pauseVideos(){videos.forEach(video=>video.pause());}
  function wantsVideo(video){return allowedMotion()&&videoVisibility.get(video)&&!video.closest('[hidden]');}
  function playVisibleVideo(){
    if(!allowedMotion()){pauseVideos();return;}
    for(const video of videos){
      if(!wantsVideo(video)){video.pause();continue;}
      if(!video.paused||pendingVideos.has(video))continue;
      if(!video.getAttribute('src')){video.muted=true;video.src=mediaQuery.matches&&video.dataset.srcMobile?video.dataset.srcMobile:video.dataset.src;video.load();}
      const attempt={};pendingVideos.set(video,attempt);
      video.play().then(()=>{if(!wantsVideo(video))video.pause();}).catch(error=>{if(error.name!=='AbortError')video.closest('[data-media-scene]')?.setAttribute('data-media-state','poster');}).finally(()=>{if(pendingVideos.get(video)===attempt)pendingVideos.delete(video);});
    }
  }
  function responsivePosters(){
    for(const video of videos){
      if(!video.dataset.desktopPoster)video.dataset.desktopPoster=video.getAttribute('poster')||'';
      video.poster=mediaQuery.matches&&video.dataset.posterMobile?video.dataset.posterMobile:video.dataset.desktopPoster;
    }
  }
  mediaQuery.addEventListener('change',()=>{
    responsivePosters();
    for(const video of videos){if(video.dataset.srcMobile&&video.hasAttribute('src')){pendingVideos.delete(video);video.pause();video.removeAttribute('src');video.load();}}
    playVisibleVideo();
  });
  responsivePosters();
  function syncMotion(){
    const stopped=paused||reduced.matches;
    root.classList.toggle('motion-paused',stopped);
    motionButtons.forEach(button=>{
      button.disabled=reduced.matches;
      button.textContent=reduced.matches?'Motion reduced by system':stopped?'Enable motion':'Reduce motion';
      button.setAttribute('aria-label',reduced.matches?'Motion reduced by your system preference':stopped?'Enable page motion':'Reduce page motion');
      button.setAttribute('aria-pressed',String(stopped));
    });
    if(stopped)document.getAnimations().forEach(animation=>{const timing=animation.effect?.getTiming?.();if(timing&&timing.iterations!==Infinity)animation.finish();});
    document.dispatchEvent(new CustomEvent('rexzen-motion-change',{detail:{paused:stopped}}));
    playVisibleVideo();
  }
  motionButtons.forEach(button=>button.addEventListener('click',()=>{paused=!paused;try{sessionStorage.setItem('rexzen.motion-paused',String(paused));}catch{}syncMotion();}));
  reduced.addEventListener('change',syncMotion);
  if('IntersectionObserver' in window){
    const observer=new IntersectionObserver(entries=>{for(const entry of entries)videoVisibility.set(entry.target,entry.isIntersecting&&entry.intersectionRatio>0);playVisibleVideo();},{threshold:[0,.01]});
    videos.forEach(video=>observer.observe(video));
    const footerDot=document.querySelector('.footer-dot');
    if(footerDot){
      const dotObserver=new IntersectionObserver(entries=>{footerDot.classList.toggle('is-visible',entries[0].isIntersecting);});
      dotObserver.observe(footerDot);
    }
  }
  syncMotion();

  // Native modal focus can land on the dialog or browser chrome at a boundary.
  // Keep both Tab directions inside the currently focused, visible modal.
  const focusSelector='a[href],area[href],button,input:not([type="hidden"]),select,textarea,iframe,summary,[tabindex],[contenteditable="true"]';
  function dialogControls(dialog){
    return [...dialog.querySelectorAll(focusSelector)]
      .filter(node=>usableControl(node)&&(node.tabIndex>=0||node.isContentEditable))
      .map((node,index)=>({node,index,order:node.tabIndex>0?node.tabIndex:Infinity}))
      .sort((a,b)=>a.order-b.order||a.index-b.index).map(item=>item.node);
  }
  document.addEventListener('keydown',event=>{
    if(event.key!=='Tab'||event.defaultPrevented||event.ctrlKey||event.metaKey||event.altKey)return;
    const active=document.activeElement;
    const dialog=active?.closest?.('dialog[open]')||dialogs.filter(item=>item.open).at(-1);
    if(!dialog)return;
    const controls=dialogControls(dialog);
    if(!controls.length){event.preventDefault();dialog.focus({preventScroll:true});return;}
    const index=controls.indexOf(active);
    if(index<0||(event.shiftKey&&index===0)||(!event.shiftKey&&index===controls.length-1)){
      event.preventDefault();controls[event.shiftKey?controls.length-1:0].focus();
    }
  },true);

  function syncModalState(){
    const active=dialogs.some(dialog=>dialog.open);
    root.classList.toggle('modal-open',active);root.classList.toggle('page-sleeping',document.hidden||active);
    menuButtons.forEach(button=>button.setAttribute('aria-expanded',String(!!menu?.open)));
    searchButtons.forEach(button=>button.setAttribute('aria-expanded',String(!!search?.open)));
    document.dispatchEvent(new Event(active?'site-menu-open':'site-menu-close'));playVisibleVideo();
  }
  function openMenu(){
    if(!menu?.showModal)return;
    if(search?.open)search.close();menuReturn=document.activeElement;
    menu.showModal();menu.scrollTop=0;syncModalState();menu.querySelector('[data-menu-close]')?.focus({preventScroll:true});
  }
  function closeMenu(restore=true){
    if(!menu?.open)return;menu.close();syncModalState();
    if(restore)returnFocus(menuReturn,menuButtons);
  }
  function openSearch(){
    if(!search?.showModal)return;searchReturn=menu?.open?(menuReturn?.isConnected?menuReturn:visibleControl(menuButtons)):document.activeElement;
    closeMenu(false);search.showModal();syncModalState();search.querySelector('input')?.focus({preventScroll:true});
  }
  function closeSearch(restore=true){
    if(!search?.open)return;search.close();syncModalState();
    if(restore)returnFocus(searchReturn,searchButtons);
  }
  menuButtons.forEach(button=>button.addEventListener('click',openMenu));
  searchButtons.forEach(button=>button.addEventListener('click',openSearch));
  document.querySelector('[data-menu-close]')?.addEventListener('click',()=>closeMenu());
  document.querySelector('[data-search-close]')?.addEventListener('click',()=>closeSearch());
  menu?.addEventListener('cancel',event=>{event.preventDefault();closeMenu();});search?.addEventListener('cancel',event=>{event.preventDefault();closeSearch();});
  menu?.addEventListener('close',syncModalState);search?.addEventListener('close',syncModalState);
  const dialogObserver=new MutationObserver(syncModalState);
  dialogs.forEach(dialog=>dialogObserver.observe(dialog,{attributes:true,attributeFilter:['open']}));
  for(const dialog of [menu,search])dialog?.addEventListener('click',event=>{
    const link=event.target.closest?.('a[href]');
    if(link&&event.button===0&&!event.metaKey&&!event.ctrlKey&&!event.shiftKey&&!event.altKey&&!link.target){if(dialog===menu)closeMenu(false);else closeSearch(false);}
  });
  search?.addEventListener('click',event=>{if(event.target!==search)return;const r=search.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeSearch();});
  const searchInput=search?.querySelector('input');
  const results=[...search?.querySelectorAll('[data-search-result]')||[]];
  searchInput?.addEventListener('input',()=>{
    const query=searchInput.value.trim().toLocaleLowerCase();let count=0;
    results.forEach(result=>{result.hidden=query&&!`${result.textContent} ${result.dataset.searchKeywords||''}`.toLocaleLowerCase().includes(query);if(!result.hidden)count++;});
    const empty=search.querySelector('[data-search-empty]');if(empty)empty.hidden=count>0;
    search.querySelector('[data-search-status]').textContent=`${count} ${count===1?'page':'pages'} found`;
  });
  searchInput?.addEventListener('keydown',event=>{
    const first=results.find(result=>!result.hidden)?.querySelector('a');
    if(event.key==='ArrowDown'&&first){event.preventDefault();first.focus();}
    if(event.key==='Enter'&&searchInput.value.trim()&&first){event.preventDefault();first.click();}
  });
  document.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'&&!/input|textarea|select/i.test(event.target?.tagName||'')){event.preventDefault();openSearch();}});
  document.addEventListener('click',event=>{const link=event.target.closest?.('a[href]');if(link&&new URL(link.href).origin===location.origin&&new URL(link.href).pathname!==location.pathname&&event.button===0&&!event.metaKey&&!event.ctrlKey)document.dispatchEvent(new Event('site-navigation-start'));});
  window.addEventListener('pagehide',()=>{pauseVideos();if(menu?.open)menu.close();if(search?.open)search.close();root.classList.remove('modal-open');});
  window.addEventListener('pageshow',()=>{syncModalState();scheduleScroll();});
  document.addEventListener('visibilitychange',()=>{root.classList.toggle('page-sleeping',document.hidden||root.classList.contains('modal-open'));playVisibleVideo();});

  document.addEventListener('focusin',event=>document.getAnimations().forEach(animation=>{if(animation.effect?.target?.contains(event.target)&&animation.effect.getTiming().iterations!==Infinity)animation.finish();}));
})();
