(() => {
  'use strict';
  const scene = document.querySelector('[data-character-scene]');
  if (!scene) return;
  const canvas = scene.querySelector('canvas');
  const seat = scene.querySelector('.character-seat');
  const stage = scene.querySelector('.character-banner') || scene;
  const ctx = canvas?.getContext('2d');
  if (!ctx) return;
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const glyphs = ' .,:;ixtfLCO08#@';
  const colors = ['#1e2124','#25303b','#344353','#46566a','#576a7d','#697d90','#7c8fa0','#8b9caa',
    '#101d3f','#182a59','#213878','#29459e','#3051bf','#2747e7','#4164cd','#5c78d0'];
  const backdrop = document.createElement('canvas');
  let data = null, pending = false, inView = false, frame = null;
  let w = 0, h = 0, dpr = 1, ux = 0, uy = 0, x0 = 0, y0 = 0, stride = 1;
  let elapsed = 0, lastTime = 0, lastDraw = 0, resizeFrame = null, paper = '#f4f4f1';
  const allowed = () => !preference.matches;
  const eligible = () => data && inView && allowed() && !document.hidden &&
    !document.documentElement.classList.contains('directory-open');

  function stop() {
    if (frame !== null) cancelAnimationFrame(frame);
    frame = null; lastTime = 0;
    if (data) scene.dataset.characterState = allowed() ? 'resting' : 'still';
  }
  function drawCell(target, value, col, row, dx = 0, dy = 0) {
    target.fillText(glyphs[value & 15], x0 + (col + .5) * ux + dx, y0 + (row + .5) * uy + dy);
  }
  function silhouette(buffer, width, height) {
    const shape = new Path2D();
    // Each occupied character cell hides the lettering beneath the moving figure.
    // Continuous row runs preserve the full legs, coat and hair between glyphs.
    for (let row = 0; row < height; row++) {
      const offset = row * width;
      let start = -1;
      for (let col = 0; col <= width; col++) {
        if (col < width && buffer[offset + col]) {
          if (start < 0) start = col;
        } else if (start >= 0) {
          shape.rect(start, row, col - start, 1);
          start = -1;
        }
      }
    }
    return shape;
  }
  function buildBackdrop() {
    backdrop.width = canvas.width; backdrop.height = canvas.height;
    const bg = backdrop.getContext('2d');
    bg.setTransform(dpr, 0, 0, dpr, 0, 0);
    bg.font = ctx.font; bg.textAlign = 'center'; bg.textBaseline = 'middle';
    if (seat || !data.backdrop) return;
    bg.fillStyle = '#77848b'; bg.globalAlpha = .24;
    for (let row = 0; row < data.height; row += stride) {
      for (let col = 0; col < data.width; col += stride) {
        const value = data.backdrop[row * data.width + col];
        if (value) drawCell(bg, value, col, row);
      }
    }
  }
  function render(ms) {
    if (!data || !w || !h) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(backdrop, 0, 0, w, h);
    const t = ms / 1000;
    const cinema = allowed();
    // Run the filmed movement at its original pace, then return without a hold.
    const end = data.count - 1;
    const phase = end ? (t * data.fps) % (end * 2) : 0;
    const index = cinema ? Math.round(phase <= end ? phase : end * 2 - phase) : Math.round(end * .22);
    // The filmed hair, scarf and coat move while her seat stays on the lettering.
    const driftX = 0, driftY = 0;
    ctx.save();
    if (seat && data.silhouettes) {
      ctx.save();
      ctx.translate(x0 + driftX, y0 + driftY);
      ctx.scale(ux, uy);
      ctx.fillStyle = paper;
      ctx.fill(data.silhouettes[index]);
      ctx.restore();
    }
    if (data.frames) {
      const buffer = data.frames[index];
      // Grouping by material keeps text drawing inexpensive on mobile.
      for (let mat = 0; mat < colors.length; mat++) {
        ctx.fillStyle = colors[mat];
        for (let row = 0; row < data.height; row += stride) {
          const offset = row * data.width;
          for (let col = 0; col < data.width; col += stride) {
            const value = buffer[offset + col];
            if (value && (value >> 4) === mat) drawCell(ctx, value, col, row, driftX, driftY);
          }
        }
      }
    } else {
      for (const p of data.points) {
        if (p[0] % stride || p[1] % stride) continue;
        ctx.fillStyle = colors[p[3]];
        ctx.fillText(glyphs[p[2]], x0 + (p[0] + .5) * ux, y0 + (p[1] + .5) * uy);
      }
    }
    ctx.restore();
    // Sparse characters in the air share the film's breeze, without a frame or panel.
    ctx.font = `${Math.max(7, uy * stride)}px ui-monospace, monospace`;
    for (let i = 0; i < 18; i++) {
      const x = x0 + ((i * .119 + (cinema ? t * .012 : 0)) % 1) * data.width * ux;
      const y = y0 + data.height * uy * (.16 + (i * .173) % .65) + Math.sin(t * .5 + i) * 3;
      ctx.fillStyle = i % 5 ? 'rgba(91,107,116,.19)' : 'rgba(39,71,231,.26)';
      ctx.fillText(i % 3 ? '.' : ':', x, y);
    }
    ctx.font = `700 ${Math.max(1.6, uy * 1.1 * stride)}px "SFMono-Regular",Consolas,monospace`;
    scene.dataset.characterFrame = String(index);
    scene.dataset.characterTime = t.toFixed(2);
  }
  function tick(now) {
    frame = null;
    if (!eligible()) { stop(); return; }
    if (lastTime) elapsed += now - lastTime;
    lastTime = now;
    if (now - lastDraw >= 1000 / (w < 641 ? 20 : 30)) { render(elapsed); lastDraw = now; }
    frame = requestAnimationFrame(tick);
  }
  function resume() {
    if (!eligible() || frame !== null) return;
    lastTime = 0;
    scene.dataset.characterState = 'running';
    frame = requestAnimationFrame(tick);
  }
  function resize() {
    if (!data) return;
    stop();
    const box = canvas.getBoundingClientRect();
    paper = getComputedStyle(scene).backgroundColor;
    w = Math.round(box.width); h = Math.round(box.height);
    if (!w || !h) return;
    dpr = Math.min(devicePixelRatio || 1, 1.5);
    canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    const mobile = w < 641;
    const figureHeight = Math.min(h * .86, w * .36 / data.aspect);
    const figureWidth = figureHeight * data.aspect;
    ux = figureWidth / data.width; uy = figureHeight / data.height;
    x0 = w * .63;
    y0 = Math.max(18, (h - figureHeight) * .10);
    if (seat) {
      const origin = canvas.getBoundingClientRect();
      const chapter = stage.getBoundingClientRect();
      const wordWidth = w * .94;
      const wordHeight = wordWidth / 3;
      const arc = seat.querySelector('tspan:last-child');
      const hipLine = y0 + figureHeight * .52;
      seat.style.left = `${origin.left - chapter.left + w * .03}px`;
      seat.style.width = `${wordWidth}px`;
      seat.style.height = `${wordHeight}px`;
      // SVG text bounds include empty font space. Use the actual drawn letter
      // ascent so her hips meet the red ink rather than that empty space.
      const font = getComputedStyle(arc);
      ctx.save();
      ctx.font = `${font.fontStyle} ${font.fontWeight} ${font.fontSize} ${font.fontFamily}`;
      const ascent = ctx.measureText(arc.textContent).actualBoundingBoxAscent;
      ctx.restore();
      const baseline = Number(seat.querySelector('text').getAttribute('y'));
      const inkTop = (baseline - ascent) * wordHeight / 120;
      seat.style.top = `${origin.top - chapter.top + hipLine - inkTop}px`;
      scene.dataset.characterSeat = hipLine.toFixed(2);
    }
    stride = mobile ? 2 : 1;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.font = `700 ${Math.max(1.6, uy * 1.1 * stride)}px "SFMono-Regular",Consolas,monospace`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    buildBackdrop();
    render(elapsed);
    scene.dataset.characterReady = 'true';
    resume();
  }
  async function load() {
    if (data || pending) return;
    pending = true;
    try {
      if (!('DecompressionStream' in window)) throw new Error('Text frame decompression unavailable');
      const response = await fetch('/character-film-v30.gz');
      if (!response.ok) throw new Error('Character film unavailable');
      const bytes = new Uint8Array(await new Response(response.body.pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
      if (String.fromCharCode(...bytes.subarray(0, 4)) !== 'RZAN') throw new Error('Invalid character frames');
      const header = new DataView(bytes.buffer);
      const width = header.getUint16(4, true), height = header.getUint16(6, true), count = header.getUint16(8, true);
      const size = width * height;
      if (!width || !height || !count || bytes.length < 16 + size * (count + 1)) throw new Error('Incomplete character frames');
      const frames = Array.from({length:count}, (_,i) => bytes.subarray(16 + size * i, 16 + size * (i + 1)));
      data = {width, height, count, frames, fps:header.getUint16(10, true) / 100 || 16,
        silhouettes:frames.map(buffer => silhouette(buffer, width, height)),
        aspect:width * .55 / height, backdrop:bytes.subarray(16 + size * count)};
      scene.dataset.characterMode = 'film';
    } catch {
      try {
        const response = await fetch('/character-study-v30.json');
        if (!response.ok) throw new Error('Character still unavailable');
        data = {...await response.json(), count:1, fps:16};
        const buffer = new Uint8Array(data.width * data.height);
        for (const point of data.points) buffer[point[1] * data.width + point[0]] = 1;
        data.silhouettes = [silhouette(buffer, data.width, data.height)];
        scene.dataset.characterMode = 'still';
      } catch { scene.dataset.characterState = 'unavailable'; }
    }
    pending = false;
    resize();
  }
  if ('IntersectionObserver' in window) new IntersectionObserver(entries => {
    inView = entries[0].isIntersecting;
    if (inView) { load(); resume(); } else stop();
  }, {threshold:.03}).observe(canvas);
  else { inView = true; load(); }
  new ResizeObserver(() => {
    if (resizeFrame !== null) cancelAnimationFrame(resizeFrame);
    resizeFrame = requestAnimationFrame(() => { resizeFrame = null; resize(); });
  }).observe(canvas);
  window.addEventListener('focus', resume);
  window.addEventListener('pagehide', stop);
  document.addEventListener('visibilitychange', () => document.hidden ? stop() : resume());
  ['site-menu-open','site-navigation-start'].forEach(name => document.addEventListener(name, stop));
  document.addEventListener('site-menu-close', resume);
  preference.addEventListener('change', () => { stop(); render(0); resume(); });
})();
