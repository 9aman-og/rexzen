const $ = (selector, root = document) => root.querySelector(selector);
const escape = (value = '') => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels = {home:'Workspace',work:'Work',context:'Context',graph:'Relationships',ask:'Conversations',journal:'Journal',personal:'Personal',settings:'Settings'};
const kinds = {note:'Note',project:'Project',task:'Task',goal:'Goal',log:'Work log',personal:'Personal context'};
const relations = {supports:'supports',depends_on:'depends on',part_of:'is part of',related:'is related to'};
const state = {session:null,records:[],edges:[],conversations:[],preferences:{},selected:new Set(),view:viewFromPath(),filter:'all',search:'',demo:false,prepared:null,latest:null,sourceSearch:'',sourceType:'all',inspectorOpen:!matchMedia('(max-width:1100px)').matches,sending:false};
let toastTimer;
let editing;
let routeTransition;
let navigationRevision=0;
let prepareToolRevision=0;
let prepareRequestRevision=0;
let draftRevision=0;
let reviewExpiryTimer;
let conversationGeneration=0;
let renderedSurface=null;
const accountChannel = typeof BroadcastChannel === 'function' ? new BroadcastChannel('aero-account') : null;

function clearPrivateState() {
  renderedSurface=null;conversationGeneration++;closeSidebar(false);
  prepareRequestRevision++;draftRevision++;clearTimeout(reviewExpiryTimer);document.dispatchEvent(new Event('aero-navigation-start'));
  navigationRevision++;routeTransition?.skipTransition();routeTransition=null;
  state.session={authenticated:false};state.records=[];state.edges=[];state.conversations=[];state.preferences={};state.selected.clear();state.latest=null;state.prepared=null;state.demo=false;state.sourceSearch='';state.sourceType='all';state.sending=false;delete state.draftQuestion;delete state.draftMode;delete state.draftTier;editing=null;
  document.querySelectorAll('dialog').forEach(dialog=>{if(dialog.open)dialog.close();dialog.querySelectorAll('form').forEach(form=>form.reset());});
  $('#record-form').elements.projectId.replaceChildren();$('#relation-form').elements.fromId.replaceChildren();$('#relation-form').elements.toId.replaceChildren();
  $('#detail-content').replaceChildren();$('#context-review').replaceChildren();$('#confirm-copy').textContent='';$('#confirm-action').onclick=null;clearTimeout(toastTimer);$('#toast').textContent='';$('#toast').hidden=true;
  render();
}
function accountInvalidated() { clearPrivateState();notice('Your sign-in changed or expired. Reload Aero to continue with the current account.',true); }
if(accountChannel)accountChannel.onmessage=event=>{const accountId=event.data?.accountId;if(state.session?.authenticated && (accountId===null || (typeof accountId==='string' && accountId!==state.session.user.id)))accountInvalidated();};

function viewFromPath() { return Object.keys(labels).includes(location.pathname.split('/')[2]) ? location.pathname.split('/')[2] : 'home'; }
function activeRecords() { return state.records.filter(r => !r.archived); }
function record(id) { return state.records.find(r => r.id === id); }
function date(value) { if (!value) return ''; const d = new Date(value.length === 10 ? `${value}T12:00:00` : value); if (Number.isNaN(d.valueOf())) return ''; const options={month:'short',day:'numeric',year:'numeric'}; if (value.length !== 10 && validTimezone(state.preferences.timezone)) options.timeZone=state.preferences.timezone; return new Intl.DateTimeFormat(undefined,options).format(d); }
function validTimezone(value) { if (typeof value !== 'string' || !value.trim()) return false; try { new Intl.DateTimeFormat(undefined,{timeZone:value}); return true; } catch { return false; } }
function toast(text) { $('#toast').textContent=text; $('#toast').hidden=false; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('#toast').hidden=true,4500); }
function notice(text='', error=false) { const node=$('#notice');node.textContent=text;node.hidden=!text;node.classList.toggle('error',error); }
async function api(path, data, method) {
  const expected=state.session?.authenticated?state.session.user.id:null;
  const headers=data === undefined?{}:{'Content-Type':'application/json'};if(expected)headers['X-Aero-Account']=expected;
  const response=await fetch(path,{method:method || (data === undefined?'GET':'POST'),credentials:'same-origin',headers,body:data === undefined?undefined:JSON.stringify(data),cache:'no-store'});
  let payload; try { payload=await response.json(); } catch { throw new Error('The workspace returned an unreadable response. Please try again.'); }
  if (!response.ok) { const error=new Error(payload.error?.message || 'This action could not be completed.');error.code=payload.error?.code;error.status=response.status;if(response.status===401 || ['account_changed','account_state_required'].includes(error.code))accountInvalidated();throw error; }
  if(expected && state.session?.user?.id!==expected){accountInvalidated();throw new Error('Your sign-in changed while this action was running. Reload Aero.');}
  return payload;
}
async function loadWorkspace() {
  if (state.demo) return;
  const data=await api('/api/workspace');
  Object.assign(state,{records:data.records || [],edges:data.edges || [],conversations:data.conversations || [],preferences:data.preferences || {}});
  state.selected=new Set([...state.selected].filter(id=>record(id)?.cloudAllowed && !record(id)?.archived));
}
function updateChrome() {
  const authenticated=state.session?.authenticated;
  $('.workspace-name').textContent=state.demo?'Example workspace':state.preferences.workspaceName || 'Personal workspace';
  $('#signin-top').hidden=!!authenticated;$('#signout').hidden=!authenticated;
  $('#quick-add').disabled=!(authenticated || state.demo);
  $('#account-label').textContent=authenticated ? state.session.user.email : state.demo ? 'Example workspace · not saved' : 'Not signed in';
  $('#view-label').textContent=labels[state.view];
  $('#recent-requests').innerHTML=state.conversations.length?state.conversations.slice(0,7).map(c=>`<button class="sidebar-request" data-action="conversation" data-id="${c.id}" title="${escape(c.question)}">${escape(c.question)}</button>`).join(''):'<p class="sidebar-empty">Your saved requests appear here.</p>';
  document.querySelectorAll('#app-nav a').forEach(link=>{if(!link.querySelector('svg'))link.insertAdjacentHTML('afterbegin',icon(link.dataset.view));});
  document.title=`${labels[state.view]} | Aero`;
  document.querySelectorAll('[data-view]').forEach(a=> { if(a.dataset.view===state.view) a.setAttribute('aria-current','page');else a.removeAttribute('aria-current'); });
}
function heading(title,copy,action='') { return `<div class="page-heading"><div><div class="eyebrow">${state.demo?'Example workspace':'Your workspace'}</div><h1 data-headline-reveal>${escape(title)}</h1>${copy?`<p>${escape(copy)}</p>`:''}</div>${action}</div>`; }
function addButton(type, title='New record') { return `<button class="button" data-action="add" data-type="${type}">${title}</button>`; }
function empty(title,copy,type) { return `<div class="empty-state"><h2>${escape(title)}</h2><p>${escape(copy)}</p>${type?addButton(type,`Add a ${kinds[type].toLowerCase()}`):''}</div>`; }
function rows(records) {
  if (!records.length) return empty('Nothing here yet','Create a record to begin.');
  return `<div class="record-list">${records.map(r=> {
    const blockers=state.edges.filter(e=>e.fromId===r.id && e.relation==='depends_on' && record(e.toId)?.status!=='done' && !record(e.toId)?.archived).length;
    return `<div class="record-row">${r.type==='task'&&!r.archived ? `<input type="checkbox" data-task="${r.id}" aria-label="Mark ${escape(r.title)} ${r.status==='done'?'open':'done'}" ${r.status==='done'?'checked':''}>` : `<span class="kind-marker" aria-label="${kinds[r.type]}">${icon(r.type)}</span>`}<button class="record-open" data-action="detail" data-id="${r.id}"><span class="record-title">${escape(r.title)}</span><span class="record-meta"><span>${kinds[r.type]}</span>${r.projectId?`<span>${escape(record(r.projectId)?.title || 'Project')}</span>`:''}${r.due?`<span>Due ${date(r.due)}</span>`:''}${blockers?`<span>${blockers} dependencies open</span>`:''}<span>${r.cloudAllowed?'AI selectable':'Excluded from AI'}</span></span></button><span class="status-chip">${r.archived?'Archived':escape(r.status)}</span></div>`;
  }).join('')}</div>`;
}
function welcome() {
  return `<div class="welcome-panel"><div><div class="eyebrow">Aero / Private workspace</div><h1 data-headline-reveal>Your private<br>workspace.</h1><p>Keep notes, projects and tasks together. Choose sources for a question, review the request and read the answer with its references.</p><div class="welcome-actions"><a class="button" href="/auth/google">Sign in with Google</a><button class="button outline" data-action="demo">Explore an example</button></div><p class="private-note">Each account has its own workspace. Bring your OpenAI key in Settings to use AI.</p></div><ol class="workflow-list"><li><div><strong>Write it down</strong><span>Notes, projects, tasks, goals, and personal context.</span></div></li><li><div><strong>Connect the details</strong><span>Record what supports a decision and what depends on a task.</span></div></li><li><div><strong>Review before sending</strong><span>Choose the sources and see the question and context first.</span></div></li><li><div><strong>Turn a plan into work</strong><span>Read the proposed steps, then accept them into your task list.</span></div></li></ol></div><p class="private-note">The example uses fictional records and has no live AI responses. Your signed-in workspace is stored privately on the server.</p>`;
}
function renderHome() { return renderAsk(true); }
function renderRecords(view) {
  const config={work:['Work','Make the next step concrete. Keep projects, goals, and their tasks together.','task'],context:['Context','Keep sources, observations, and decisions you want to build on.','note'],journal:['Journal','Record what you did, what changed, and what you learned.','log'],personal:['Personal','Your preferences and personal context. New personal records are excluded from AI by default.','personal']}[view];
  const filters=view==='work'?['all','project','task','goal']:view==='context'?['all','note']:['all'];
  const scoped=activeRecords().filter(r=>view==='work'?['project','task','goal'].includes(r.type):view==='context'?r.type==='note':r.type===(view==='journal'?'log':'personal'));
  const tabs=filters.length>1?`<div class="tabs" role="group" aria-label="Filter records">${filters.map(f=>`<button data-filter="${f}" class="tab ${state.filter===f?'active':''}" aria-pressed="${state.filter===f}">${f==='all'?'All':kinds[f]+'s'}</button>`).join('')}</div>`:'';
  return heading(config[0],config[1],addButton(config[2],`New ${kinds[config[2]].toLowerCase()}`))+tabs+`<div class="toolbar"><input id="record-search" type="search" aria-label="Search these records" placeholder="Find a record…" value="${escape(state.search)}"><span class="selected-count">${scoped.length} records</span></div><div id="filtered-records">${filteredRows(scoped)}</div>`;
}
function filteredRows(scoped) { return rows(scoped.filter(r=>(state.filter==='all'||r.type===state.filter)&&`${r.title} ${r.body} ${r.tags.join(' ')}`.toLowerCase().includes(state.search.toLowerCase()))); }
function graphSvg(records,edges) {
  if (!records.length) return empty('Connections start with records','Create two records, then add a relationship.','note');
  const nodes=records.slice(0,30);const height=Math.max(330,Math.ceil(nodes.length/3)*110+50);const positions=new Map(nodes.map((r,i)=>[r.id,{x:45+(i%3)*290,y:35+Math.floor(i/3)*110}]));
  return `<div class="graph-wrap"><svg viewBox="0 0 900 ${height}" role="img" aria-label="Connections between the first ${nodes.length} workspace records"><defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7" fill="#b0bad1"/></marker></defs>${edges.filter(e=>positions.has(e.fromId)&&positions.has(e.toId)).map(e=>{const a=positions.get(e.fromId),b=positions.get(e.toId);return `<path class="graph-edge" marker-end="url(#arrow)" d="M ${a.x+115} ${a.y+28} L ${b.x+115} ${b.y+28}"/>`;}).join('')}${nodes.map(r=>{const p=positions.get(r.id);return `<g class="graph-node" data-action="detail" data-id="${r.id}" role="button" tabindex="0" aria-label="Open ${escape(r.title)}"><rect x="${p.x}" y="${p.y}" width="235" height="64" rx="5"/><text x="${p.x+13}" y="${p.y+25}">${escape(r.title.length>27?r.title.slice(0,26)+'…':r.title)}</text><text class="graph-label" x="${p.x+13}" y="${p.y+47}">${kinds[r.type]}</text></g>`;}).join('')}</svg></div>${records.length>30?'<p class="form-note">Showing the 30 most recent records here. The list below contains all relationships.</p>':''}`;
}
function renderGraph() {
  const records=activeRecords(),ids=new Set(records.map(r=>r.id)),edges=state.edges.filter(e=>ids.has(e.fromId)&&ids.has(e.toId));
  return heading('A relationship has a reason.','Connect evidence to a decision, a task to its dependencies, or an idea to its project.',`<button class="button" data-action="relation" ${records.length<2?'disabled':''}>Add relationship</button>`)+graphSvg(records,edges)+`<section class="list-section"><h2 class="section-title">${edges.length} relationships</h2>${edges.length?edges.map(e=>`<div class="relationship-row"><div><button class="subtle-button" data-action="detail" data-id="${e.fromId}">${escape(record(e.fromId).title)}</button> <span>${relations[e.relation]}</span> <button class="subtle-button" data-action="detail" data-id="${e.toId}">${escape(record(e.toId).title)}</button></div><button class="icon-button" data-action="unlink" data-id="${e.id}" aria-label="Remove relationship between ${escape(record(e.fromId).title)} and ${escape(record(e.toId).title)}">Remove</button></div>`).join(''):empty('No links yet','Links help you remember why two records belong together.')}</section>`;
}
function icon(kind) {
  const paths={home:'<path d="M3 10 12 3l9 7v10H3Z"/><path d="M9 20v-7h6v7"/>',work:'<rect x="4" y="5" width="16" height="16" rx="3"/><path d="M9 5V3h6v2M8 11l2 2 5-5M8 17h8"/>',context:'<path d="M6 3h10l3 3v15H6Z"/><path d="M15 3v5h4M9 12h7M9 16h5"/>',graph:'<circle cx="5" cy="6" r="2.5"/><circle cx="19" cy="6" r="2.5"/><circle cx="12" cy="19" r="2.5"/><path d="M7.5 6h9M6 8l5 9M18 8l-5 9"/>',ask:'<path d="M4 4h16v12H10l-6 4Z"/><path d="M8 9h8M8 12h5"/>',journal:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 3v18M11 8h6M11 12h6M11 16h4"/>',personal:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',note:'<path d="M6 3h10l3 3v15H6Z"/><path d="M9 10h7M9 14h7M9 18h4"/>',project:'<path d="M3 7h7l2-3h9v16H3Z"/>',task:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="m8 12 3 3 6-7"/>',goal:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>',log:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>'};
  return `<svg class="nav-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${paths[kind]||paths.note}</svg>`;
}
function citationEvidence(conversation,citation) { return Array.isArray(conversation.evidence)?conversation.evidence.find(e=>e.id===citation.id&&e.revision===citation.revision):null; }
function answerHtml(conversation) {
  const {answer,proposal}=conversation;
  return `<section class="conversation-answer" aria-label="Saved answer"><div class="conversation-question">${escape(conversation.question)}</div><div class="answer-panel"><div class="answer-heading"><img src="/brand/aero-mark.svg" alt=""><span>Aero</span><small>${escape(conversation.model)} · ${date(conversation.createdAt)}</small></div><div class="answer">${escape(answer.text)}</div>${answer.citations?.length?`<div class="citation-list" aria-label="Referenced sources">${answer.citations.map(c=>`<button class="citation" data-action="citation" data-id="${c.id}" data-revision="${c.revision}" data-conversation="${conversation.id}">${escape(citationEvidence(conversation,c)?.title || record(c.id)?.title || 'Source')} · v${c.revision}</button>`).join('')}</div><p class="form-note">Open a citation to inspect its source. References still need to support the claims.</p>`:''}${answer.steps?.length?`<section class="plan-review"><header><h2>${proposal?.status==='applied'?'Accepted plan':'Proposed plan'}</h2><span class="plan-state">${proposal?.status==='applied'?'Saved to Work':'Awaiting your review'}</span></header>${answer.steps.map((step,index)=>`<div class="plan-step"><strong>${index+1}. ${escape(step.title)}</strong><p>${escape(step.body)}</p><p>Done when: ${escape(step.doneWhen)}</p>${step.dependsOn.length?`<small>Depends on: ${step.dependsOn.map(id=>escape(answer.steps.find(x=>x.id===id)?.title || id)).join(', ')}</small>`:''}</div>`).join('')}<p class="form-note">${proposal?.status==='applied'?'These steps are in your task list.':'Accepting this plan creates all listed tasks and their dependency links.'}</p>${proposal?.status==='pending'?`<button class="button" data-action="apply" data-id="${proposal.id}">Review ${answer.steps.length} steps for Work</button>`:''}</section>`:''}<details class="answer-receipt"><summary>Request receipt</summary><p class="form-note">${escape(conversation.receipt?.coverage?.summary || '')}</p><p class="review-hash">${escape(conversation.receipt?.hash || '')}</p></details></div></section>`;
}
function selectedChips() {
  return [...state.selected].map(id=>record(id)).filter(Boolean).map(r=>`<span class="source-chip"><span>${escape(r.title)}</span><button type="button" data-action="remove-source" data-id="${r.id}" aria-label="Remove ${escape(r.title)} from selected context">×</button></span>`).join('');
}
function selectedLinks() {
  const edges=state.edges.filter(e=>state.selected.has(e.fromId)&&state.selected.has(e.toId));
  return edges.length?edges.map(e=>`<p>${escape(record(e.fromId)?.title)} <span>${relations[e.relation]}</span> ${escape(record(e.toId)?.title)}</p>`).join(''):'<p>No direct relationships between the selected records.</p>';
}
function sourceRows(selectable) {
  return selectable.map(r=>`<div class="source-entry" data-source-entry="${r.id}"><label><input type="checkbox" data-source="${r.id}" ${state.selected.has(r.id)?'checked':''}><span><strong>${escape(r.title)}</strong><small>${kinds[r.type]} · version ${r.revision}${r.projectId?' · '+escape(record(r.projectId)?.title || 'Project'):''}</small></span></label><button type="button" class="source-inspect" data-action="detail" data-id="${r.id}" aria-label="Inspect ${escape(r.title)} without selecting it">Inspect</button></div>`).join('');
}
function renderAsk(home=false) {
  const selectable=activeRecords().filter(r=>r.cloudAllowed);
  const taskCount=activeRecords().filter(r=>r.type==='task'&&r.status!=='done').length;
  const tasks=activeRecords().filter(r=>r.type==='task'&&r.status!=='done').sort((a,b)=>(a.due || '9999').localeCompare(b.due || '9999')).slice(0,3);
  return `<div class="conversation-layout"><section class="conversation-column" aria-label="Conversation">${state.latest?'<h1 class="sr-only">Conversation</h1>'+answerHtml(state.latest):`<header class="conversation-intro"><img src="/brand/aero-mark.svg" alt=""><h1 data-headline-reveal>What are you working on?</h1><p>Think with your sources. Turn a question into a clear answer or a plan you can review.</p></header>`}<form id="ask-form" class="request-composer"><label for="aero-question">Your question</label><textarea id="aero-question" name="question" maxlength="4000" required rows="3" placeholder="Ask about your work, with the context you choose…">${escape(state.draftQuestion || '')}</textarea><div id="composer-sources" class="composer-sources">${selectedChips()}</div><div class="composer-options"><div class="composer-selects"><label>Response<select name="mode"><option value="answer">Answer with sources</option><option value="plan" ${state.draftMode==='plan'?'selected':''}>Propose a plan</option></select></label><label>Reasoning<select name="tier"><option value="luna">Luna · everyday</option><option value="sol" ${state.draftTier==='sol'?'selected':''}>Sol · deeper</option></select></label></div><button class="button composer-review" type="submit" ${state.sending?'disabled':''}>${state.sending?'Request in progress':state.prepared?'Resume review':'Review request'}</button></div><div class="composer-context"><button type="button" data-action="choose-context" aria-controls="context-inspector">Choose context · <span id="selected-count">${state.selected.size}</span> / 12</button><span>${state.demo?'Fictional example':'Review before sending'}</span></div><p id="ask-error" class="form-error" role="alert"></p></form><p class="composer-disclosure">${state.demo?'Example only. No request is sent and changes are not saved.':state.session.user.hasKey?'Each request uses the sources you select. You review it before it goes to OpenAI.':'Connect your own OpenAI key in Settings to send a reviewed request.'}</p>${!state.latest?`<div class="composer-prompts"><button type="button" class="composer-prompt" data-action="starter" data-starter="answer">Make sense of my notes<small>Compare ideas and trace the sources.</small></button><button type="button" class="composer-prompt" data-action="starter" data-starter="plan">Plan the next step<small>Review proposed tasks before saving.</small></button></div>`:''}${home?`<section class="workbench-glance"><div class="glance-heading"><strong>Next in your work</strong><span class="glance-counts">${taskCount} open tasks · ${selectable.length} selectable sources</span><button class="subtle-button" data-view="work">Open Work</button></div>${tasks.length?rows(tasks):'<p class="private-note">Add a task or review a proposed plan to give your work a next step.</p>'}</section>`:''}</section><details class="context-inspector" id="context-inspector" ${state.inspectorOpen?'open':''}><summary><strong>Context</strong><span class="context-total"><span id="inspector-selected-count">${state.selected.size}</span> / 12 selected</span></summary><div class="inspector-body"><div class="inspector-label">Sources for this request</div><div class="source-controls"><label>Find a source<input id="source-search" type="search" placeholder="Search titles or tags" value="${escape(state.sourceSearch)}"></label><label>Record type<select id="source-type"><option value="all">All types</option>${Object.entries(kinds).map(([kind,label])=>`<option value="${kind}" ${state.sourceType===kind?'selected':''}>${label}</option>`).join('')}</select></label></div><div class="source-list" id="source-list">${sourceRows(selectable)}</div><p id="source-no-match" class="source-empty" hidden>No sources match these filters.</p>${!selectable.length?'<p class="source-empty">No records are enabled for AI. Open a record and allow explicit AI selection.</p>':''}<p class="inspector-copy">Only enabled records appear here. Inspecting a source does not select it. The request preview shows exactly what fits in the context budget.</p><section class="context-links"><div class="inspector-label">Selected relationships</div><div id="selected-links">${selectedLinks()}</div></section><p class="inspector-copy">Personal records stay excluded unless you explicitly enable them.</p><button type="button" class="subtle-button list-section" data-view="context">Open all context</button></div></details></div>`;
}
function filterSources() {
  let count=0;
  document.querySelectorAll('[data-source-entry]').forEach(row=>{
    const r=record(row.dataset.sourceEntry);
    row.hidden=!r || (state.sourceType!=='all'&&r.type!==state.sourceType) || !`${r.title} ${r.tags.join(' ')}`.toLowerCase().includes(state.sourceSearch.toLowerCase());
    if(!row.hidden)count++;
  });
  const empty=$('#source-no-match');if(empty)empty.hidden=count>0 || !activeRecords().some(r=>r.cloudAllowed);
}
function invalidatePrepared() { draftRevision++;prepareRequestRevision++;state.prepared=null;clearTimeout(reviewExpiryTimer); }
function syncSources() {
  $('#composer-sources')?.replaceChildren();if($('#composer-sources'))$('#composer-sources').innerHTML=selectedChips();
  if($('#selected-count'))$('#selected-count').textContent=state.selected.size;
  if($('#inspector-selected-count'))$('#inspector-selected-count').textContent=state.selected.size;
  if($('#selected-links'))$('#selected-links').innerHTML=selectedLinks();
  document.querySelectorAll('[data-source]').forEach(input=>input.checked=state.selected.has(input.dataset.source));
  syncReviewControls();
}
function preparedMatchesDraft() {
  const prepared=state.prepared;if(!prepared || new Date(prepared.receipt.expiresAt).valueOf()<=Date.now())return false;
  return prepared.request?.question===(state.draftQuestion || '').trim() && prepared.request.mode===(state.draftMode || 'answer') && prepared.request.tier===(state.draftTier || 'luna') &&
    prepared.evidence.length===state.selected.size && prepared.evidence.every(e=>state.selected.has(e.id)&&record(e.id)?.revision===e.revision&&record(e.id)?.cloudAllowed&&!record(e.id)?.archived);
}
function syncReviewControls() {
  const button=$('#ask-form [type="submit"]');if(!button)return;
  button.disabled=state.sending;
  button.textContent=state.sending?'Request in progress':preparedMatchesDraft()?'Resume review':'Review request';
}
function showCitation(conversationId,id,revision) {
  const conversation=state.conversations.find(c=>c.id===conversationId) || (state.latest?.id===conversationId?state.latest:null);
  if(!conversation)return toast('This answer is no longer in the workspace.');
  const evidence=citationEvidence(conversation,{id,revision:Number(revision)});const current=record(id);
  $('#detail-content').innerHTML=`<div class="dialog-heading"><h2>${escape(evidence?.title || 'Source citation')}</h2><button class="icon-button" data-close>Close</button></div><p class="detail-meta">Source version ${Number(revision)} · saved answer from ${date(conversation.createdAt)}</p>${evidence?`<p class="form-note">Excerpt sent with this answer</p><div class="detail-body">${escape(evidence.excerpt)}</div>`:'<p class="stale-message">The original excerpt was not saved with this older answer. Current record content may differ.</p>'}<p class="form-note">${current?(current.archived?'The current record is archived.':current.cloudAllowed?'The current record is enabled for explicit AI selection.':'The current record is excluded from new AI requests.'):'The current record is no longer available.'} Viewing this saved excerpt does not send or select anything.</p>${current?`<div class="dialog-actions"><button type="button" class="button outline" data-action="detail" data-id="${id}">Open current record</button></div>`:''}`;
  if(!$('#detail-dialog').open)$('#detail-dialog').showModal();
}
function exampleReview() {
  const sources=[...state.selected].map(id=>record(id)).filter(Boolean);
  $('#context-review').innerHTML=`<div class="dialog-heading"><h2>Example request review</h2><button class="icon-button" data-close>Close</button></div><p class="form-note">Fictional workspace. This is a local preview; nothing is sent to a provider.</p><h3 class="section-title">Your question</h3><div class="detail-body">${escape(state.draftQuestion)}</div><p class="form-note">${state.draftMode==='plan'?'Proposed plan':'Answer with sources'} · ${state.draftTier==='sol'?'Sol':'Luna'} · ${sources.length} selected records</p>${sources.map(r=>`<section class="review-source"><h3>${escape(r.title)} · v${r.revision}</h3><pre>${escape(r.body)}</pre></section>`).join('')}${!sources.length?'<p class="form-note">No workspace sources selected.</p>':''}<div class="dialog-actions"><button class="button outline" data-close>Return to example</button><a class="button" href="/auth/google">Sign in for your workspace</a></div>`;
  $('#context-dialog').showModal();
}
async function prepareRequest() {
  const form=$('#ask-form');if(!form || state.sending)return;
  state.draftQuestion=form.elements.question.value.trim();state.draftMode=form.elements.mode.value;state.draftTier=form.elements.tier.value;
  if(!state.draftQuestion)return form.elements.question.reportValidity();
  $('#ask-error').textContent='';
  if(state.demo)return exampleReview();
  if(preparedMatchesDraft())return showReview(state.prepared);
  state.prepared=null;const requestRevision=++prepareRequestRevision;const draft=draftRevision;const navigation=navigationRevision;
  const button=form.querySelector('[type="submit"]');button.disabled=true;button.textContent='Preparing review…';
  const input={question:state.draftQuestion,mode:state.draftMode,tier:state.draftTier,recordIds:[...state.selected]};
  try {
    const data=await api('/api/context/prepare',input);
    if(requestRevision!==prepareRequestRevision || draft!==draftRevision || navigation!==navigationRevision)return;
    showReview(data);syncReviewControls();
  } catch(error) { if(requestRevision===prepareRequestRevision){const target=$('#ask-error');if(target)target.textContent=error.message;else notice(error.message,true);} }
  finally { if(requestRevision===prepareRequestRevision)syncReviewControls(); }
}
function renderSettings() {
  const user=state.session?.user || {};
  const archived=state.records.filter(r=>r.archived);
  return heading('Settings','Your account, AI connection, and portable workspace data.')+`<div class="settings-grid"><section class="panel"><h2>Account</h2><p>${escape(user.email || 'Fictional example workspace')}</p><p class="form-note">Google handles sign-in. Records belong to this account and are encrypted in server storage. Encryption is managed by the service; this is not end-to-end encryption.</p><form id="preferences-form"><label>Workspace name<input name="workspaceName" maxlength="80" value="${escape(state.preferences.workspaceName || '')}" placeholder="My workspace"></label><label>Time zone<input name="timezone" maxlength="80" value="${escape(state.preferences.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone)}"></label><label>Preferred response style<select name="tone"><option value="concise">Concise and direct</option><option value="detailed" ${state.preferences.tone==='detailed'?'selected':''}>Detailed explanations</option></select></label><p class="form-note">Response style is saved as a workspace preference. Your question controls the current AI request.</p><button class="button" type="submit">Save preferences</button></form></section><section class="panel"><h2>AI connection</h2><div class="key-state">${state.demo?'Example · no key connected':user.ownerKey?'Your founder key is configured for this verified account.':user.personalKey?'Your personal key is connected.':'Connect your own OpenAI API key.'}</div><p class="form-note">Other accounts must supply their own key. Keys are encrypted in server storage and never returned to the browser, included in context, or exported. Requests may incur charges on the connected OpenAI account.</p><form id="key-form"><label>${user.hasKey?'Replace with a personal key':'OpenAI API key'}<input type="password" name="key" autocomplete="off" spellcheck="false" placeholder="sk-…" maxlength="503" ${state.demo?'disabled':''} required></label><button class="button" type="submit" ${state.demo?'disabled':''}>Save private key</button></form>${user.personalKey?'<button class="button outline" data-action="remove-key">Remove personal key</button>':''}<p class="form-note">Luna: ${escape(state.session?.models?.luna || 'gpt-6-luna')}<br>Sol: ${escape(state.session?.models?.sol || 'gpt-6.1-sol')}</p></section><section class="panel"><h2>Take your work with you</h2><p>Export your records, relationships, preferences, and conversations. API keys and sign-in tokens are excluded.</p><button class="button outline" data-action="export">Export workspace JSON</button><h3 class="section-title list-section">Import records</h3><p class="form-note">Choose an Aero JSON export or a text note. You’ll review the count first. Imports copy active records and relationships into this account; conversations and credentials are not imported.</p><label>Choose a file<input id="import-file" class="import-input" type="file" accept=".json,.txt,.md,application/json,text/plain"></label></section><section class="panel"><h2>Archived records</h2><p>Archive removes a record from current work and AI selection. Restore it whenever you need it.</p>${archived.length?archived.map(r=>`<div class="relationship-row"><span>${escape(r.title)}</span><button class="subtle-button" data-action="restore" data-id="${r.id}">Restore</button></div>`).join(''): '<p class="form-note">No archived records.</p>'}</section></div>`;
}
function render() {
  document.dispatchEvent(new Event('aero-navigation-start'));
  const surface=`${state.session?.authenticated?'account':state.demo?'example':'welcome'}:${state.view}:${['home','ask'].includes(state.view)?state.latest?.id || 'intro':''}`;
  const animateHeadline=surface!==renderedSurface;renderedSurface=surface;
  updateChrome();
  $('#workspace').innerHTML=!state.session?.authenticated&&!state.demo?welcome():state.view==='home'?renderHome():['work','context','journal','personal'].includes(state.view)?renderRecords(state.view):state.view==='graph'?renderGraph():state.view==='ask'?renderAsk():renderSettings();
  filterSources();syncReviewControls();
  document.dispatchEvent(new CustomEvent('aero-view-rendered',{detail:{animateHeadline}}));
}
function navigate(view,push=true) {
  const previous=state.view;const revision=++navigationRevision;prepareRequestRevision++;
  document.dispatchEvent(new Event('aero-navigation-start'));
  if($('#context-dialog').open)$('#context-dialog').close();
  routeTransition?.skipTransition();
  state.view=labels[view]?view:'home';state.filter='all';state.search='';
  if(push) history.pushState({},'',state.view==='home'?'/aero':`/aero/${state.view}`);
  closeSidebar(false);
  const update=()=>{if(revision!==navigationRevision)return;render();window.scrollTo({top:0,behavior:'instant'});$('#workspace').focus({preventScroll:true});};
  const destinationHasHeadline=(!state.session?.authenticated&&!state.demo) || !['home','ask'].includes(state.view) || !state.latest;
  if(document.startViewTransition && !destinationHasHeadline && previous!==state.view && !document.hidden && !matchMedia('(prefers-reduced-motion: reduce)').matches){
    const transition=document.startViewTransition(update);routeTransition=transition;
    transition.finished.catch(()=>{}).finally(()=>{if(routeTransition===transition)routeTransition=null;});
    return transition.updateCallbackDone.catch(()=>{});
  }
  update();return Promise.resolve();
}
function openRecord(type='note',id) {
  editing=id?record(id):null;const form=$('#record-form');form.reset();
  $('#record-dialog-title').textContent=editing?'Edit record':'New record';$('#record-error').textContent='';
  form.elements.projectId.innerHTML='<option value="">No project</option>'+activeRecords().filter(r=>r.type==='project'&&r.id!==id).map(r=>`<option value="${r.id}">${escape(r.title)}</option>`).join('');
  form.elements.type.value=editing?.type || type;form.elements.type.disabled=!!editing;
  for(const field of ['title','body','status','projectId']) if(editing) form.elements[field].value=editing[field] || (field==='status'?'open':'');
  form.elements.due.value=editing?.due?.slice(0,10) || '';form.elements.tags.value=editing?.tags?.join(', ') || '';
  form.elements.cloudAllowed.checked=editing?.cloudAllowed || false;
  $('#record-dialog').showModal();
}
function detail(id,citedRevision) {
  const r=record(id);if(!r) return toast('This source is no longer in the workspace.');
  const linked=state.edges.filter(e=>e.fromId===id||e.toId===id);
  const linkedHtml=linked.length ? '<h3 class="section-title">Relationships</h3>'+linked.map(e=>`<p class="detail-meta">${escape(record(e.fromId)?.title || 'Archived source')} ${relations[e.relation]} ${escape(record(e.toId)?.title || 'Archived source')}</p>`).join('') : '';
  $('#detail-content').innerHTML=`<div class="dialog-heading"><h2>${escape(r.title)}</h2><button class="icon-button" data-close>Close</button></div><div class="detail-meta">${kinds[r.type]} · ${escape(r.status)} · version ${r.revision}${r.due?' · due '+date(r.due):''}<br>${r.cloudAllowed?'Enabled for explicit AI selection':'Excluded from AI requests'}${r.tags.length?' · '+escape(r.tags.join(', ')):''}</div>${citedRevision&&Number(citedRevision)!==r.revision?`<p class="stale-message">The answer referenced version ${Number(citedRevision)}. You’re viewing version ${r.revision}, which has changed since that answer.</p>`:''}<div class="detail-body">${escape(r.body || 'No additional content.')}</div>${linkedHtml}<div class="dialog-actions">${r.archived?`<button class="button" data-action="restore" data-id="${r.id}">Restore</button>`:`<button class="button outline" data-action="archive" data-id="${r.id}">Archive</button><button class="button" data-action="edit" data-id="${r.id}">Edit record</button>`}</div>`;
  if(!$('#detail-dialog').open) $('#detail-dialog').showModal();
}
async function saveRecord(data,id,expectedRevision) {
  if(state.demo) { const previous=id?record(id):null;const r={...previous,...data,id:id || crypto.randomUUID(),revision:(previous?.revision || 0)+1,createdAt:previous?.createdAt || new Date().toISOString(),updatedAt:new Date().toISOString(),archived:false};state.records=[r,...state.records.filter(x=>x.id!==r.id)];return r; }
  const result=await api(id?`/api/records/${id}`:'/api/records',id?{...data,expectedRevision:expectedRevision ?? record(id).revision}:data,id?'PATCH':'POST');
  state.records=[result.record,...state.records.filter(x=>x.id!==result.record.id)];return result.record;
}
function confirmAction(title,copy,button,action) {
  $('#confirm-title').textContent=title;$('#confirm-copy').textContent=copy;$('#confirm-action').textContent=button;
  $('#confirm-action').onclick=async()=>{const btn=$('#confirm-action');btn.disabled=true;try { await action();$('#confirm-dialog').close(); } catch(e){notice(e.message,true);}finally{btn.disabled=false;}};
  $('#confirm-dialog').showModal();
}
async function archive(id,restore=false) {
  if(state.demo) { const r=record(id);r.archived=!restore;r.revision++; }
  else {const result=await api(`/api/records/${id}${restore?'/restore':''}`,restore?{}:undefined,restore?'POST':'DELETE');state.records=state.records.map(r=>r.id===id?result.record:r);}
  state.selected.delete(id);$('#detail-dialog').close();render();toast(restore?'Record restored.':'Record archived. You can restore it in Settings.');
}
function showReview(data) {
  state.prepared=data;clearTimeout(reviewExpiryTimer);
  const request=data.request || {question:state.draftQuestion,mode:state.draftMode,tier:state.draftTier};
  $('#context-review').innerHTML=`<div class="dialog-heading"><h2>Review this request</h2><button data-close class="icon-button">Close</button></div><p class="form-note">Destination: OpenAI · ${escape(data.receipt.model)}<br>Mode: ${escape(request.mode)} · expires ${new Date(data.receipt.expiresAt).toLocaleTimeString()}</p><h3 class="section-title">Your question</h3><div class="detail-body">${escape(request.question)}</div><p class="form-note">${escape(data.receipt.coverage.summary)}</p>${data.evidence.map(e=>`<section class="review-source"><h3>${escape(e.title)} · v${e.revision}</h3><pre>${escape(e.excerpt)}</pre></section>`).join('')}<h3 class="section-title list-section">Selected relationships</h3>${data.relations.length?data.relations.map(e=>`<p class="form-note">${escape(record(e.fromId)?.title)} ${relations[e.relation]} ${escape(record(e.toId)?.title)}</p>`).join(''):'<p class="form-note">No direct links among selected records.</p>'}${request.wire?`<details><summary>Complete outbound request</summary><pre class="wire-preview">${escape(request.wire)}</pre></details>`:''}<p class="review-hash">SHA-256: ${escape(data.receipt.hash)}</p><p class="form-note">Pressing Send shares this question and reviewed context with OpenAI using your account’s key. Source permissions and versions are checked again before dispatch.</p><p id="send-error" role="alert" class="form-error"></p><div class="dialog-actions"><button type="button" class="button outline" data-action="prepare-again" hidden>Review fresh request</button><button data-close class="button outline">Cancel</button>${state.session.user.hasKey?'<button class="button" data-action="send">Send this request</button>':'<button class="button" data-action="key-settings">Connect your key first</button>'}</div>`;
  if(!$('#context-dialog').open)$('#context-dialog').showModal();
  const expiry=()=>{if(state.prepared?.receipt.id!==data.receipt.id || !$('#context-dialog').open)return;const send=$('#context-review [data-action=send]');if(send){send.disabled=true;send.textContent='Review expired';}$('#send-error').textContent='This review expired. Prepare a fresh request before sending.';$('#context-review [data-action=prepare-again]').hidden=false;syncReviewControls();};
  reviewExpiryTimer=setTimeout(expiry,Math.max(0,new Date(data.receipt.expiresAt).valueOf()-Date.now()));
}
$('#context-dialog').addEventListener('close',()=>{clearTimeout(reviewExpiryTimer);syncReviewControls();});
function demoWorkspace() {
  state.demo=true;const now=new Date().toISOString();const ids=Array.from({length:5},()=>crypto.randomUUID());
  const examples=[['project','Field notebook','A fictional project: make a short guide to the night sky.'],['note','Observation notes','Clear sky at 21:00. The best view was away from street lights. Keep the guide readable without specialised equipment.'],['task','Draft the first page','Explain what a reader can look for in ten minutes.'],['goal','A guide someone can use','A reader can identify three constellations from the guide.'],['personal','Working preferences','Fictional preference: short writing sessions and concrete examples.']];
  state.records=examples.map((e,i)=>({id:ids[i],type:e[0],title:e[1],body:e[2],status:i===0?'active':'open',projectId:i===2?ids[0]:null,due:null,tags:['example'],cloudAllowed:i!==4,revision:1,archived:false,createdAt:now,updatedAt:now}));
  state.edges=[{id:crypto.randomUUID(),fromId:ids[1],toId:ids[2],relation:'supports',createdAt:now},{id:crypto.randomUUID(),fromId:ids[2],toId:ids[0],relation:'part_of',createdAt:now}];
  notice('Fictional example · changes stay in this page and are not saved. Sign in for your private workspace.');render();window.scrollTo({top:0,behavior:'instant'});
}
async function importFile(file) {
  if(!file) return;if(file.size>2*1024*1024) throw new Error('Import a file smaller than 2 MB.');
  const text=await file.text();let sources,edges=[];
  if(file.name.toLowerCase().endsWith('.json')) { const data=JSON.parse(text);if(!Array.isArray(data.records)) throw new Error('Choose an Aero export with a records array.');sources=data.records.filter(r=>!r.archived);edges=Array.isArray(data.edges)?data.edges:[]; }
  else sources=[{type:'note',title:file.name.replace(/\.[^.]+$/,''),body:text,status:'open',tags:[]}];
  if(!sources.length||sources.length>100) throw new Error('Import between 1 and 100 active records at a time.');
  const ids=new Map(sources.filter(r=>r.id).map(r=>[r.id,crypto.randomUUID()]));
  const safe=sources.map(r=> {if(!kinds[r.type]||typeof r.title!=='string'||!r.title.trim()||r.title.length>160||typeof(r.body || '')!=='string'||(r.body || '').length>16000) throw new Error('A record is invalid or exceeds the editor limits.');return {id:ids.get(r.id) || crypto.randomUUID(),type:r.type,title:r.title,body:r.body || '',status:['open','active','done'].includes(r.status)?r.status:'open',tags:Array.isArray(r.tags)?r.tags.filter(t=>typeof t==='string'&&t.length<=40).slice(0,12):[],due:r.due || null,projectId:ids.get(r.projectId) || null,cloudAllowed:false};});
  const queue=[];const pending=[...safe];const done=new Set();
  while(pending.length) {const index=pending.findIndex(r=>!r.projectId||done.has(r.projectId));if(index<0) throw new Error('The import contains a cycle or missing parent project.');const [r]=pending.splice(index,1);queue.push(r);done.add(r.id);}
  confirmAction(`Import ${safe.length} records?`,'Copies will be created in this account. Every imported record starts excluded from AI. Your existing records will remain.','Import records',async()=>{
    let saved=0;try {for(const r of queue) {await saveRecord(r);saved++;}for(const e of edges) if(ids.has(e.fromId)&&ids.has(e.toId)&&relations[e.relation]) {const edge={fromId:ids.get(e.fromId),toId:ids.get(e.toId),relation:e.relation};if(state.demo) state.edges.push({...edge,id:crypto.randomUUID()});else await api('/api/edges',edge);}await loadWorkspace();render();toast(`${saved} records imported.`);}catch(e){await loadWorkspace();render();throw new Error(`${saved} records imported before this issue: ${e.message}`);}
  });
}

document.addEventListener('click',async event=>{
  const close=event.target.closest('[data-close]');if(close){close.closest('dialog')?.close();return;}
  const view=event.target.closest('[data-view]');if(view){event.preventDefault();navigate(view.dataset.view);return;}
  const filter=event.target.closest('[data-filter]');if(filter){state.filter=filter.dataset.filter;render();return;}
  const button=event.target.closest('[data-action]');if(!button||button.disabled)return;
  const {action,id,type,revision,conversation:conversationId}=button.dataset;
  try {
    if(action==='add') openRecord(type);
    if(action==='detail')detail(id,revision);
    if(action==='citation')showCitation(conversationId,id,revision);
    if(action==='remove-source'){state.selected.delete(id);invalidatePrepared();syncSources();}
    if(action==='choose-context'){const inspector=$('#context-inspector');if(inspector){inspector.open=true;state.inspectorOpen=true;inspector.scrollIntoView({block:'start',behavior:'instant'});$('#source-search').focus({preventScroll:true});}}
    if(action==='new-conversation'){if(state.sending)return toast('A request is still in progress. You can read other work while it finishes.');invalidatePrepared();state.latest=null;state.selected.clear();state.draftQuestion='';state.draftMode='answer';state.sourceSearch='';state.sourceType='all';await navigate('ask');$('#aero-question')?.focus({preventScroll:true});}
    if(action==='starter'){state.draftMode=button.dataset.starter==='plan'?'plan':'answer';state.draftQuestion=state.draftMode==='plan'?'What is the next useful step for this project? Propose a plan grounded in the selected records.':'What do these selected notes tell me? Identify the main ideas, tensions and unanswered questions.';invalidatePrepared();render();$('#aero-question')?.focus({preventScroll:true});}
    if(action==='prepare-again'){$('#context-dialog').close();invalidatePrepared();await prepareRequest();}
    if(action==='edit') {$('#detail-dialog').close();openRecord('note',id);}
    if(action==='demo') demoWorkspace();
    if(action==='archive') confirmAction('Archive this record?','It will leave current work and AI selection. You can restore it in Settings.','Archive record',()=>archive(id));
    if(action==='restore') await archive(id,true);
    if(action==='relation') {const options=activeRecords().map(r=>`<option value="${r.id}">${escape(r.title)}</option>`).join('');$('#relation-form').reset();$('#relation-form').elements.fromId.innerHTML=options;$('#relation-form').elements.toId.innerHTML=options;$('#relation-form').elements.toId.selectedIndex=1;$('#relation-error').textContent='';$('#relation-dialog').showModal();}
    if(action==='unlink') confirmAction('Remove this relationship?','The records remain. You can add the relationship again.','Remove link',async()=>{if(!state.demo)await api(`/api/edges/${id}`,undefined,'DELETE');state.edges=state.edges.filter(e=>e.id!==id);render();});
    if(action==='key-settings') {$('#context-dialog').close();navigate('settings');}
    if(action==='send') {
      const prepared=state.prepared;if(!prepared || state.sending)return;
      const receiptId=prepared.receipt.id;const draftAtSend=draftRevision;const navigationAtSend=navigationRevision;const generationAtSend=conversationGeneration;
      state.sending=true;button.disabled=true;button.textContent='Waiting for Aero…';$('#send-error').textContent='';syncReviewControls();
      try {
        const result=await api('/api/context/send',{receiptId});
        state.conversations=[result.conversation,...state.conversations.filter(c=>c.id!==result.conversation.id)];
        const current=state.prepared?.receipt.id===receiptId;
        const ownsSurface=current && draftRevision===draftAtSend && navigationRevision===navigationAtSend && conversationGeneration===generationAtSend;
        if(current){state.prepared=null;clearTimeout(reviewExpiryTimer);if($('#context-dialog').open)$('#context-dialog').close();}
        if(ownsSurface){state.latest=result.conversation;conversationGeneration++;state.draftQuestion='';render();if(['home','ask'].includes(state.view))$('.conversation-answer')?.scrollIntoView({block:'start',behavior:'instant'});}else updateChrome();
        toast('Answer saved to your private workspace.');
      }catch(error){
        const current=state.prepared?.receipt.id===receiptId;if(current){state.prepared=null;clearTimeout(reviewExpiryTimer);}
        const target=$('#send-error');if(current&&target){target.textContent=error.message;const retry=$('#context-review [data-action=prepare-again]');if(retry)retry.hidden=false;button.hidden=true;}else notice(error.message,true);
      }finally{state.sending=false;syncReviewControls();}
    }
    if(action==='conversation'){state.latest=state.conversations.find(c=>c.id===id);conversationGeneration++;closeSidebar(false);if(!['home','ask'].includes(state.view))await navigate('ask');else render();$('.conversation-answer')?.scrollIntoView({block:'start',behavior:'instant'});$('#workspace').focus({preventScroll:true});}
    if(action==='apply') {const conversation=state.conversations.find(c=>c.proposal?.id===id);confirmAction('Accept this plan into Work?',`This will create ${conversation?.answer.steps.length || 'the proposed'} tasks and their dependency links. Source versions will be checked again.`,'Accept plan',async()=>{await api(`/api/proposals/${id}/apply`,{});await loadWorkspace();state.latest=state.conversations.find(c=>c.id===conversation?.id);render();toast('Plan accepted. The tasks are now in Work.');});}
    if(action==='export') {let blob;if(state.demo)blob=new Blob([JSON.stringify({version:1,records:state.records,edges:state.edges,preferences:state.preferences,conversations:[]},null,2)],{type:'application/json'});else{const expected=state.session.user.id;const r=await fetch('/api/export',{credentials:'same-origin',cache:'no-store',headers:{'X-Aero-Account':expected}});if(!r.ok){if(r.status===401 || r.status===409)accountInvalidated();throw new Error('The export could not be completed. Reload Aero if your sign-in changed.');}if(state.session?.user?.id!==expected)throw new Error('Your sign-in changed. Reload Aero before exporting.');blob=await r.blob();if(state.session?.user?.id!==expected)throw new Error('Your sign-in changed while the export was loading. Reload Aero.');}const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`aero-export-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);}
    if(action==='remove-key') confirmAction('Remove your personal key?','AI will use no key unless this is the verified founder account. Its server-configured key remains available.','Remove personal key',async()=>{Object.assign(state.session.user,await api('/api/settings/key',undefined,'DELETE'));render();toast('Personal key removed.');});
  }catch(e){notice(e.message,true);}
});
document.addEventListener('input',event=> {
  if(event.target.id==='record-search'){state.search=event.target.value;const view=state.view;const scoped=activeRecords().filter(r=>view==='work'?['project','task','goal'].includes(r.type):r.type===(view==='context'?'note':view==='journal'?'log':'personal'));$('#filtered-records').innerHTML=filteredRows(scoped);}
  if(event.target.name==='question'){state.draftQuestion=event.target.value;invalidatePrepared();syncReviewControls();}
  if(event.target.id==='source-search'){state.sourceSearch=event.target.value;filterSources();}
});
document.addEventListener('change',async event=>{
  const target=event.target;
  try {
    if(target.dataset.source){if(target.checked&&state.selected.size>=12){target.checked=false;toast('Select up to 12 records.');return;}target.checked?state.selected.add(target.dataset.source):state.selected.delete(target.dataset.source);invalidatePrepared();syncSources();}
    if(target.dataset.task){target.disabled=true;try{await saveRecord({status:target.checked?'done':'open'},target.dataset.task);render();}catch(e){target.checked=!target.checked;throw e;}finally{target.disabled=false;}}
    if(target.name==='mode'){state.draftMode=target.value;invalidatePrepared();syncReviewControls();}
    if(target.name==='tier'){state.draftTier=target.value;invalidatePrepared();syncReviewControls();}
    if(target.id==='source-type'){state.sourceType=target.value;filterSources();}
    if(target.id==='import-file')await importFile(target.files[0]);
  }catch(e){notice(e.message,true);}
});
$('#record-form').addEventListener('submit',async event=> {
  event.preventDefault();const form=event.target;const submit=form.querySelector('[type=submit]');submit.disabled=true;$('#record-error').textContent='';
  try {const data={type:form.elements.type.value,title:form.elements.title.value.trim(),body:form.elements.body.value,status:form.elements.status.value,projectId:form.elements.projectId.value || null,due:form.elements.due.value || null,tags:form.elements.tags.value.split(',').map(t=>t.trim()).filter(Boolean),cloudAllowed:form.elements.cloudAllowed.checked};if(data.tags.length>12||data.tags.some(t=>t.length>40))throw new Error('Use up to 12 tags, each no more than 40 characters.');await saveRecord(data,editing?.id,editing?.revision);$('#record-dialog').close();render();toast(state.demo?'Example updated in this page.':'Record saved.');}catch(e){$('#record-error').textContent=e.message+(e.code==='revision_conflict'?' Your draft is preserved. Copy it, then reopen the updated record.':'');if(e.code==='revision_conflict')await loadWorkspace();}finally{submit.disabled=false;}
});
$('#relation-form').addEventListener('submit',async event=> {
  event.preventDefault();const form=event.target;const data={fromId:form.elements.fromId.value,toId:form.elements.toId.value,relation:form.elements.relation.value};const submit=form.querySelector('[type=submit]');submit.disabled=true;
  try{if(data.fromId===data.toId)throw new Error('Choose two different records.');const result=state.demo?{edge:{...data,id:crypto.randomUUID()}}:await api('/api/edges',data);state.edges=[...state.edges.filter(e=>e.id!==result.edge.id),result.edge];$('#relation-dialog').close();render();toast('Relationship saved.');}catch(e){$('#relation-error').textContent=e.message;}finally{submit.disabled=false;}
});
document.addEventListener('submit',async event=> {
  const form=event.target;if(!['ask-form','preferences-form','key-form'].includes(form.id))return;event.preventDefault();const button=form.querySelector('[type=submit]');button.disabled=true;
  try{
    if(form.id==='ask-form'){await prepareRequest();}
    if(form.id==='preferences-form'){const preferences={...state.preferences,workspaceName:form.elements.workspaceName.value.trim(),timezone:form.elements.timezone.value.trim(),tone:form.elements.tone.value};if(!validTimezone(preferences.timezone))throw new Error('Enter a recognised time zone, such as Asia/Kolkata.');state.preferences=state.demo?preferences:(await api('/api/settings',{preferences})).preferences;updateChrome();notice();toast('Preferences saved.');}
    if(form.id==='key-form'){const key=form.elements.key.value.trim();try{Object.assign(state.session.user,await api('/api/settings/key',{key}));}finally{form.elements.key.value='';}render();toast('Your private key is connected.');}
  }catch(e){const target=form.id==='ask-form'?$('#ask-error'):null;if(target)target.textContent=e.message;else notice(e.message,true);}finally{button.disabled=false;if(form.id==='ask-form')syncReviewControls();}
});
$('#quick-add').addEventListener('click',()=>openRecord(state.view==='personal'?'personal':state.view==='journal'?'log':state.view==='work'?'task':'note'));
function closeSidebar(restore=true) {
  $('.sidebar').classList.remove('open');$('.sidebar').removeAttribute('role');$('.sidebar').removeAttribute('aria-modal');
  $('.sidebar').inert=matchMedia('(max-width:720px)').matches;
  $('.app-main').inert=false;$('#sidebar-backdrop').hidden=true;$('#menu-toggle').setAttribute('aria-expanded','false');document.documentElement.style.overflow='';
  if(restore)$('#menu-toggle').focus({preventScroll:true});
}
$('#menu-toggle').addEventListener('click',()=>{
  if($('.sidebar').classList.contains('open'))return closeSidebar();
  $('.sidebar').inert=false;$('.sidebar').classList.add('open');$('.sidebar').setAttribute('role','dialog');$('.sidebar').setAttribute('aria-modal','true');$('.app-main').inert=true;$('#sidebar-backdrop').hidden=false;$('#menu-toggle').setAttribute('aria-expanded','true');document.documentElement.style.overflow='hidden';$('#sidebar-close').focus();
});
$('#sidebar-close').addEventListener('click',()=>closeSidebar());$('#sidebar-backdrop').addEventListener('click',()=>closeSidebar());
document.addEventListener('keydown',event=>{
  if(!$('.sidebar').classList.contains('open'))return;
  if(event.key==='Escape'){event.preventDefault();closeSidebar();}
  if(event.key==='Tab'){const nodes=[...$('.sidebar').querySelectorAll('a,button')].filter(n=>!n.disabled&&n.getBoundingClientRect().height>0);const first=nodes[0],last=nodes.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
});
matchMedia('(max-width:720px)').addEventListener('change',()=>closeSidebar(false));
window.addEventListener('pagehide',()=>closeSidebar(false));
window.addEventListener('pageshow',()=>closeSidebar(false));
closeSidebar(false);
document.addEventListener('toggle',event=>{if(event.target.id==='context-inspector')state.inspectorOpen=event.target.open;},true);
$('#signout').addEventListener('click',async()=>{try{await api('/api/logout',undefined,'POST');clearPrivateState();accountChannel?.postMessage({accountId:null});notice();navigate('home');}catch(e){notice(e.message,true);}});
document.addEventListener('keydown',event=>{if((event.key==='Enter'||event.key===' ')&&event.target.matches('.graph-node')){event.preventDefault();detail(event.target.dataset.id);}});
window.addEventListener('popstate',()=>navigate(viewFromPath(),false));
async function start() {
  try {state.session=await api('/api/session');if(state.session.authenticated)await loadWorkspace();accountChannel?.postMessage({accountId:state.session?.user?.id || null});const params=new URLSearchParams(location.search);if(params.has('auth_error')){notice('Google sign-in could not complete. Please try again.',true);history.replaceState({},'',location.pathname);}render();}
  catch(e){state.session={authenticated:false};render();notice(e.message,true);}
}
function registerBrowserTools() {
  const context=document.modelContext;if(!context?.registerTool)return;
  const lifecycle=new AbortController();
  window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
  const requireAccount=()=>{if(!state.session?.authenticated || state.demo)throw new Error('Sign in to Aero before using this tool.');};
  const validInput=(input,keys)=>{if(!input || typeof input!=='object' || Array.isArray(input) || Object.keys(input).some(key=>!keys.includes(key)))throw new Error('Invalid tool input.');};
  const tools=[{
    name:'list_aero_ai_sources',title:'List selectable Aero sources',
    description:'Read the IDs, titles, types and versions of records explicitly enabled for AI in the signed-in Aero account. Returns no bodies, keys, conversations or excluded personal records.',
    inputSchema:{type:'object',properties:{},additionalProperties:false},
    annotations:{readOnlyHint:true,untrustedContentHint:true},
    async execute(input){validInput(input,[]);requireAccount();await loadWorkspace();render();return {sources:activeRecords().filter(r=>r.cloudAllowed).map(r=>({id:r.id,title:r.title,type:r.type,revision:r.revision})),maxSelected:12};}
  },{
    name:'prepare_aero_request_review',title:'Prepare an Aero request for review',
    description:'Stage a question and explicitly chosen record IDs in Aero’s visible context review. Saves a private receipt and shows the exact outbound request. Does not send to OpenAI or accept a plan; the user completes those steps in the interface.',
    inputSchema:{type:'object',properties:{question:{type:'string',minLength:1,maxLength:4000},recordIds:{type:'array',items:{type:'string'},uniqueItems:true,maxItems:12},mode:{type:'string',enum:['answer','plan']},tier:{type:'string',enum:['luna','sol']}},required:['question','recordIds','mode','tier'],additionalProperties:false},
    annotations:{readOnlyHint:false,untrustedContentHint:true},
    async execute(input){
      validInput(input,['question','recordIds','mode','tier']);requireAccount();
      if(typeof input.question!=='string' || !input.question.trim() || input.question.length>4000 || !['answer','plan'].includes(input.mode) || !['luna','sol'].includes(input.tier) || !Array.isArray(input.recordIds) || input.recordIds.length>12 || new Set(input.recordIds).size!==input.recordIds.length || input.recordIds.some(id=>typeof id!=='string'))throw new Error('Provide a question, model, response mode and up to 12 distinct source IDs.');
      const toolRevision=++prepareToolRevision;const initialNavigation=navigationRevision;
      const question=input.question.trim();const recordIds=[...input.recordIds];const mode=input.mode;const tier=input.tier;
      const interrupted=()=>{throw new Error('The workspace changed while the review was being prepared. Please try again from Ask Aero.');};
      await loadWorkspace();if(input.recordIds.some(id=>!record(id)?.cloudAllowed || record(id)?.archived))throw new Error('Every source must be current and explicitly enabled for AI.');
      if(toolRevision!==prepareToolRevision || initialNavigation!==navigationRevision)interrupted();requireAccount();
      state.draftQuestion=question;state.draftMode=mode;state.draftTier=tier;state.selected=new Set(recordIds);
      const navigationDone=navigate('ask');const stagedNavigation=navigationRevision;await navigationDone;
      const checkStaged=()=>{requireAccount();if(toolRevision!==prepareToolRevision || stagedNavigation!==navigationRevision || state.view!=='ask')interrupted();};
      checkStaged();const data=await api('/api/context/prepare',{question,mode,tier,recordIds});checkStaged();showReview(data);
      return {status:'awaiting_user_review',receiptId:data.receipt.id,hash:data.receipt.hash,model:data.receipt.model,recordCount:data.receipt.recordCount,expiresAt:data.receipt.expiresAt};
    }
  }];
  for(const tool of tools){try{Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}}
}
start().then(registerBrowserTools);
