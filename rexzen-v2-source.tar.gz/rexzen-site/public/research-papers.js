(() => {
  'use strict';
  const unlock = document.querySelector('[data-paper-unlock]');
  const access = document.querySelector('#paper-access');
  const form = document.querySelector('#research-unlock');
  const input = document.querySelector('#research-password');
  const status = document.querySelector('#paper-access-status');
  const selected = document.querySelector('#paper-access-selected');
  const libraryStatus = document.querySelector('#paper-library-status');
  const reader = document.querySelector('#paper-reader');
  const frame = reader?.querySelector('iframe');
  const readerTitle = reader?.querySelector('[data-paper-reader-title]');
  const readerDownload = reader?.querySelector('[data-paper-reader-download]');
  const readerOpen = reader?.querySelector('[data-paper-reader-open]');
  const buttons = [...document.querySelectorAll('[data-paper-action]')];
  if (!unlock || !access?.showModal || !form || !reader?.showModal || !crypto.subtle) return;
  const papers = new Map([...document.querySelectorAll('[data-paper-record]')].map(record => [record.id, {
    title: record.querySelector('h3').textContent,
    record
  }]));
  const envelopes = new Map();
  const files = new Map();
  let secret = null, pending = null, revision = 0, activeButton = null;
  const decode = value => Uint8Array.from(atob(value), character => character.charCodeAt(0));
  function reflect() {
    unlock.textContent = secret ? 'Lock PDFs' : 'Unlock PDFs';
    libraryStatus.textContent = secret ? 'PDFs unlocked for this page.' : 'PDFs are locked.';
    document.querySelector('#papers').dataset.paperAccess = secret ? 'unlocked' : 'locked';
  }
  function clearReader() {
    frame.removeAttribute('src');
    readerDownload.removeAttribute('href');
    readerOpen.removeAttribute('href');
  }
  function lock() {
    revision++;
    secret?.fill(0); secret = null; pending = null;
    input.value = '';
    if (access.open) access.close();
    if (reader.open) reader.close();
    clearReader();
    for (const file of files.values()) URL.revokeObjectURL(file.url);
    files.clear();
    buttons.forEach(button => { button.disabled = false; });
    form.querySelector('[type="submit"]').disabled = false;
    reflect();
  }
  async function envelope(id) {
    if (envelopes.has(id)) return envelopes.get(id);
    if (!papers.has(id)) throw new Error('This paper is not in the directory.');
    const response = await fetch(papers.get(id).record.dataset.paperFile, {credentials:'omit'});
    if (!response.ok) throw new Error('The PDF could not be loaded. Please try again.');
    const data = await response.json();
    if (data.format !== 'rexzen-research-v1' || data.id !== id || data.algorithm !== 'AES-256-GCM' ||
        data.kdf !== 'PBKDF2-SHA256' || data.iterations !== 600000 ||
        !/^[a-z0-9-]+\.pdf$/.test(data.filename) || !/^[a-f0-9]{64}$/.test(data.sha256))
      throw new Error('This PDF has an unsupported file format.');
    envelopes.set(id, data);
    return data;
  }
  async function prepare(id, password, expectedRevision) {
    if (files.has(id)) return files.get(id);
    const data = await envelope(id);
    const material = await crypto.subtle.importKey('raw', password, 'PBKDF2', false, ['deriveKey']);
    const key = await crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt:decode(data.salt),iterations:data.iterations},
      material, {name:'AES-GCM',length:256}, false, ['decrypt']);
    let plain;
    try {
      plain = new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(data.iv),
        additionalData:new TextEncoder().encode(`rexzen-research-v1:${id}`)}, key, decode(data.ciphertext)));
    } catch { throw new Error('That password did not unlock the PDF. Check it and try again.'); }
    try {
      if (new TextDecoder().decode(plain.subarray(0,5)) !== '%PDF-') throw new Error('This file is not a PDF.');
      const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256', plain))].map(n => n.toString(16).padStart(2,'0')).join('');
      if (hash !== data.sha256) throw new Error('The PDF could not be checked. Please try again.');
      if (expectedRevision !== revision) return null;
      const file = {url:URL.createObjectURL(new Blob([plain], {type:'application/pdf'})), filename:data.filename};
      files.set(id, file);
      return file;
    } finally { plain.fill(0); }
  }
  function deliver(id, action, file) {
    if (action === 'download') {
      const link = document.createElement('a');
      link.href = file.url; link.download = file.filename;
      document.body.append(link); link.click(); link.remove();
      libraryStatus.textContent = 'PDF download started.';
      return;
    }
    readerTitle.textContent = papers.get(id).title;
    readerDownload.href = file.url; readerDownload.download = file.filename;
    readerOpen.href = file.url;
    frame.title = papers.get(id).title; frame.src = file.url;
    reader.showModal();
  }
  function ask(action = null) {
    pending = action;
    selected.textContent = action ? papers.get(action.id).title : 'Unlock the research PDFs for this page.';
    status.textContent = 'Enter the shared password.';
    input.value = '';
    access.showModal();
    input.focus();
  }
  unlock.addEventListener('click', () => secret ? lock() : ask());
  access.querySelector('[data-paper-access-close]').addEventListener('click', () => access.close());
  access.addEventListener('close', () => {
    input.value = '';
    revision++;
    pending = null;
    form.querySelector('[type="submit"]').disabled = false;
  });
  reader.querySelector('[data-paper-reader-close]').addEventListener('click', () => reader.close());
  reader.addEventListener('close', clearReader);
  for (const dialog of [access, reader]) dialog.addEventListener('click', event => {
    if (event.target !== dialog) return;
    const box = dialog.getBoundingClientRect();
    if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close();
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const submit = form.querySelector('[type="submit"]');
    if (submit.disabled) return;
    submit.disabled = true;
    const action = pending;
    const id = action?.id || papers.keys().next().value;
    const password = new TextEncoder().encode(input.value);
    input.value = '';
    const version = ++revision;
    status.textContent = 'Unlocking the PDF...';
    try {
      const file = await prepare(id, password, version);
      if (version !== revision || !file || !access.open) { password.fill(0); return; }
      secret?.fill(0); secret = password;
      access.close();
      reflect();
      if (action) deliver(id, action.action, file);
    } catch (error) {
      password.fill(0);
      if (version === revision && access.open) { status.textContent = error.message; input.focus(); }
    } finally { submit.disabled = false; }
  });
  buttons.forEach(button => button.addEventListener('click', async () => {
    const id = button.dataset.paper;
    const action = button.dataset.paperAction;
    activeButton = button;
    if (!secret) { ask({id,action}); return; }
    button.disabled = true;
    const version = revision;
    libraryStatus.textContent = 'Preparing the PDF...';
    try {
      const file = await prepare(id, secret, version);
      if (version === revision && file && secret) { reflect(); deliver(id, action, file); }
    } catch (error) { if (version === revision) libraryStatus.textContent = error.message; }
    finally { button.disabled = false; }
  }));
  reader.addEventListener('close', () => activeButton?.focus({preventScroll:true}));
  window.addEventListener('pagehide', lock);
  window.addEventListener('pageshow', event => { if (event.persisted) lock(); });
  reflect();
})();
