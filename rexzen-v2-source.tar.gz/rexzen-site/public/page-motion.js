(() => {
  'use strict';

  // This handoff contains only a public pathname, version and timestamp.
  const key = 'rexzen.public-page-motion.v1';
  const routes = new Set(['/', '/projects', '/focus', '/research', '/eos', '/rex-wm', '/2piarc', '/frontiers', '/about', '/principles', '/privacy']);
  const root = document.documentElement;
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  let overlay;
  let pendingURL;
  let committed = false;
  let exitTimer;
  let finishTimer;
  let guardTimer;
  let arriving = false;

  const removeHandoff = () => {
    try { sessionStorage.removeItem(key); } catch { /* Navigation still works without storage. */ }
  };
  const finish = () => {
    clearTimeout(exitTimer);
    clearTimeout(finishTimer);
    clearTimeout(guardTimer);
    root.removeAttribute('data-page-motion');
    arriving = false;
    pendingURL = undefined;
    committed = false;
  };

  try {
    const handoff = JSON.parse(sessionStorage.getItem(key) || 'null');
    removeHandoff();
    const age = Date.now() - handoff?.at;
    const navigationType = performance.getEntriesByType('navigation')[0]?.type;
    if (!preference.matches && routes.has(location.pathname) && !location.search && !location.hash && navigationType === 'navigate' &&
        handoff?.version === 1 && handoff?.to === location.pathname && age >= 0 && age < 10000) {
      arriving = true;
      root.setAttribute('data-page-motion', 'covered');
      // A failed or delayed page script must never leave the reading surface covered.
      guardTimer = setTimeout(finish, 3000);
    }
  } catch { removeHandoff(); }

  const navigate = () => {
    if (!pendingURL) return;
    const destination = pendingURL;
    clearTimeout(exitTimer);
    pendingURL = undefined;
    committed = true;
    try { sessionStorage.setItem(key, JSON.stringify({ to: new URL(destination).pathname, at: Date.now(), version: 1 })); } catch { /* Exit alone still works. */ }
    // Keep the cover until the next document paints, then clear if navigation fails.
    root.setAttribute('data-page-motion', 'covered');
    guardTimer = setTimeout(() => { removeHandoff(); finish(); }, 6000);
    try { location.assign(destination); } catch { removeHandoff(); finish(); }
  };

  const ready = () => {
    overlay = document.querySelector('[data-page-sweep]');
    if (!overlay) { finish(); return; }
    const mark = document.createElement('img');
    mark.className = 'page-sweep-mark';
    mark.src = '/brand/rexzen-mark.svg';
    mark.width = 64; mark.height = 64; mark.alt = '';
    overlay.append(mark);
    if (preference.matches) finish();
    if (arriving) {
      // Start from the first painted cover, not from an unseen initial frame.
      requestAnimationFrame(() => requestAnimationFrame(() => {
        if (!arriving || preference.matches || document.hidden) { finish(); return; }
        root.setAttribute('data-page-motion', 'arriving');
        // Prepare the headline before the first pane exposes the reading surface.
        document.dispatchEvent(new Event('site-page-uncover'));
        finishTimer = setTimeout(finish, 590);
      }));
    }

    document.addEventListener('click', (event) => {
      // While a slow destination loads, later activations retain native behavior.
      if (committed) { removeHandoff(); finish(); return; }
      const cancel = () => { if (pendingURL) finish(); };
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || preference.matches) return;
      const link = event.target instanceof Element ? event.target.closest('a[href]') : null;
      // A click on empty space does not withdraw an accepted navigation.
      if (!link) return;
      if (link.hasAttribute('download') || (link.target && link.target !== '_self') || link.hasAttribute('data-no-page-motion')) { cancel(); return; }
      let destination;
      try { destination = new URL(link.href); } catch { cancel(); return; }
      if (destination.origin !== location.origin || !routes.has(destination.pathname) || destination.search || destination.hash ||
          destination.pathname === location.pathname || !routes.has(location.pathname)) { cancel(); return; }
      if (getComputedStyle(overlay).position !== 'fixed') { cancel(); return; }

      event.preventDefault();
      // A second click updates the destination without restarting the sweep.
      const isDeparting = !!pendingURL;
      pendingURL = destination.href;
      if (isDeparting) return;
      clearTimeout(finishTimer);
      clearTimeout(guardTimer);
      arriving = false;
      root.setAttribute('data-page-motion', 'departing');
      document.dispatchEvent(new Event('site-navigation-start'));
      exitTimer = setTimeout(navigate, 250);
    });
  };

  document.addEventListener('DOMContentLoaded', ready, { once: true });
  window.addEventListener('pagehide', finish);
  window.addEventListener('pageshow', (event) => { if (event.persisted) { removeHandoff(); finish(); } });
  document.addEventListener('focusin', () => { if (arriving) finish(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && pendingURL) finish(); });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) return;
    if (pendingURL) navigate();
    else finish();
  });
  preference.addEventListener('change', () => {
    if (!preference.matches) return;
    if (pendingURL) navigate();
    else { removeHandoff(); finish(); }
  });
})();
