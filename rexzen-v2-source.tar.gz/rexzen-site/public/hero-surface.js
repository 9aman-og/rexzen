// An original, finite material study. No WebGL, network requests, or idle loop.
const figure = document.querySelector('[data-hero-surface]');
const canvas = figure?.querySelector('canvas');
const control = document.querySelector('[data-hero-playback]');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const context = canvas?.getContext('2d', {alpha: false});

if (figure && canvas && control && context) {
  const duration = 9600;
  let width = 0, height = 0, progress = 0, frame = null, last = 0;
  let playing = false, visible = !('IntersectionObserver' in window), disposed = false;
  let autoStartConsumed = false, dirty = true, pixelRatio = 0;
  const sweepObserver = new MutationObserver(maybeStart);
  const consumeAuto = () => { autoStartConsumed = true; sweepObserver.disconnect(); };
  const ease = t => t * t * (3 - 2 * t);
  const elevation = (x, z) => .68 * Math.exp(-.38 * ((x + .2) ** 2 + (z + .1) ** 2))
    + .23 * Math.sin(x * 1.24 + z * .68) + .10 * Math.cos(z * 2.0 - x * .7);

  function draw() {
    if (!width || !height) return;
    const scale = Math.max(width / 7.6, height / 4.0);
    const yaw = -.23 + .10 * ease(Math.min(progress / duration, 1));
    const c = Math.cos(yaw), s = Math.sin(yaw);
    const project = (x, z, y = elevation(x, z)) => [
      width * .60 + (x * c - z * s) * scale,
      height * .31 + (x * s + z * c) * scale * .47 - y * scale * .72
    ];
    const backdrop = context.createLinearGradient(0, 0, width, height);
    backdrop.addColorStop(0, '#15191d'); backdrop.addColorStop(.65, '#30373d'); backdrop.addColorStop(1, '#141b24');
    context.fillStyle = backdrop; context.fillRect(0, 0, width, height);
    const path = points => { context.beginPath(); points.forEach((p, i) => i ? context.lineTo(...p) : context.moveTo(...p)); };
    const rows = width < 700 ? 28 : 42;
    const steps = width < 700 ? 48 : 72;
    for (let row = 0; row < rows; row++) {
      const z = -3.8 + row * 7.6 / rows, back = [], front = [];
      for (let i = 0; i <= steps; i++) {
        const x = -5.8 + i * 11.6 / steps;
        back.push(project(x, z)); front.push(project(x, z + 7.6 / rows * .91));
      }
      path([...back, ...front.reverse()]); context.closePath();
      const material = context.createLinearGradient(0, height * .2, width, height * .7);
      const light = Math.round(50 + 14 * Math.cos(z * .9));
      material.addColorStop(0, `rgb(${light - 14} ${light - 10} ${light - 4})`);
      material.addColorStop(.52, `rgb(${light + 24} ${light + 28} ${light + 34})`);
      material.addColorStop(1, `rgb(${light - 10} ${light - 4} ${light + 5})`);
      context.fillStyle = material; context.fill();
      path(back); context.strokeStyle = 'rgba(222,230,236,.13)'; context.lineWidth = .6; context.stroke();
    }
    // Three routes pass across the same material. One carries a finite trace.
    const route = (t, offset) => {
      const x = -4.7 + t * 9.0;
      const z = .12 + .62 * Math.tanh((t - .32) * 16) - .62 * Math.tanh((t - .69) * 16) + offset;
      return project(x, z, elevation(x, z) + .025);
    };
    for (const offset of [-.15, 0, .15]) {
      path(Array.from({length: 111}, (_, i) => route(i / 110, offset)));
      context.strokeStyle = offset === 0 ? '#4268f3' : 'rgba(151,175,255,.35)';
      context.lineWidth = offset === 0 ? Math.max(3, scale * .025) : 1;
      context.lineJoin = 'round'; context.lineCap = 'round'; context.stroke();
    }
    const head = .06 + .89 * ease(Math.min(progress / duration, 1));
    const tail = Math.max(0, head - .15);
    path(Array.from({length: 31}, (_, i) => route(tail + (head - tail) * i / 30, 0)));
    context.strokeStyle = '#c8d6ff'; context.lineWidth = Math.max(2, scale * .011); context.stroke();
    const point = route(head, 0);
    context.beginPath(); context.arc(...point, Math.max(2.5, scale * .016), 0, Math.PI * 2);
    context.fillStyle = '#f3f7ff'; context.fill();
    figure.dataset.surfaceReady = 'true';
    figure.dataset.surfaceProgress = String(Math.round(progress));
  }

  function updateControl() {
    control.hidden = reduced.matches;
    control.textContent = playing ? 'Pause scene' : progress >= duration ? 'Replay scene' : 'Play scene';
    control.setAttribute('aria-label', control.textContent);
    figure.dataset.surfaceState = playing ? 'playing' : progress >= duration ? 'complete' : 'paused';
  }
  function stop() {
    playing = false;
    if (frame !== null) cancelAnimationFrame(frame);
    frame = null; last = 0; updateControl();
  }
  function tick(now) {
    frame = null;
    if (!playing || !visible || document.hidden || reduced.matches || disposed) { stop(); return; }
    if (last && now - last < 40) { frame = requestAnimationFrame(tick); return; }
    if (last) progress = Math.min(duration, progress + Math.min(now - last, 100));
    last = now; draw();
    if (progress >= duration) { stop(); return; }
    frame = requestAnimationFrame(tick);
  }
  function play() {
    if (document.hidden || !visible || reduced.matches || disposed) return;
    if (progress >= duration) progress = 0;
    playing = true; last = 0; updateControl();
    if (frame === null) frame = requestAnimationFrame(tick);
  }
  function maybeStart() {
    if (autoStartConsumed || disposed || !visible || document.hidden || reduced.matches || document.documentElement.hasAttribute('data-page-motion')) return;
    consumeAuto(); play();
  }
  function resize() {
    const bounds = figure.getBoundingClientRect();
    const ratio = Math.min(devicePixelRatio || 1, 1.25, 1600 / Math.max(bounds.width, 1));
    if (bounds.width === width && bounds.height === height && ratio === pixelRatio && !dirty) return;
    width = bounds.width; height = bounds.height; pixelRatio = ratio; dirty = true;
    if (!visible || document.hidden) return;
    canvas.width = Math.round(width * ratio); canvas.height = Math.round(height * ratio);
    context.setTransform(ratio, 0, 0, ratio, 0, 0); dirty = false; draw();
  }
  control.hidden = false;
  control.addEventListener('click', () => { consumeAuto(); playing ? stop() : play(); });
  const observer = 'ResizeObserver' in window ? new ResizeObserver(resize) : null;
  observer?.observe(figure); if (!observer) window.addEventListener('resize', resize, {passive: true});
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(entries => {
      visible = entries[0].isIntersecting && entries[0].intersectionRatio >= .08;
      if (!visible) { if (playing) consumeAuto(); stop(); }
      else { resize(); maybeStart(); }
    }, {threshold: .08}).observe(figure);
  }
  document.addEventListener('visibilitychange', () => { if (document.hidden) { if (playing) consumeAuto(); stop(); } else { resize(); maybeStart(); } });
  document.addEventListener('site-navigation-start', () => { consumeAuto(); stop(); });
  document.addEventListener('site-menu-open', () => { consumeAuto(); stop(); });
  figure.closest('.hero-stage').addEventListener('focusin', event => { if (event.target !== control) { consumeAuto(); stop(); } });
  window.addEventListener('pagehide', () => { consumeAuto(); stop(); disposed = true; });
  window.addEventListener('pageshow', () => { disposed = false; resize(); updateControl(); });
  reduced.addEventListener('change', () => { consumeAuto(); stop(); if (reduced.matches) { progress = duration; resize(); draw(); } updateControl(); });
  sweepObserver.observe(document.documentElement, {attributes: true, attributeFilter: ['data-page-motion']});
  resize();
  if (reduced.matches) { consumeAuto(); progress = duration; resize(); updateControl(); }
  else maybeStart();
}
