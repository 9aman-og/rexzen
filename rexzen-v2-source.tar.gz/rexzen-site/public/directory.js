(() => {
  const dialog = document.querySelector('#site-directory');
  const trigger = document.querySelector('.nav-toggle');
  if (!dialog?.showModal || !trigger) return;
  const root = document.documentElement;
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const close = dialog.querySelector('[data-directory-close]');
  const figure = dialog.querySelector('.directory-feature-image');
  const image = figure.querySelector('img');
  const spareImage = image.cloneNode();
  figure.setAttribute('role', 'img'); figure.setAttribute('aria-label', image.alt);
  image.alt = ''; spareImage.alt = '';
  image.setAttribute('aria-hidden', 'true'); spareImage.setAttribute('aria-hidden', 'true');
  image.dataset.fit = figure.dataset.fit || 'cover';
  image.style.opacity = '1'; spareImage.style.opacity = '0';
  figure.append(spareImage);
  let currentImage = image;
  const title = dialog.querySelector('[data-directory-title]');
  const label = dialog.querySelector('[data-directory-label]');
  const copy = dialog.querySelector('[data-directory-copy]');
  const featureLink = dialog.querySelector('[data-directory-link]');
  const sections = [...dialog.querySelectorAll('[data-directory-section]')];
  const pageLinks = [...dialog.querySelectorAll('a[data-directory-preview]')];
  let closingTimer = null, previewRevision = 0, imageAnimations = [];
  const previews = {
    projects: {label:'PROJECTS',src:'/images/menu-about.svg',fit:'contain',title:'Software and research.',copy:'Aero for your notes. Rex for studying how models learn.',href:'/projects',link:'All projects',alt:'Rexzen software and research'},
    aero: {label:'AERO',src:'/images/menu-aero.svg',fit:'contain',title:'Reason from your own notes.',copy:'A private workspace for notes, AI answers and plans you review.',href:'/focus',link:'Explore Aero',alt:'An illustration of selected notes in Aero'},
    wm: {label:'REX',src:'/images/menu-rex.svg',fit:'contain',title:'Predict simulated motion.',copy:'A downloadable research prototype for one-dimensional simulated motion.',href:'/rex-wm',link:'Explore Rex',alt:'An illustration of prediction, observation and correction'},
    division: {label:'2πarc',src:'/images/menu-2piarc.svg',fit:'contain',title:'Models that learn from change.',copy:'2πarc is Rexzen’s research division. We study prediction, adaptation and earlier learning.',href:'/2piarc',link:'Explore 2πarc',alt:'The 2πarc wordmark with an orbital study'},
    eos: {label:'EOS / 2πarc',src:'/images/eos-system.svg',fit:'contain',title:'Evidence before lasting change.',copy:'A research program on world models, memory and evidence for persistent change.',href:'/eos',link:'Explore EOS',alt:'Conceptual diagram of prediction and evidence in the proposed EOS architecture'},
    research: {label:'RESEARCH',src:'/images/menu-2piarc.svg',fit:'contain',title:'Inside the research.',copy:'Papers on world models, adaptation and decisions. Read the summaries, then unlock a PDF.',href:'/research',link:'Research directory',alt:'The 2πarc research division'},
    about: {label:'ABOUT REXZEN',src:'/images/menu-about.svg',fit:'contain',title:'About Rexzen.',copy:'AI software and world model research, founded by Aman Agarwal.',href:'/about',link:'About Rexzen',alt:'Rexzen software and research'}
  };
  function settleImages() {
    imageAnimations.forEach(animation => animation.cancel()); imageAnimations = [];
    for (const layer of [image, spareImage]) {
      layer.style.opacity = layer === currentImage ? '1' : '0';
      layer.style.transform = 'none';
    }
  }
  function closeNow(restoreFocus = false) {
    clearTimeout(closingTimer); closingTimer = null;
    previewRevision++; settleImages();
    if (dialog.open) dialog.close();
    dialog.removeAttribute('data-state'); root.classList.remove('directory-open');
    root.classList.toggle('page-sleeping', document.hidden);
    trigger.setAttribute('aria-expanded', 'false');
    if (restoreFocus) trigger.focus({preventScroll: true});
  }
  function dismiss() {
    if (!dialog.open || closingTimer !== null) return;
    if (preference.matches) { closeNow(true); return; }
    dialog.dataset.state = 'closing';
    closingTimer = setTimeout(() => closeNow(true), 190);
  }
  async function preview(key) {
    const next = previews[key]; if (!next || !dialog.open) return;
    const revision = ++previewRevision;
    // Navigation feedback must not wait for image decoding or connectivity.
    title.textContent = next.title; copy.textContent = next.copy;
    if (label) label.textContent = next.label;
    featureLink.href = next.href; featureLink.textContent = next.link;
    const preload = new Image(); preload.src = next.src;
    try { await preload.decode(); } catch { return; }
    if (revision !== previewRevision || !dialog.open) return;
    settleImages();
    const outgoing = currentImage;
    const incoming = currentImage === image ? spareImage : image;
    incoming.src = next.src; incoming.dataset.fit = next.fit || 'cover';
    figure.setAttribute('aria-label', next.alt);
    currentImage = incoming;
    if (preference.matches || !incoming.animate) { settleImages(); return; }
    imageAnimations = [
      outgoing.animate([{opacity: 1}, {opacity: 0}], {duration: 240, easing: 'ease-out', fill: 'both'}),
      incoming.animate([{opacity: 0, transform: 'scale(1.015)'}, {opacity: 1, transform: 'none'}], {duration: 240, easing: 'ease-out', fill: 'both'})
    ];
    const running = imageAnimations;
    Promise.allSettled(running.map(animation => animation.finished)).then(() => {
      if (running === imageAnimations) settleImages();
    });
  }
  document.body.classList.add('has-directory');
  trigger.setAttribute('aria-controls', 'site-directory'); trigger.setAttribute('aria-haspopup', 'dialog');
  trigger.addEventListener('click', () => {
    if (dialog.open) { dismiss(); return; }
    root.classList.add('directory-open'); dialog.showModal(); dialog.scrollTop = 0;
    trigger.setAttribute('aria-expanded', 'true'); root.classList.add('page-sleeping');
    sections.forEach(section => { section.open = false; });
    const current = pageLinks.find(link => new URL(link.href).pathname === location.pathname);
    preview(current?.dataset.directoryPreview || 'projects');
    document.dispatchEvent(new Event('site-menu-open')); close.focus({preventScroll: true});
  });
  close.addEventListener('click', dismiss);
  dialog.addEventListener('cancel', event => { event.preventDefault(); dismiss(); });
  dialog.addEventListener('close', () => {
    root.classList.remove('directory-open'); trigger.setAttribute('aria-expanded', 'false');
    root.classList.toggle('page-sleeping', document.hidden);
    document.dispatchEvent(new Event('site-menu-close'));
  });
  dialog.addEventListener('click', event => {
    const link = event.target.closest('a[href]');
    if (link && event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey && !link.target && !link.hasAttribute('download')) closeNow(false);
  });
  dialog.querySelectorAll('[data-directory-preview]').forEach(link => {
    link.addEventListener('pointerenter', event => { if (event.pointerType !== 'touch') preview(link.dataset.directoryPreview); });
    link.addEventListener('focus', () => preview(link.dataset.directoryPreview));
  });
  pageLinks.forEach(link => {
    if (new URL(link.href).pathname === location.pathname) link.setAttribute('aria-current', 'page');
  });
  sections.forEach(section => section.addEventListener('toggle', () => {
    if (!section.open) return;
    sections.forEach(other => { if (other !== section) other.open = false; });
    preview(section.querySelector('summary').dataset.directoryPreview);
  }));
  document.addEventListener('site-navigation-start', () => closeNow(false));
  window.addEventListener('pagehide', () => closeNow(false));
  window.addEventListener('pageshow', event => { if (event.persisted) closeNow(false); });
  preference.addEventListener('change', () => { settleImages(); if (closingTimer !== null) closeNow(true); });
})();
