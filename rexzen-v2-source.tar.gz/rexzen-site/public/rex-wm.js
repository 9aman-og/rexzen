/* One finite decorative cycle; the complete mechanism stays readable. */
(() => {
  'use strict';
  const scene = document.querySelector('[data-wm-example]');
  if (!scene) return;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const nodes = [...scene.querySelectorAll('[data-wm-node]')];
  const stages = [['history'],['predict'],['observe'],['update','select'],[]];
  let frame = null, consumed = false, visible = false, started = 0;
  let arrivalUncovered = false;
  const eligible = () => {
    const phase = document.documentElement.dataset.pageMotion;
    return visible && (!phase || (phase === 'arriving' && arrivalUncovered)) && !reduced.matches && !document.hidden && document.hasFocus() && !document.documentElement.classList.contains('directory-open');
  };
  const stop = () => {
    if (frame !== null) cancelAnimationFrame(frame);
    frame = null;
    nodes.forEach(node => node.dataset.active = 'false');
    scene.dataset.sequenceState = 'settled';
  };
  const tick = now => {
    frame = null;
    if (!eligible() || now - started >= 4400) { stop(); return; }
    const current = Math.min(4, Math.floor((now - started) / 880));
    nodes.forEach(node => node.dataset.active = String(stages[current].includes(node.dataset.wmNode)));
    frame = requestAnimationFrame(tick);
  };
  const begin = () => {
    if (consumed || !eligible() || navigator.connection?.saveData) return;
    consumed = true; started = performance.now(); scene.dataset.sequenceState = 'running';
    frame = requestAnimationFrame(tick);
  };
  if ('IntersectionObserver' in window) new IntersectionObserver(entries => {
    visible = entries[0].isIntersecting && entries[0].intersectionRatio >= .15;
    if (!visible) stop(); else begin();
  }, {threshold:.15}).observe(scene);
  window.addEventListener('blur', stop);
  window.addEventListener('focus', begin);
  window.addEventListener('resize', stop, {passive:true});
  window.addEventListener('pagehide', stop);
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); else begin(); });
  ['site-menu-open','site-navigation-start'].forEach(name => document.addEventListener(name, stop));
  document.addEventListener('site-menu-close', begin);
  document.addEventListener('site-page-uncover', () => { arrivalUncovered = true; begin(); });
  reduced.addEventListener('change', stop);
})();
