(() => {
  'use strict';
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  let arrivalUncovered = false;
  const phaseReady = () => {
    const phase = document.documentElement.dataset.pageMotion;
    return !phase || (phase === 'arriving' && arrivalUncovered);
  };
  document.querySelectorAll('[data-sequence]').forEach(scene => {
    const nodes = [...scene.querySelectorAll('[data-sequence-node]')];
    let visible = false, consumed = false, frame = null, started = 0;
    const stop = () => {
      if (frame !== null) cancelAnimationFrame(frame);
      frame = null;
      nodes.forEach(node => node.removeAttribute('data-active'));
      scene.dataset.sequenceState = 'settled';
    };
    const eligible = () => visible && phaseReady() && !preference.matches && !document.hidden && document.hasFocus() && !document.documentElement.classList.contains('directory-open');
    const tick = now => {
      frame = null;
      if (!eligible() || now - started >= 4400) { stop(); return; }
      const current = Math.min(nodes.length - 1, Math.floor((now - started) / (4400 / nodes.length)));
      nodes.forEach((node,i) => node.dataset.active = String(i === current));
      frame = requestAnimationFrame(tick);
    };
    const begin = () => {
      if (consumed || !eligible() || navigator.connection?.saveData) return;
      consumed = true; started = performance.now(); scene.dataset.sequenceState = 'running';
      frame = requestAnimationFrame(tick);
    };
    if ('IntersectionObserver' in window) new IntersectionObserver(entries => {
      visible = entries[0].isIntersecting && entries[0].intersectionRatio >= .2;
      if (!visible) stop(); else begin();
    }, {threshold:.2}).observe(scene);
    window.addEventListener('blur', stop);
    window.addEventListener('focus', begin);
    window.addEventListener('resize', stop, {passive:true});
    window.addEventListener('pagehide', stop);
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); else begin(); });
    ['site-menu-open','site-navigation-start'].forEach(name => document.addEventListener(name, stop));
    document.addEventListener('site-menu-close', begin);
    document.addEventListener('site-page-uncover', () => { arrivalUncovered = true; begin(); });
    preference.addEventListener('change', stop);
  });
  let activeFilmStop = null;
  document.querySelectorAll('[data-editorial-camera], [data-recorded-film], [data-editorial-film]').forEach(scene => {
    const film = scene.matches('[data-recorded-film], [data-editorial-film]') ? scene.querySelector('video') : null;
    const compact = film ? matchMedia('(max-width: 640px)') : null;
    const desktopPoster = film?.getAttribute('poster');
    let filmVariant = null;
    let visible = false, consumed = false, animation = null, revision = 0;
    const stop = () => {
      revision++;
      film?.pause();
      if (activeFilmStop === stop) activeFilmStop = null;
      animation?.cancel(); animation = null;
      scene.dataset.mediaState = 'settled';
    };
    const syncFilmPoster = () => {
      if (!film) return;
      const variant = compact.matches ? 'mobile' : 'desktop';
      if (variant === filmVariant) return;
      filmVariant = variant;
      film.poster = compact.matches && film.dataset.posterMobile ? film.dataset.posterMobile : desktopPoster;
      // Crossing the breakpoint after a turn shows the matching still without replaying.
      if (film.getAttribute('src')) { film.removeAttribute('src'); film.load(); }
    };
    syncFilmPoster();
    const eligible = () => visible && phaseReady() && !preference.matches && !document.hidden && document.hasFocus() && !document.documentElement.classList.contains('directory-open');
    const begin = async () => {
      if (consumed || !eligible() || navigator.connection?.saveData) return;
      consumed = true;
      scene.dataset.mediaState = 'playing';
      if (film) {
        if (activeFilmStop && activeFilmStop !== stop) activeFilmStop();
        activeFilmStop = stop;
        const turn = ++revision;
        film.src = compact.matches && film.dataset.srcMobile ? film.dataset.srcMobile : film.dataset.src;
        try { await film.play(); if (turn !== revision || !eligible()) stop(); } catch { stop(); }
      } else if (scene.animate) {
        animation = scene.animate([{transform:'scale(1.04)'},{transform:'scale(1)'}],{duration:4400,easing:'cubic-bezier(.2,.7,.25,1)'});
        const current = animation;
        current.finished.then(() => { if (animation === current) stop(); }).catch(() => {});
      }
    };
    if ('IntersectionObserver' in window) new IntersectionObserver(entries => {
      visible = entries[0].isIntersecting && entries[0].intersectionRatio >= .2;
      if (!visible) stop(); else begin();
    }, {threshold:.2}).observe(scene);
    film?.addEventListener('ended', stop);
    film?.addEventListener('error', stop);
    window.addEventListener('blur', stop);
    window.addEventListener('focus', begin);
    window.addEventListener('resize', () => { stop(); syncFilmPoster(); }, {passive:true});
    compact?.addEventListener('change', () => { stop(); syncFilmPoster(); });
    window.addEventListener('pagehide', stop);
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); else begin(); });
    ['site-menu-open','site-navigation-start'].forEach(name => document.addEventListener(name, stop));
    document.addEventListener('site-menu-close', begin);
    document.addEventListener('site-page-uncover', () => { arrivalUncovered = true; begin(); });
    preference.addEventListener('change', stop);
  });
  const projects = document.querySelector('.nav-group');
  if (projects) {
    document.addEventListener('click', event => { if (!projects.contains(event.target)) projects.open = false; });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && projects.open) { projects.open = false; projects.querySelector('summary').focus(); }
    });
    document.addEventListener('site-menu-open', () => projects.open = false);
  }
})();

(() => {
  const projects = document.querySelector('.nav-group');
  if (!projects) return;
  document.addEventListener('click', event => { if (!projects.contains(event.target)) projects.open = false; });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && projects.open) { projects.open = false; projects.querySelector('summary').focus(); }
  });
  document.addEventListener('site-menu-open', () => projects.open = false);
})();
