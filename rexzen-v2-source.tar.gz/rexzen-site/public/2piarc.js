const study = document.querySelector('[data-arc-study]');
const trigger = study?.querySelector('[data-arc-trace]');
const preference = matchMedia('(prefers-reduced-motion: reduce)');
if (study && trigger) {
  const stop = () => { study.classList.remove('is-tracing'); trigger.textContent = 'Trace the form'; };
  trigger.hidden = preference.matches;
  trigger.addEventListener('click', () => {
    if (study.classList.contains('is-tracing')) { stop(); return; }
    study.classList.add('is-tracing'); trigger.textContent = 'Pause trace';
  });
  study.querySelector('.arc-trace').addEventListener('animationend', () => { stop(); trigger.textContent = 'Replay trace'; });
  document.addEventListener('site-navigation-start', stop);
  document.addEventListener('site-menu-open', stop);
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });
  preference.addEventListener('change', () => { stop(); trigger.hidden = preference.matches; });
  if ('IntersectionObserver' in window) new IntersectionObserver(entries => { if (!entries[0].isIntersecting) stop(); }).observe(study);
}
