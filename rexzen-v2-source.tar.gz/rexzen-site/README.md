# Rexzen + Aero

Company pages and the private Aero workspace at https://rexzen.si.

## Layout

- `public/`: company pages, Aero interface, SVG identities and encrypted paper envelopes.
- `server/`: authenticated API, account-scoped encrypted D1 storage, reviewed context requests and task-plan transactions.
- `worker/`: the Cloudflare Worker router.
- `db/schema.ts` and `drizzle/`: database schema and immutable generated migrations.
- `scripts/build.mjs`: compiles browser modules and bundles the Worker.

## Build

Use Node.js 22 or later and pnpm. Install the pinned dependencies with `pnpm install --frozen-lockfile`, then run `pnpm build`.

Runtime configuration belongs in the hosting service, never in source:

- Secrets: `APP_ENCRYPTION_KEY` (base64 32-byte key), `OWNER_USER_ID`, `OWNER_OPENAI_API_KEY`.
- Configuration: `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `MODEL_LUNA`, `MODEL_SOL`.
- D1 binding: `DB`.

The founder key is selected only for the verified owner UUID. Other accounts use their own encrypted provider key. Workspace records, sessions, receipts, conversations and proposals are encrypted in storage; the server decrypts them to serve the account. This is not end-to-end encryption.

Google sign-in uses server PKCE and a host-only HttpOnly session cookie. Auth and API responses are never cached. Record changes require a revision match. AI requests require an explicit source selection and an expiring preview receipt; proposed plans require acceptance before task writes.

Private API requests carry the browser's expected verified account ID in `X-Aero-Account`. The server rejects account changes before processing a draft. Account changes and expired sign-in clear cached private state; account-switch notifications are also broadcast to other open Aero tabs.

Supporting browsers may expose two bounded WebMCP helpers: list explicitly AI-enabled source metadata and stage a visible request review. They do not send an AI request or accept a plan. Unsupported browsers retain the full ordinary interface.

## Paper library

The repository contains only AES-256-GCM encrypted PDF envelopes. The paper password is not stored in source. Original PDFs, account records, provider keys, local context and screenshots are excluded.

## Deployment

The existing Sites project ID is recorded in `.openai/hosting.json`. Preserve it. Package the build from the exact pushed source commit and deploy a saved version. Generate and inspect new schema-only migrations when the schema changes; do not rewrite applied migration history.

The Sonne Systems repository is separate and unchanged.
