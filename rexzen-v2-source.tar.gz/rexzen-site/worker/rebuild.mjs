/* The second edition is mounted independently; the original routes stay intact. */
const pages=new Map([
  ['/2/','/2/index.html'],['/2/projects','/2/projects.html'],['/2/focus','/2/focus.html'],
  ['/2/rex-wm','/2/rex-wm.html'],['/2/2piarc','/2/2piarc.html'],['/2/eos','/2/eos.html'],
  ['/2/research','/2/research.html'],['/2/about','/2/about.html'],
  ['/2/aman-agarwal','/2/aman-agarwal.html'],['/2/privacy','/2/privacy.html']
]);
const retired=['/2/library/','/2/research/rex-wm-sensor-noise/','/2/research/persistent-model-growth/'];
const redirect=(url,path)=>Response.redirect(new URL(path+url.search,url.origin).href,308);
function decodeRange(body,start=0,end=Infinity){
  const first=Math.floor(start/3)*4,last=Number.isFinite(end)?Math.ceil((end+1)/3)*4:body.length;
  const text=atob(body.slice(first,last));
  const bytes=Uint8Array.from(text,c=>c.charCodeAt(0));
  return bytes.subarray(start-Math.floor(first/4)*3,Number.isFinite(end)?end-start+1+(start-Math.floor(first/4)*3):undefined);
}
export async function handleRebuild(request,url,assets){
  const path=url.pathname;
  if(path==='/2'||path==='/2/index.html')return redirect(url,'/2/');
  if(path!=='/2/'&&path.endsWith('/'))return redirect(url,path.slice(0,-1));
  if(path.endsWith('.html')&&pages.has(path.slice(0,-5)))return redirect(url,path.slice(0,-5));
  const headers={'Cache-Control':'no-store','X-Robots-Tag':'noindex, nofollow'};
  if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405,headers:{...headers,Allow:'GET, HEAD'}});
  if(path==='/2/papers.js'||retired.some(prefix=>path===prefix.slice(0,-1)||path.startsWith(prefix)))return new Response(request.method==='HEAD'?null:'This research document has been withdrawn.',{status:410,headers:{...headers,'Content-Type':'text/plain; charset=utf-8'}});
  const key=pages.get(path)||path,asset=assets[key];
  if(!asset)return new Response(request.method==='HEAD'?null:'<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Page not found | Rexzen</title><link rel="stylesheet" href="/2/interface.css"><main class="wrap section"><h1>Page not found.</h1><p>This address does not have a page.</p><a href="/2/">Return to Rexzen</a></main></html>',{status:404,headers:{...headers,'Content-Type':'text/html; charset=utf-8'}});
  delete headers['X-Robots-Tag'];
  headers['Content-Type']=asset.type;
  headers['ETag']=`"${asset.hash}"`;
  headers['Cache-Control']=asset.type.startsWith('text/html')?'public, max-age=0, must-revalidate':url.searchParams.get('v')===asset.hash?'public, max-age=31536000, immutable':'public, max-age=300';
  if(asset.canonical){headers.Link=`<${asset.canonical}>; rel="canonical"`;headers['X-Robots-Tag']='noindex';}
  if(asset.noindex)headers['X-Robots-Tag']='noindex';
  if(request.headers.get('If-None-Match')?.split(',').some(value=>value.trim().replace(/^W\//,'')===headers.ETag))return new Response(null,{status:304,headers});
  const length=Math.floor(asset.body.length*3/4)-(asset.body.endsWith('==')?2:asset.body.endsWith('=')?1:0);
  if(asset.type==='video/mp4'){
    headers['Accept-Ranges']='bytes';headers['Content-Length']=String(length);
    if(request.method==='HEAD')return new Response(null,{headers});
    const range=request.headers.get('Range'),ifRange=request.headers.get('If-Range');
    const match=range&&/^bytes=(\d*)-(\d*)$/.exec(range);
    if(match&&(match[1]||match[2])&&(!ifRange||ifRange===headers.ETag)){
      let start=0,end=length-1;
      if(match[1]){start=Number(match[1]);if(match[2])end=Math.min(Number(match[2]),length-1);}
      else start=Math.max(0,length-Number(match[2]));
      if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=length||end<start)return new Response(null,{status:416,headers:{...headers,'Content-Range':`bytes */${length}`,'Content-Length':'0'}});
      const bytes=decodeRange(asset.body,start,end);
      return new Response(bytes,{status:206,headers:{...headers,'Content-Range':`bytes ${start}-${end}/${length}`,'Content-Length':String(bytes.length)}});
    }
  }
  return new Response(request.method==='HEAD'?null:decodeRange(asset.body),{headers});
}
