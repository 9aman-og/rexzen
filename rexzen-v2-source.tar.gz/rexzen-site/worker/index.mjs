import {handleApi} from '../server/index.mjs';
import {assets} from './assets.generated.mjs';
import {handleRebuild} from './rebuild.mjs';

const pages={'/projects':'/projects.html','/':'/index.html','/focus':'/focus.html','/frontiers':'/frontiers.html','/principles':'/principles.html','/research':'/research.html','/rex-wm':'/rex-wm.html','/2piarc':'/2piarc.html','/eos':'/eos.html','/about':'/about.html','/privacy':'/privacy.html','/favicon.ico':'/brand/rexzen-favicon.svg'};
const appPaths=new Set(['/aero','/aero/work','/aero/context','/aero/graph','/aero/ask','/aero/journal','/aero/personal','/aero/settings']);
const retiredResearchPrefixes=['/research/rex-wm-sensor-noise/','/research/persistent-model-growth/','/library/'];
const retiredResearchPaths=new Set(['/papers.js']);
const security={
  'X-Content-Type-Options':'nosniff',
  'Referrer-Policy':'strict-origin-when-cross-origin',
  'Permissions-Policy':'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; font-src 'self'; connect-src 'self'; frame-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'self' https://chatgpt.com https://*.chatgpt.com",
};
function secured(response){const headers=new Headers(response.headers);for(const [key,value] of Object.entries(security))headers.set(key,value);return new Response(response.body,{status:response.status,statusText:response.statusText,headers});}
function decoded(base64){const text=atob(base64);return Uint8Array.from(text,c=>c.charCodeAt(0));}
export default {async fetch(request,env){
  const url=new URL(request.url);
  // Start sign-in on one origin so host-only PKCE and session cookies agree.
  if(url.hostname==='www.rexzen.si'){url.hostname='rexzen.si';return secured(Response.redirect(url.href,308));}
  if(url.pathname==='/2'||url.pathname.startsWith('/2/'))return secured(await handleRebuild(request,url,assets));
  let path=url.pathname;
  if(path.length>1&&path.endsWith('/'))return secured(Response.redirect(new URL(path.slice(0,-1)+url.search,url.origin).href,308));
  const retired={'/frontiers':'/about','/principles':'/about','/frontiers.html':'/about','/principles.html':'/about'};
  if(retired[path])return secured(Response.redirect(new URL(retired[path]+url.search,url.origin).href,308));
  // Public document aliases resolve to one canonical URL.
  if(path.endsWith('.html')){
    const canonical=path==='/index.html'?'/':path.slice(0,-5);
    if(pages[canonical]||canonical==='/aero')return secured(Response.redirect(new URL(canonical+url.search,url.origin).href,308));
  }
  if(retiredResearchPaths.has(path)||retiredResearchPrefixes.some(prefix=>path.startsWith(prefix))){
    if(!['GET','HEAD'].includes(request.method))return secured(new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD','Cache-Control':'no-store'}}));
    return secured(new Response(request.method==='HEAD'?null:'This research document has been withdrawn.',{status:410,headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','X-Robots-Tag':'noindex, nofollow'}}));
  }
  const api=await handleApi(request,env);if(api)return secured(api);
  if(!['GET','HEAD'].includes(request.method))return secured(new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD'}}));
  const privatePage=appPaths.has(path);
  const key=privatePage?'/aero.html':pages[path] || path;
  const asset=assets[key];
  if(!asset)return secured(new Response('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Page not found | Rexzen</title><link rel="stylesheet" href="/site.css"><main class="page-shell page-hero"><h1>Page not found.</h1><p>This address does not have a page.</p><a href="/">Return to Rexzen</a></main></html>',{status:404,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Robots-Tag':'noindex'}}));
  const encryptedEnvelope=(key.startsWith('/library/')||key.startsWith('/paper-files/'))&&key.endsWith('.encrypted.json');
  const headers={'Content-Type':asset.type,'Cache-Control':privatePage?'private, no-store':asset.type.startsWith('text/html')?'public, max-age=0, must-revalidate':'public, max-age=300','ETag':`"${asset.hash}"`,...(privatePage||encryptedEnvelope?{'X-Robots-Tag':'noindex, nofollow'}:{})};
  if(asset.canonical){headers.Link=`<${asset.canonical}>; rel="canonical"`;headers['X-Robots-Tag']='noindex';}
  if(asset.noindex)headers['X-Robots-Tag']='noindex';
  if(asset.type==='application/zip') {
    headers['Content-Disposition']=`attachment; filename="${key.split('/').pop()}"`;
    headers['X-Robots-Tag']='noindex';
  }
  if(asset.type==='application/pdf') {
    headers['Content-Disposition']=`inline; filename="${key.split('/').pop()}"`;
    headers['Link']=`<https://rexzen.si${key}>; rel="canonical"`;
  }
  if(asset.type==='video/mp4'){
    const length=Math.floor(asset.body.length*3/4)-(asset.body.endsWith('==')?2:asset.body.endsWith('=')?1:0);
    headers['Accept-Ranges']='bytes'; headers['Content-Length']=String(length);
    if(request.method==='HEAD')return secured(new Response(null,{headers}));
    const range=request.headers.get('Range');
    const ifRange=request.headers.get('If-Range');
    const match=range&&/^bytes=(\d*)-(\d*)$/.exec(range);
    // This small film endpoint supports one byte range. Ignore unknown units
    // and multipart requests so the browser can fall back to the full response.
    if(match&&(match[1]||match[2])&&(!ifRange||ifRange===headers.ETag)){
      let start=0,end=length-1;
      if(match[1]){start=Number(match[1]);if(match[2])end=Math.min(Number(match[2]),length-1);}
      else start=Math.max(0,length-Number(match[2]));
      if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=length||end<start)
        return secured(new Response(null,{status:416,headers:{...headers,'Content-Range':`bytes */${length}`,'Content-Length':'0'}}));
      const bytes=decoded(asset.body).subarray(start,end+1);
      return secured(new Response(bytes,{status:206,headers:{...headers,'Content-Range':`bytes ${start}-${end}/${length}`,'Content-Length':String(bytes.length)}}));
    }
  }
  return secured(new Response(request.method==='HEAD'?null:decoded(asset.body),{headers}));
}};
