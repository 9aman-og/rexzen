# Media source notices

The 21 October 2026 media rebuild uses two licensed Pexels photos and two licensed Pexels films, prepared as muted web excerpts with desktop and portrait ripple versions. These are editorial illustrations. They do not depict Rexzen employees, facilities, customers, hardware or research outputs, and no endorsement is implied.

The notebook photo is by Thirdman (Pexels 5592496); the circuit photo is by Jeswin Thomas (5023565); the pendulum film is by Engin Akyurt (6613341); the ripple film is by Mixkit via Pexels (2675514). The exact source pages, current license link and local file identities are recorded in `media-provenance.json` and `MEDIA_PROVENANCE_PREVIOUS.txt` in the source archive. The Pexels license was checked on 21 October 2026. No Palantir media, marks, customer material or proprietary fonts are used.

The original seated 2πarc girl is recovered from existing Rexzen v30 frames and the seat-compositing renderer. Her pose remains anchored to the wordmark while the filmed scarf, hair and coat move. The interface provides pause controls, visibility handling and a still pose for reduced motion.

The Rex-WM recording and release remain the original bounded one-dimensional CPU prototype. The ambient pendulum and ripple films are distinct from that recording. The current Aero workflow is an explicitly fictional HTML illustration that ends at a pending plan.

## Motion extension, 22 October 2026

The motion system is authored for Rexzen from an audit of 15 public Palantir URLs. The coverage record distinguishes observed behavior from source-only components. Scroll distances, stagger intervals, mask shapes and page-wipe timing are adapted from those bounded observations; this is not a claim to reproduce every page on the reference domain. No reference-site JavaScript, media, fonts, SVG marks or product/customer graphics are shipped.

GSAP 3.15.0 core, ScrollTrigger and EasePack/RoughEase are self-hosted from the verified official package. GSAP is available under its standard no-charge commercial license; it is not represented as MIT or open source. The package notice, source URL, integrity and file hashes are retained in `public/vendor/gsap-NOTICE.txt` and `gsap-manifest.json`. Original vendor license headers remain in the served bundle.

The rotating gray page wipe uses Rexzen's existing wordmark. It preserves ordinary document navigation, modified clicks, downloads and same-page anchors. Arrival text follows the wipe. Global Pause motion and the system reduced-motion preference expose complete readable content; phone and reduced-motion layouts use normal document flow instead of pinned chapters. Directional connector effects use plain lines and the reference's chevron mask is replaced with a rectangular aperture to preserve the user's no-arrow requirement. A legacy flashing label is adapted to an underline; the source-only nested dropdown is not added to the already complete directory.

Seven unreferenced earlier presentation files remain in source/history but are omitted from the runtime payload: the two superseded Aero workflow films and posters, two obsolete contour SVGs and the unused v29 character JSON. Current media, v30 animation/fallback, useful page routes, release bytes and protected research assets remain available under their established contracts.

## Earlier version 23 notes retained for provenance

Version 23 uses an original abstract 2D contour study in the homepage hero and original functional diagrams authored from the public Rex-WM Micro 0.1.0 release and the declared Aero workflow. These are software diagrams and recorded data displays, not photographs or hardware demonstrations. Published file identities are recorded in media-provenance.json.

The contour field is conceptual artwork, with no claim to measured terrain or model output. Its entrance is finite; the graphic remains still afterward.

The historical motion diagram plots 51 original samples at target times 28 to 32 seconds from one historical seed-0 simulation. Observed velocity, deployed bank forecasts and frozen forecasts share a target-time axis. The stored-adapter selection occurs at 29.36 seconds; its first forecast target is 29.44 seconds. Straight segments connect the recorded points without smoothing or new inference. This excerpt does not establish a general performance advantage and is separate from present-source acceptance or the sensor-noise report.

Aero diagrams and films use fictional notes, requests and pending plans. Two selected notes feed the reviewed request; an unselected private note is excluded. The illustration ends before any plan is accepted or saved. It is not a recording of the live app or a runtime privacy-enforcement receipt.

The Rex loop diagram describes observed position, velocity and applied force feeding acceleration and next-motion prediction in the released one-dimensional software. Learning a residual correction and selecting an earlier stored adapter are separate operations. It does not depict hardware, new experiments or general real-world autonomy.

The Rex films preserve all 480 sealed forecasts in order from one public historical 1D simulation. They illustrate two series, not the full seven-method benchmark or the sensor-noise experiment. Aero and Rex films remain finite and silent, with wide and portrait versions, lasting 12 and 18 seconds respectively. Each plays once when visible, stops when offscreen, blurred or hidden, and uses a still for reduced motion. Resizing does not replay a consumed film.

The earlier atmospheric coastal footage and conceptual photographic studies are replaced in this version. Their source notices remain preserved in the version 22 source history.

## Original media and copy refinement, 23 October 2026

Three original editorial images were created with the built-in OpenAI image-generation tool: a graphite wave surface, layered paper with a cobalt-edged glass lens, and light through smoky glass planes. The surface and glass scenes were animated with the connected Wan 2.2 image-to-video tool. These are conceptual editorial artworks, separate from the actual recorded Rex simulation. Source prompts, tool identities, seeds, output hashes and web encodings are recorded in `MEDIA_PRODUCTION_20261023.json`. No generated film is presented as a research result.

Visible photo/video credit captions and the public media-credit page were removed at the user's request. The Pexels source/license records and GSAP notices remain preserved in the source archive. Original pixel icons use hand-authored SVG shapes and do not include Minecraft textures or other game assets. Extra key-statement reveals use bounded shuffled opacity, restore ordinary text after completion, and honor the existing reduced-motion setting.


## Real-media revision, 23 October 2026

The synthetic graphite, glass-lens and smoky-glass artwork is superseded by camera-shot material and a native Aero interface film. Current source URLs, creators, license terms, hashes, editorial scope and capture details are recorded in MEDIA_REAL_20261023.json. Pexels attribution is optional under its license; visible credits remain removed at the user's request. The footage and photographs do not depict Rexzen staff or facilities and are not experimental evidence. The Aero demonstration uses production interface components with fictional offline records and a predefined illustrated response. No private account content or provider request was used.
