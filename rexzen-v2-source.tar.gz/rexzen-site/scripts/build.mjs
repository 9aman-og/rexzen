import {readFile,writeFile,readdir,mkdir,rm,cp} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve,extname,relative} from 'node:path';
import {createHash} from 'node:crypto';
import {build,transform} from 'esbuild';
import {rebuildMetadata,rebuildRoutes} from './rebuild-metadata.mjs';
const root=fileURLToPath(new URL('..',import.meta.url));
const dist=resolve(root,'dist');
const reviewedPublicPdfs=new Map();
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.mp4':'video/mp4','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.xml':'application/xml; charset=utf-8','.zip':'application/zip','.pdf':'application/pdf','.md':'text/markdown; charset=utf-8','.tex':'text/plain; charset=utf-8','.csv':'text/csv; charset=utf-8','.gz':'application/gzip'};
const assets={};
const publicRoutes=new Map([['index.html','/'],['projects.html','/projects'],['focus.html','/focus'],['2piarc.html','/2piarc'],['eos.html','/eos'],['research.html','/research'],['rex-wm.html','/rex-wm'],['about.html','/about'],['privacy.html','/privacy']]);
const researchCatalog=JSON.parse(await readFile(resolve(root,'public/research-catalog.json'),'utf8'));
const publicText=[];
function decodeText(value){
  return value.replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi,(_,entity)=>{
    if(entity[0]==='#')return String.fromCodePoint(entity[1].toLowerCase()==='x'?parseInt(entity.slice(2),16):Number(entity.slice(1)));
    return {amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:' '}[entity.toLowerCase()];
  });
}
function plainText(html){return decodeText(html.replace(/<[^>]*>/g,'')).replace(/\s+/g,' ').trim();}
function pageText(html,route){
  const title=plainText(html.match(/<title>(.*?)<\/title>/s)?.[1]||'Rexzen');
  const description=decodeText(html.match(/<meta\s+name="description"\s+content="([^"]*)"/)?.[1]||'');
  let main=html.match(/<main\b[^>]*>([\s\S]*?)<\/main>/i)?.[1];
  if(!main)throw new Error(`Public page has no main content: ${route}`);
  main=main.replace(/<(script|style|svg|canvas|button|select)\b[^>]*>[\s\S]*?<\/\1>/gi,'');
  main=main.replace(/<a\b[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi,(_,href,label)=>{
    const text=plainText(label);
    if(!text)return '';
    const target=new URL(decodeText(href),'https://rexzen.si').href;
    return `[${text}](${target})`;
  });
  main=main.replace(/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi,(_,level,label)=>`\n\n${'#'.repeat(Number(level))} ${plainText(label)}\n\n`);
  main=main.replace(/<img\b[^>]*alt="([^"]*)"[^>]*>/gi,(_,alt)=>alt?`\n\nImage: ${decodeText(alt)}\n\n`:'');
  main=main.replace(/<br\s*\/?>/gi,'\n').replace(/<li\b[^>]*>/gi,'\n- ');
  main=main.replace(/<\/?(?:p|div|section|article|figure|figcaption|ul|ol|dl|dt|dd|blockquote|table|tr)\b[^>]*>/gi,'\n\n');
  main=decodeText(main.replace(/<[^>]*>/g,'')).replace(/[\t ]+/g,' ').replace(/ *\n */g,'\n').replace(/\n{3,}/g,'\n\n').trim();
  return `# ${title}\n\nSource: https://rexzen.si${route}\n\n${description}\n\n${main}\n`;
}
function metadata(html,file){
  const route=publicRoutes.get(relative(resolve(root,'public'),file));
  if(route===undefined)return html;
  const title=html.match(/<title>(.*?)<\/title>/s)?.[1]||'Rexzen';
  const description=html.match(/<meta\s+name="description"\s+content="([^"]*)"/)?.[1]||'';
  const url=`https://rexzen.si${route}`;
  const share={
    '/': ['home-recurrence-share-v23.jpg','Predicted and observed velocity in a recorded Rex simulation',1200,630],
    '/projects': ['aero-workflow-share-v23.jpg','Fictional Aero workflow ending with a pending plan',1200,630],
    '/focus': ['aero-workflow-share-v23.jpg','Fictional Aero workflow ending with a pending plan',1200,630],
    '/research': ['rex-learning-loop-share-v23.jpg','The released Rex software prediction and correction loop',1200,630],
    '/2piarc': ['home-recurrence-share-v23.jpg','Predicted and observed velocity in a recorded Rex simulation',1200,630],
    '/eos': ['eos-share.png','EOS research program at 2πarc: evidence before lasting change',1200,630],
    '/rex-wm': ['rex-learning-loop-share-v23.jpg','The released Rex software prediction and correction loop',1200,630],
    '/about': ['home-recurrence-share-v23.jpg','Predicted and observed velocity in a recorded Rex simulation',1200,630],
    '/privacy': ['aero-workflow-share-v23.jpg','Fictional Aero selected-note workflow',1200,630]
  }[route]||['home-recurrence-share-v23.jpg','Predicted and observed velocity in a recorded Rex simulation',1200,630];
  const image=`https://rexzen.si/images/${share[0]}`;
  const pageId=`${url}#page`;
  const graph=[
    {'@type':'Organization','@id':'https://rexzen.si/#organization',name:'Rexzen',url:'https://rexzen.si/',logo:{'@type':'ImageObject',url:'https://rexzen.si/brand/rexzen-logo-512.png',width:512,height:512},sameAs:['https://www.linkedin.com/company/rexzen/','https://www.instagram.com/rexzen.si/'],description:'AI software and world model research.',founder:{'@type':'Person',name:'Aman Agarwal'},department:{'@id':'https://rexzen.si/2piarc#organization'}},
    {'@type':'Organization','@id':'https://rexzen.si/2piarc#organization',name:'2πarc',url:'https://rexzen.si/2piarc',description:'Rexzen research division studying prediction and adaptation.',parentOrganization:{'@id':'https://rexzen.si/#organization'}},
    {'@type':'WebSite','@id':'https://rexzen.si/#website',name:'Rexzen',url:'https://rexzen.si/',inLanguage:'en',publisher:{'@id':'https://rexzen.si/#organization'}},
    {'@type':'WebPage','@id':pageId,name:title,description,url,inLanguage:'en',isAccessibleForFree:true,isPartOf:{'@id':'https://rexzen.si/#website'},about:{'@id':['/2piarc','/eos','/research'].includes(route)?'https://rexzen.si/2piarc#organization':'https://rexzen.si/#organization'},primaryImageOfPage:{'@type':'ImageObject',url:image,width:share[2],height:share[3]}}
  ];
  if(route!=='/'){
    const parent=['/research','/eos'].includes(route)?{name:'2πarc',url:'https://rexzen.si/2piarc'}:['/focus','/rex-wm'].includes(route)?{name:'Projects',url:'https://rexzen.si/projects'}:null;
    const crumbs=[{'@type':'ListItem',position:1,name:'Rexzen',item:'https://rexzen.si/'}];
    if(parent)crumbs.push({'@type':'ListItem',position:2,name:parent.name,item:parent.url});
    crumbs.push({'@type':'ListItem',position:crumbs.length+1,name:title.split(' | ')[0],item:url});
    graph.push({'@type':'BreadcrumbList','@id':`${url}#breadcrumb`,itemListElement:crumbs});
  }
  if(route==='/eos'){
    graph[3].about={'@id':`${url}#program`};
    graph.push({'@type':'ResearchProject','@id':`${url}#program`,name:'EOS',url,description:'A research program on causal world models, memory and evidence for persistent change. The proposed architecture remains a research hypothesis.',parentOrganization:{'@id':'https://rexzen.si/2piarc#organization'},member:{'@type':'Person',name:'Aman Agarwal'},subjectOf:researchCatalog.papers.filter(paper=>paper.id.startsWith('eos-')||paper.id==='pomdp').map(paper=>({'@id':paper.url}))});
  }
  if(route==='/research'){
    const paperIds=researchCatalog.papers.map(paper=>({'@id':paper.url}));
    graph[3]['@type']='CollectionPage';
    graph[3].hasPart=paperIds;
    graph[3].mainEntity={'@id':`${url}#paper-list`};
    graph.push({'@type':'ItemList','@id':`${url}#paper-list`,name:'Selected research manuscripts',itemListOrder:'https://schema.org/ItemListOrderAscending',itemListElement:paperIds.map((item,index)=>({'@type':'ListItem',position:index+1,item}))});
    for(const paper of researchCatalog.papers)graph.push({
      '@type':'ScholarlyArticle','@id':paper.url,url:paper.url,name:paper.title,headline:paper.title,
      description:`${paper.summary} ${paper.scope}`,inLanguage:'en',creativeWorkStatus:paper.status,version:paper.version,
      pagination:`${paper.pages} pages`,author:{'@type':'Person',name:paper.author,affiliation:{'@type':'Organization',name:paper.affiliation}},
      isPartOf:{'@id':pageId},about:{'@type':'Thing',name:paper.topic}
    });
  }
  const json=JSON.stringify({'@context':'https://schema.org','@graph':graph}).replace(/</g,'\\u003c');
  const textUrl=`https://rexzen.si${route==='/'?'/index':route}.md`;
  const tags=`<meta name="robots" content="index, follow, max-image-preview:large"><link rel="alternate" type="text/markdown" href="${textUrl}" title="Plain text version"><link rel="sitemap" type="application/xml" href="https://rexzen.si/sitemap.xml"><link rel="describedby" type="text/plain" href="https://rexzen.si/llms.txt"><meta property="og:type" content="website"><meta property="og:site_name" content="Rexzen"><meta property="og:title" content="${title}"><meta property="og:description" content="${description}"><meta property="og:url" content="${url}"><meta property="og:image" content="${image}"><meta property="og:image:width" content="${share[2]}"><meta property="og:image:height" content="${share[3]}"><meta property="og:image:alt" content="${share[1]}"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${title}"><meta name="twitter:description" content="${description}"><meta name="twitter:image" content="${image}"><meta name="twitter:image:alt" content="${share[1]}"><script type="application/ld+json">${json}</script>`;
  return html.replace('</head>',`${tags}</head>`);
}
async function collect(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const file=resolve(dir,entry.name);if(entry.isDirectory())await collect(file);else if(entry.isFile()){const ext=extname(file);if(!types[ext])throw new Error(`Unsupported public asset: ${entry.name}`);if(ext==='.pdf'&&reviewedPublicPdfs.get(relative(resolve(root,'public'),file))!==createHash('sha256').update(await readFile(file)).digest('hex'))throw new Error('Only exact reviewed research PDFs may be public assets.');let bytes=await readFile(file);if(ext==='.js')bytes=Buffer.from((await transform(bytes.toString(),{sourcefile:file,loader:'js',target:'es2022',minify:file.includes('/public/2/vendor/'),legalComments:file.includes('/public/2/vendor/')?'inline':'none'})).code);if(ext==='.html'){let html=bytes.toString();html=html.replace(/(<link rel="canonical" href=")\/(.*?)"/g,'$1https://rexzen.si/$2"');html=file.startsWith(resolve(root,'public/2')+'/')?rebuildMetadata(html,rebuildRoutes.get(relative(resolve(root,'public/2'),file)),researchCatalog):metadata(html,file);bytes=Buffer.from(html);}assets['/'+relative(resolve(root,'public'),file)]={type:types[ext],body:bytes.toString('base64'),hash:createHash('sha256').update(bytes).digest('hex').slice(0,24)};}}}
await collect(resolve(root,'public'));
assets['/research-catalog.json'].canonical='https://rexzen.si/research';
// Text versions come from the same public HTML so copy and research limits agree.
for(const [file,route] of publicRoutes){
  const html=Buffer.from(assets[`/${file}`].body,'base64').toString();
  const body=pageText(html,route);
  publicText.push(body);
  assets[route==='/'?'/index.md':`${route}.md`]={type:types['.md'],body:Buffer.from(body).toString('base64'),hash:createHash('sha256').update(body).digest('hex').slice(0,24),canonical:`https://rexzen.si${route}`};
}
const fullText=`# Rexzen public pages\n\nThese pages are public. Private workspace content is not included.\n\n${publicText.join('\n\n---\n\n')}`;
assets['/llms-full.txt']={type:types['.txt'],body:Buffer.from(fullText).toString('base64'),hash:createHash('sha256').update(fullText).digest('hex').slice(0,24),noindex:true};
// The second edition has its own canonical URLs, sitemap and text index.
const rebuiltText=[];
for(const [file,route] of rebuildRoutes){
  const asset=assets[`/2/${file}`];
  if(!asset)throw new Error(`Missing second-edition page: ${file}`);
  const html=Buffer.from(asset.body,'base64').toString();
  const body=pageText(html.replace(/<br\s*\/?>/gi,' '),'/2'+route);
  rebuiltText.push(body);
  const bytes=Buffer.from(body);
  assets[route==='/'?'/2/index.md':`/2${route}.md`]={type:types['.md'],body:bytes.toString('base64'),hash:createHash('sha256').update(bytes).digest('hex').slice(0,24),canonical:`https://rexzen.si/2${route}`};
}
const rebuiltFull=Buffer.from(`# Rexzen second-edition public pages\n\nPrivate workspace content is not included.\n\n${rebuiltText.join('\n\n---\n\n')}`);
assets['/2/llms-full.txt']={type:types['.txt'],body:rebuiltFull.toString('base64'),hash:createHash('sha256').update(rebuiltFull).digest('hex').slice(0,24),noindex:true};
// A fresh HTML response must load the matching client code after deployment,
// even when the browser still has an older script within its cache lifetime.
for(const asset of Object.values(assets)){
  if(!asset.type.startsWith('text/html'))continue;
  const html=Buffer.from(asset.body,'base64').toString().replace(/((?:src|href|data-paper-file)=")([^"?]+\.(?:js|css|svg|jpg|jpeg|png|webp|mp4|json))"/g,(match,prefix,path)=>assets[path]?`${prefix}${path}?v=${assets[path].hash}"`:match);
  const bytes=Buffer.from(html);asset.body=bytes.toString('base64');asset.hash=createHash('sha256').update(bytes).digest('hex').slice(0,24);
}
await mkdir(resolve(root,'worker'),{recursive:true});
await writeFile(resolve(root,'worker/assets.generated.mjs'),`export const assets=${JSON.stringify(assets)};\n`);
await rm(dist,{recursive:true,force:true});await mkdir(resolve(dist,'server'),{recursive:true});await mkdir(resolve(dist,'.openai'),{recursive:true});
await build({entryPoints:[resolve(root,'worker/index.mjs')],outfile:resolve(dist,'server/index.js'),bundle:true,format:'esm',platform:'browser',target:'es2022',minify:false,legalComments:'none'});
await cp(resolve(root,'.openai/hosting.json'),resolve(dist,'.openai/hosting.json'));
await cp(resolve(root,'drizzle'),resolve(dist,'.openai/drizzle'),{recursive:true});
console.log(`Built Rexzen + Aero: ${Object.keys(assets).length} public assets; Worker and D1 migrations packaged.`);
