export const rebuildRoutes=new Map([['index.html','/'],['projects.html','/projects'],['focus.html','/focus'],['2piarc.html','/2piarc'],['eos.html','/eos'],['research.html','/research'],['rex-wm.html','/rex-wm'],['about.html','/about'],['aman-agarwal.html','/aman-agarwal'],['privacy.html','/privacy']]);
export function rebuildMetadata(html,route,researchCatalog){
  if(route===undefined)return html;
  const title=html.match(/<title>(.*?)<\/title>/s)?.[1]||'Rexzen';
  const description=html.match(/<meta\s+name="description"\s+content="([^"]*)"/)?.[1]||'';
  const url=`https://rexzen.si/2${route}`;
  const share={
    '/': ['water-motion-poster.jpg','An editorial study of expanding water ripples',1600,900],
    '/projects': ['editorial-notes.jpg','Hands writing in a notebook, an editorial illustration of personal context',1125,750],
    '/focus': ['editorial-notes.jpg','Hands writing in a notebook, an editorial illustration of personal context',1125,750],
    '/research': ['character-study-v29.webp','The original seated 2πarc character study',1254,1254],
    '/2piarc': ['character-study-v29.webp','The original seated 2πarc character study',1254,1254],
    '/eos': ['water-motion-poster.jpg','An editorial study of expanding water ripples',1600,900],
    '/rex-wm': ['rex-recorded-v22-poster.jpg','A recorded one-dimensional Rex-WM Micro simulation',1600,900],
    '/about': ['editorial-circuit.jpg','Hands working on an electronic circuit, an editorial illustration',1125,750],
    '/aman-agarwal': ['../brand/rexzen-logo-512.png','Rexzen, founded by Aman Agarwal',512,512],
    '/privacy': ['editorial-notes.jpg','Hands writing in a notebook, an editorial illustration of personal context',1125,750]
  }[route]||['water-motion-poster.jpg','An editorial study of expanding water ripples',1600,900];
  const image=new URL(share[0],['/','/eos','/about','/focus','/projects','/privacy'].includes(route)?'https://rexzen.si/2/images/':'https://rexzen.si/images/').href;
  const pageId=`${url}#page`;
  const graph=[
    {'@type':'Organization','@id':'https://rexzen.si/#organization',name:'Rexzen',url:'https://rexzen.si/',logo:{'@type':'ImageObject',url:'https://rexzen.si/brand/rexzen-logo-512.png',width:512,height:512},sameAs:['https://www.linkedin.com/company/rexzen/','https://www.instagram.com/rexzen.si/'],description:'AI software and world model research.',founder:{'@id':'https://rexzen.si/2/aman-agarwal#person'},department:{'@id':'https://rexzen.si/2/2piarc#organization'}},
    {'@type':'Organization','@id':'https://rexzen.si/2/2piarc#organization',name:'2πarc',url:'https://rexzen.si/2/2piarc',description:'Rexzen research division studying prediction and adaptation.',parentOrganization:{'@id':'https://rexzen.si/#organization'}},
    {'@type':'WebSite','@id':'https://rexzen.si/2/#website',name:'Rexzen',url:'https://rexzen.si/2/',inLanguage:'en',publisher:{'@id':'https://rexzen.si/#organization'}},
    {'@type':'WebPage','@id':pageId,name:title,description,url,inLanguage:'en',isAccessibleForFree:true,isPartOf:{'@id':'https://rexzen.si/2/#website'},about:{'@id':['/2piarc','/eos','/research'].includes(route)?'https://rexzen.si/2/2piarc#organization':'https://rexzen.si/#organization'},primaryImageOfPage:{'@type':'ImageObject',url:image,width:share[2],height:share[3]}}
  ];
  const person={'@type':'Person','@id':'https://rexzen.si/2/aman-agarwal#person',name:'Aman Agarwal',alternateName:'9aman-og',url:'https://rexzen.si/2/aman-agarwal',description:'Founder of Rexzen. Independent machine-learning researcher and software builder.',jobTitle:'Founder',worksFor:{'@id':'https://rexzen.si/#organization'},mainEntityOfPage:{'@id':'https://rexzen.si/2/aman-agarwal#page'},sameAs:['https://github.com/9aman-og']};
  graph.push(person);
  if(route==='/aman-agarwal'){
    graph[3]['@type']='ProfilePage';
    graph[3].mainEntity=person;
    graph.pop();
    graph[3].about={'@id':'https://rexzen.si/2/aman-agarwal#person'};
    delete graph[3].primaryImageOfPage;
  }
  if(route!=='/'){
    const parent=['/research','/eos'].includes(route)?{name:'2πarc',url:'https://rexzen.si/2/2piarc'}:['/focus','/rex-wm'].includes(route)?{name:'Projects',url:'https://rexzen.si/2/projects'}:route==='/aman-agarwal'?{name:'About',url:'https://rexzen.si/2/about'}:null;
    const crumbs=[{'@type':'ListItem',position:1,name:'Rexzen',item:'https://rexzen.si/2/'}];
    if(parent)crumbs.push({'@type':'ListItem',position:2,name:parent.name,item:parent.url});
    crumbs.push({'@type':'ListItem',position:crumbs.length+1,name:title.split(' | ')[0],item:url});
    graph.push({'@type':'BreadcrumbList','@id':`${url}#breadcrumb`,itemListElement:crumbs});
  }
  if(route==='/eos'){
    graph[3].about={'@id':`${url}#program`};
    graph.push({'@type':'ResearchProject','@id':`${url}#program`,name:'EOS',url,description:'A research program on causal world models, memory and evidence for persistent change. The proposed architecture remains a research hypothesis.',parentOrganization:{'@id':'https://rexzen.si/2/2piarc#organization'},member:{'@type':'Person',name:'Aman Agarwal'},subjectOf:researchCatalog.papers.filter(paper=>paper.id.startsWith('eos-')||paper.id==='pomdp').map(paper=>({'@id':paper.url}))});
  }
  if(route==='/research'){
    const paperIds=researchCatalog.papers.map(paper=>({'@id':paper.url}));
    graph[3]['@type']='CollectionPage';
    graph[3].hasPart=paperIds;
    graph[3].mainEntity={'@id':`${url}#paper-list`};
    graph.push({'@type':'ItemList','@id':`${url}#paper-list`,name:'Selected research manuscripts',itemListOrder:'https://schema.org/ItemListOrderAscending',itemListElement:paperIds.map((item,index)=>({'@type':'ListItem',position:index+1,item}))});
    for(const paper of researchCatalog.papers)graph.push({
      '@type':'ScholarlyArticle','@id':paper.url,url:paper.url,name:paper.title,headline:paper.title,
      description:`${paper.summary} ${paper.scope}`,inLanguage:'en',creativeWorkStatus:paper.status,version:paper.version,
      pagination:`${paper.pages} pages`,author:{'@type':'Person',name:paper.author,affiliation:{'@type':'Organization',name:paper.affiliation}},
      isPartOf:{'@id':pageId},about:{'@type':'Thing',name:paper.topic}
    });
  }
  const json=JSON.stringify({'@context':'https://schema.org','@graph':graph}).replace(/</g,'\\u003c');
  const textUrl=`https://rexzen.si/2${route==='/'?'/index':route}.md`;
  const tags=`<meta name="robots" content="index, follow, max-image-preview:large"><link rel="alternate" type="text/markdown" href="${textUrl}" title="Plain text version"><link rel="sitemap" type="application/xml" href="https://rexzen.si/2/sitemap.xml"><link rel="describedby" type="text/plain" href="https://rexzen.si/2/llms.txt"><meta property="og:type" content="website"><meta property="og:site_name" content="Rexzen"><meta property="og:title" content="${title}"><meta property="og:description" content="${description}"><meta property="og:url" content="${url}"><meta property="og:image" content="${image}"><meta property="og:image:width" content="${share[2]}"><meta property="og:image:height" content="${share[3]}"><meta property="og:image:alt" content="${share[1]}"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${title}"><meta name="twitter:description" content="${description}"><meta name="twitter:image" content="${image}"><meta name="twitter:image:alt" content="${share[1]}"><script type="application/ld+json">${json}</script>`;
  return html.replace('</head>',`${tags}</head>`);
}
