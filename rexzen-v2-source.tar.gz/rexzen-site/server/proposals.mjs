import { EDGE_LIMIT, RECORD_LIMIT, all, batch, decrypt, encrypt, fail, first, iso, json, publicEdge, relationPredicate, uuid } from "./core.mjs";
import { validateAnswer, validateSources } from "./context.mjs";
import { getRecord, normalizeRecord } from "./workspace.mjs";

function pendingGuard() {
  return `EXISTS (SELECT 1 FROM proposals p WHERE p.user_id = ? AND p.id = ? AND p.status = 'pending'
    AND NOT EXISTS (SELECT 1 FROM json_each(p.source_snapshot) s
      LEFT JOIN records r ON r.user_id = p.user_id AND r.id = json_extract(s.value, '$.id')
      WHERE r.id IS NULL OR r.revision <> json_extract(s.value, '$.revision') OR r.archived <> 0))`;
}

function insertedTasksGuard() {
  return `NOT EXISTS (SELECT 1 FROM json_each(?) t LEFT JOIN records r
    ON r.user_id = ? AND r.id = json_extract(t.value, '$.id')
    WHERE r.id IS NULL OR r.revision <> 1 OR r.cipher <> json_extract(t.value, '$.cipher'))`;
}

async function appliedResult(ctx, id, proposal, alreadyApplied) {
  const records = [];
  for (const step of proposal.steps) records.push(await getRecord(ctx, ctx.user.id, step.taskId));
  const taskIds = proposal.steps.map((step) => step.taskId);
  const placeholders = taskIds.map(() => "?").join(",");
  const edges = (await all(ctx, `SELECT * FROM edges WHERE user_id = ? AND (from_id IN (${placeholders}) OR to_id IN (${placeholders})) ORDER BY created_at, id`,
    [ctx.user.id, ...taskIds, ...taskIds])).map(publicEdge);
  return json({ proposalId: id, applied: true, alreadyApplied, records, edges });
}

export async function applyProposal(ctx, rawId) {
  const id = uuid(rawId, "Proposal ID");
  const userId = ctx.user.id;
  const row = await first(ctx, "SELECT * FROM proposals WHERE user_id = ? AND id = ?", [userId, id]);
  if (!row) fail(404, "proposal_not_found", "This plan proposal was not found in your workspace.");
  const proposal = await decrypt(ctx, "proposal", userId, id, row.cipher);
  if (proposal.id !== id || JSON.stringify(proposal.sources) !== row.source_snapshot || !Array.isArray(proposal.steps)) {
    fail(503, "private_data_unavailable", "Stored plan data could not be verified.");
  }
  const normalized = validateAnswer({ text: "Reviewed plan", citations: [], steps: proposal.steps }, "plan", proposal.sources);
  const taskIds = proposal.steps.map((step) => uuid(step.taskId, "Plan task ID"));
  if (new Set(taskIds).size !== taskIds.length) fail(503, "private_data_unavailable", "Stored plan task IDs could not be verified.");
  if (row.status === "applied") return appliedResult(ctx, id, proposal, true);
  await validateSources(ctx, proposal.sources);
  const now = Date.now();
  const byStep = new Map(normalized.steps.map((step, index) => [step.id, taskIds[index]]));
  const records = [];
  const insertRecords = [];
  for (let index = 0; index < normalized.steps.length; index++) {
    const step = normalized.steps[index];
    const record = normalizeRecord({ id: taskIds[index], type: "task", title: step.title,
      body: `${step.body}\n\nDone when: ${step.doneWhen}`, tags: ["ai-plan"], cloudAllowed: false }, null, now);
    const cipher = await encrypt(ctx, "record", userId, `${record.id}:1`, record);
    records.push(record);
    insertRecords.push({ id: record.id, type: record.type, cipher, createdAt: now, updatedAt: now });
  }
  const insertEdges = [];
  for (const step of normalized.steps) {
    const fromId = byStep.get(step.id);
    for (const dependency of step.dependsOn) {
      insertEdges.push({ id: crypto.randomUUID(), fromId, toId: byStep.get(dependency), relation: "depends_on", createdAt: now });
    }
    for (const source of proposal.sources) {
      insertEdges.push({ id: crypto.randomUUID(), fromId: source.id, toId: fromId, relation: "supports", createdAt: now });
    }
  }
  const tasksJson = JSON.stringify(insertRecords);
  const edgesJson = JSON.stringify(insertEdges);
  const links = relationPredicate(userId, proposal.relations || []);
  const relationCheck = await first(ctx, `SELECT 1 AS valid WHERE ${links.sql}`, links.params);
  if (!relationCheck) fail(409, "context_stale", "A source relationship changed. Prepare a fresh proposal before accepting it.");
  const pending = `${pendingGuard()} AND (${links.sql})`;
  const ready = insertedTasksGuard();
  // Capacity is checked only before inserts. Subsequent statements require the
  // exact ciphertext created by this attempt, so a denied/racing insert cannot
  // write revisions/edges or mark the proposal applied.
  const entries = [
    [`INSERT INTO records (user_id, id, type, revision, archived, cipher, created_at, updated_at)
      SELECT ?, json_extract(t.value, '$.id'), json_extract(t.value, '$.type'), 1, 0,
        json_extract(t.value, '$.cipher'), json_extract(t.value, '$.createdAt'), json_extract(t.value, '$.updatedAt')
      FROM json_each(?) t WHERE ${pending}
        AND (SELECT COUNT(*) FROM records WHERE user_id = ?) + ? <= ?
        AND (SELECT COUNT(*) FROM edges WHERE user_id = ?) + ? <= ?`,
    [userId, tasksJson, userId, id, ...links.params, userId, records.length, RECORD_LIMIT, userId, insertEdges.length, EDGE_LIMIT]],
    [`INSERT INTO record_revisions (user_id, record_id, revision, cipher, created_at)
      SELECT ?, json_extract(t.value, '$.id'), 1, json_extract(t.value, '$.cipher'), ?
      FROM json_each(?) t WHERE ${pending} AND ${ready}`,
    [userId, now, tasksJson, userId, id, ...links.params, tasksJson, userId]],
    [`INSERT INTO edges (user_id, id, from_id, to_id, relation, created_at)
      SELECT ?, json_extract(e.value, '$.id'), json_extract(e.value, '$.fromId'), json_extract(e.value, '$.toId'),
        json_extract(e.value, '$.relation'), json_extract(e.value, '$.createdAt')
      FROM json_each(?) e WHERE ${pending} AND ${ready}`,
    [userId, edgesJson, userId, id, ...links.params, tasksJson, userId]],
    [`UPDATE proposals SET status = 'applied', applied_at = ?
      WHERE user_id = ? AND id = ? AND status = 'pending' AND ${pending} AND ${ready}`,
    [now, userId, id, userId, id, ...links.params, tasksJson, userId]],
  ];
  const results = await batch(ctx, entries);
  if (!results.at(-1).meta?.changes) {
    const current = await first(ctx, "SELECT status FROM proposals WHERE user_id = ? AND id = ?", [userId, id]);
    if (current?.status === "applied") return appliedResult(ctx, id, proposal, true);
    await validateSources(ctx, proposal.sources);
    const recordCount = await first(ctx, "SELECT COUNT(*) AS count FROM records WHERE user_id = ?", [userId]);
    const edgeCount = await first(ctx, "SELECT COUNT(*) AS count FROM edges WHERE user_id = ?", [userId]);
    if (recordCount.count + records.length > RECORD_LIMIT || edgeCount.count + insertEdges.length > EDGE_LIMIT) {
      fail(409, "workspace_limit", "This plan would exceed the workspace record or link limit.");
    }
    fail(409, "proposal_conflict", "This plan or its source records changed. Refresh before applying it.");
  }
  return json({ proposalId: id, applied: true, alreadyApplied: false, records,
    edges: insertEdges.map((edge) => ({ ...edge, createdAt: iso(edge.createdAt) })) }, 201);
}
