import { checkOrigin, createContext, encryptionKey, errorResponse, fail, finish, rateLimit } from "./core.mjs";
import { googleCallback, logout, requireUser, sessionResponse, startGoogle } from "./auth.mjs";
import { archiveRecord, createEdge, createRecord, deleteEdge, exportWorkspace, updateKey, updateRecord, updateSettings, workspace } from "./workspace.mjs";
import { prepareContext, sendContext } from "./context.mjs";
import { applyProposal } from "./proposals.mjs";

const AUTH_PATHS = new Set(["/auth/google", "/auth/callback", "/auth/logout"]);

function method(request, expected) {
  if (request.method !== expected) fail(405, "method_not_allowed", `Use ${expected} for this endpoint.`);
}

async function route(ctx, path) {
  const request = ctx.request;
  if (path === "/auth/google") { method(request, "GET"); return startGoogle(ctx); }
  if (path === "/auth/callback") { method(request, "GET"); return googleCallback(ctx); }
  if (path === "/auth/logout" || path === "/api/logout") {
    method(request, "POST");
    // Logout works even when refresh credentials have expired.
    return logout(ctx);
  }
  if (path === "/api/session") { method(request, "GET"); return sessionResponse(ctx); }
  await requireUser(ctx);
  const mutation = !["GET", "HEAD"].includes(request.method);
  await rateLimit(ctx, ctx.user.id, mutation ? "write" : "read", mutation ? 30 : 120);
  if (path === "/api/workspace") { method(request, "GET"); return workspace(ctx); }
  if (path === "/api/export") {
    method(request, "GET");
    await rateLimit(ctx, ctx.user.id, "export", 2);
    return exportWorkspace(ctx);
  }
  if (path === "/api/records") { method(request, "POST"); return createRecord(ctx); }
  let match = path.match(/^\/api\/records\/([^/]+)\/restore$/);
  if (match) { method(request, "POST"); return archiveRecord(ctx, match[1], true); }
  match = path.match(/^\/api\/records\/([^/]+)$/);
  if (match) {
    if (request.method === "PATCH") return updateRecord(ctx, match[1]);
    if (request.method === "DELETE") return archiveRecord(ctx, match[1]);
    fail(405, "method_not_allowed", "Use PATCH or DELETE for this endpoint.");
  }
  if (path === "/api/edges") { method(request, "POST"); return createEdge(ctx); }
  match = path.match(/^\/api\/edges\/([^/]+)$/);
  if (match) { method(request, "DELETE"); return deleteEdge(ctx, match[1]); }
  if (path === "/api/settings") { method(request, "POST"); return updateSettings(ctx); }
  if (path === "/api/settings/key") {
    if (request.method === "POST") return updateKey(ctx);
    if (request.method === "DELETE") return updateKey(ctx, true);
    fail(405, "method_not_allowed", "Use POST or DELETE for this endpoint.");
  }
  if (path === "/api/context/prepare") {
    method(request, "POST");
    await rateLimit(ctx, ctx.user.id, "prepare", 10);
    return prepareContext(ctx);
  }
  if (path === "/api/context/send") {
    method(request, "POST");
    await rateLimit(ctx, ctx.user.id, "send-minute", 4);
    await rateLimit(ctx, ctx.user.id, "send-hour", 20, 60 * 60 * 1000);
    return sendContext(ctx);
  }
  match = path.match(/^\/api\/proposals\/([^/]+)\/apply$/);
  if (match) {
    method(request, "POST");
    await rateLimit(ctx, ctx.user.id, "apply", 4);
    return applyProposal(ctx, match[1]);
  }
  fail(404, "endpoint_not_found", "This API endpoint was not found.");
}

/** Route private API/auth requests. Return null so Ark can serve static pages. */
export async function handleApi(request, env) {
  const path = new URL(request.url).pathname;
  if (!path.startsWith("/api/") && !AUTH_PATHS.has(path)) return null;
  let ctx;
  try {
    ctx = createContext(request, env);
    if (!["GET", "HEAD"].includes(request.method)) checkOrigin(ctx);
    await encryptionKey(ctx);
    return finish(ctx, await route(ctx, path));
  } catch (error) {
    const response = errorResponse(error);
    return ctx ? finish(ctx, response) : response;
  }
}

export default { fetch: async (request, env) => (await handleApi(request, env)) || new Response("Not found", { status: 404 }) };
