// Shared Cloudflare Worker primitives. No secret values are logged or returned.
export const RECORD_LIMIT = 1000;
export const EDGE_LIMIT = 3000;
export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const encoder = new TextEncoder();

export class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export function fail(status, code, message, details) {
  throw new ApiError(status, code, message, details);
}

export function json(value, status = 200, headers = {}) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      ...headers,
    },
  });
}

export function errorResponse(error) {
  if (error instanceof ApiError) {
    return json({ error: { code: error.code, message: error.message, ...(error.details ? { details: error.details } : {}) } }, error.status,
      error.status === 429 ? { "Retry-After": "60" } : {});
  }
  return json({ error: { code: "internal_error", message: "The request could not be completed. Please try again." } }, 500);
}

export function createContext(request, env) {
  const ctx = { request, env: env || {}, origin: new URL(request.url).origin, cookies: [] };
  const db = ctx.env.DB;
  if (!db || typeof db.prepare !== "function" || typeof db.batch !== "function") {
    fail(503, "storage_unavailable", "Private workspace storage has not been configured.");
  }
  // Read replicas, when enabled, must not supply stale authorization state.
  ctx.db = typeof db.withSession === "function" ? db.withSession("first-primary") : db;
  return ctx;
}

export function finish(ctx, response) {
  const headers = new Headers(response.headers);
  for (const cookie of ctx.cookies) headers.append("Set-Cookie", cookie);
  headers.set("Cache-Control", "no-store");
  headers.set("X-Content-Type-Options", "nosniff");
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

export function checkOrigin(ctx) {
  if (ctx.request.headers.get("Origin") !== ctx.origin) {
    fail(403, "origin_rejected", "This action must come from the workspace website.");
  }
}

export function object(value, label = "Request") {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail(400, "invalid_input", `${label} must be a JSON object.`);
  return value;
}

export function string(value, label, max, { optional = false, empty = false, trim = false } = {}) {
  if (optional && (value === undefined || value === null)) return null;
  if (typeof value !== "string") fail(400, "invalid_input", `${label} must be text.`);
  const result = trim ? value.trim() : value;
  if ((!empty && !result.length) || result.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(result)) {
    fail(400, "invalid_input", `${label} is empty, too long, or contains unsupported characters.`);
  }
  return result;
}

export function uuid(value, label = "ID") {
  if (typeof value !== "string" || !UUID_RE.test(value)) fail(400, "invalid_input", `${label} must be a UUID.`);
  return value.toLowerCase();
}

export function choice(value, values, label) {
  if (!values.includes(value)) fail(400, "invalid_input", `${label} has an unsupported value.`);
  return value;
}

export async function readJson(request, maxBytes = 32768) {
  if (!/^application\/json(?:\s*;|$)/i.test(request.headers.get("Content-Type") || "")) {
    fail(415, "json_required", "Use application/json for this request.");
  }
  const size = Number(request.headers.get("Content-Length"));
  if (Number.isFinite(size) && size > maxBytes) fail(413, "payload_too_large", "This request is too large.");
  const text = await readText(request.body, maxBytes);
  try { return object(JSON.parse(text)); }
  catch (error) {
    if (error instanceof ApiError) throw error;
    fail(400, "invalid_json", "The request contains invalid JSON.");
  }
}

export async function readText(body, maxBytes) {
  if (!body) return "";
  const reader = body.getReader();
  const decoder = new TextDecoder("utf-8", { fatal: true });
  let total = 0;
  let result = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        fail(413, "payload_too_large", "This request is too large.");
      }
      result += decoder.decode(value, { stream: true });
    }
    return result + decoder.decode();
  } finally { reader.releaseLock(); }
}

export function base64url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function unbase64(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9+/_-]+={0,2}$/.test(value)) throw new Error("invalid encoding");
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/").replace(/=+$/, "");
  const binary = atob(normalized + "=".repeat((4 - normalized.length % 4) % 4));
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

export function randomToken(size = 32) {
  return base64url(crypto.getRandomValues(new Uint8Array(size)));
}

export async function sha256(value) {
  const bytes = new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
  return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function pkceChallenge(verifier) {
  return base64url(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(verifier))));
}

export async function encryptionKey(ctx) {
  if (!ctx.keyPromise) {
    ctx.keyPromise = (async () => {
      try {
        const bytes = unbase64(ctx.env.APP_ENCRYPTION_KEY);
        if (bytes.byteLength !== 32) throw new Error("invalid key");
        return await crypto.subtle.importKey("raw", bytes, "AES-GCM", false, ["encrypt", "decrypt"]);
      } catch { fail(503, "encryption_unavailable", "Private workspace encryption has not been configured."); }
    })();
  }
  return ctx.keyPromise;
}

function aad(purpose, userId, resourceId) {
  return encoder.encode(JSON.stringify(["aero", 1, purpose, userId, resourceId]));
}

export async function encrypt(ctx, purpose, userId, resourceId, value) {
  const key = await encryptionKey(ctx);
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce, additionalData: aad(purpose, userId, resourceId) }, key, encoder.encode(JSON.stringify(value)));
  return `v1.${base64url(nonce)}.${base64url(new Uint8Array(encrypted))}`;
}

export async function decrypt(ctx, purpose, userId, resourceId, cipher) {
  const key = await encryptionKey(ctx);
  try {
    const parts = cipher.split(".");
    if (parts.length !== 3 || parts[0] !== "v1") throw new Error("invalid ciphertext");
    const nonce = unbase64(parts[1]);
    if (nonce.length !== 12) throw new Error("invalid nonce");
    const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: nonce, additionalData: aad(purpose, userId, resourceId) }, key, unbase64(parts[2]));
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(plain));
  } catch { fail(503, "private_data_unavailable", "Stored private data could not be read."); }
}

export async function anonymousSubject(ctx) {
  await encryptionKey(ctx);
  const key = await crypto.subtle.importKey("raw", encoder.encode(ctx.env.APP_ENCRYPTION_KEY), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const ip = ctx.request.headers.get("CF-Connecting-IP") || "unidentified";
  return `anonymous:${base64url(new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(ip))))}`;
}

export function statement(ctx, sql, params = []) { return ctx.db.prepare(sql).bind(...params); }

export async function first(ctx, sql, params = []) {
  try { return await statement(ctx, sql, params).first(); }
  catch { fail(503, "storage_unavailable", "Private workspace storage is temporarily unavailable."); }
}

export async function all(ctx, sql, params = []) {
  try {
    const result = await statement(ctx, sql, params).all();
    if (result.success === false) throw new Error("storage failure");
    return result.results || [];
  } catch { fail(503, "storage_unavailable", "Private workspace storage is temporarily unavailable."); }
}

export async function run(ctx, sql, params = []) {
  try {
    const result = await statement(ctx, sql, params).run();
    if (result.success === false) throw new Error("storage failure");
    return result;
  } catch { fail(503, "storage_unavailable", "Private workspace storage is temporarily unavailable."); }
}

export async function batch(ctx, entries) {
  try {
    const results = await ctx.db.batch(entries.map(([sql, params]) => statement(ctx, sql, params)));
    if (results.some((result) => result.success === false)) throw new Error("storage failure");
    return results;
  } catch { fail(503, "storage_unavailable", "Private workspace storage is temporarily unavailable."); }
}

export async function rateLimit(ctx, subject, scope, max, windowMs = 60000) {
  const bucket = Math.floor(Date.now() / windowMs) * windowMs;
  const result = await first(ctx,
    `INSERT INTO rate_limit_buckets (subject, scope, bucket_start, request_count)
     VALUES (?, ?, ?, 1)
     ON CONFLICT (subject, scope, bucket_start) DO UPDATE SET request_count = request_count + 1
     WHERE request_count < ? RETURNING request_count`, [subject, scope, bucket, max]);
  if (!result) fail(429, "rate_limited", "Too many requests. Please wait before trying again.");
}

export async function fetchJson(url, options, { timeoutMs = 12000, maxBytes = 1048576, service = "Authentication", credentialStatuses = [401, 403] } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal, redirect: "manual" });
    if (!response.ok) {
      await response.body?.cancel();
      if (credentialStatuses.includes(response.status)) fail(422, "upstream_credentials_rejected", `${service} could not accept the credentials for this request.`);
      if (response.status === 429) fail(429, "upstream_rate_limited", `${service} is temporarily rate limited. Please try again later.`);
      fail(502, "upstream_error", `${service} could not complete this request.`);
    }
    let parsed;
    try { parsed = JSON.parse(await readText(response.body, maxBytes)); }
    catch { fail(502, "upstream_invalid_response", `${service} returned an unreadable response.`); }
    return parsed;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (controller.signal.aborted) fail(504, "upstream_timeout", `${service} took too long to respond.`);
    const message=String(error?.message || "");
    const reason=/egress|outbound|denied|permission/i.test(message)?"network_policy":/redirect/i.test(message)?"redirect":/signal|abort/i.test(message)?"signal":/network|fetch|connect|DNS|socket/i.test(message)?"network":"other";
    console.error(JSON.stringify({event:"aero_transport_failed",kind:String(error?.name || "Error").replace(/[^A-Za-z]/g,"").slice(0,40),reason}));
    fail(503, "upstream_unavailable", `${service} is temporarily unavailable.`);
  } finally { clearTimeout(timer); }
}

export function models(ctx) {
  const result = { luna: ctx.env.MODEL_LUNA || "gpt-6-luna", sol: ctx.env.MODEL_SOL || "gpt-6.1-sol" };
  if (Object.values(result).some((name) => typeof name !== "string" || !/^[a-zA-Z0-9._:-]{1,80}$/.test(name))) {
    fail(503, "model_configuration_invalid", "The workspace models have not been configured correctly.");
  }
  return result;
}

export function iso(value = Date.now()) { return new Date(value).toISOString(); }

export function publicEdge(row) {
  return { id: row.id, fromId: row.from_id, toId: row.to_id, relation: row.relation, createdAt: iso(row.created_at) };
}

// Snapshot predicates use only IDs/revisions; record content remains encrypted.
export function snapshotPredicate(userId, sources) {
  if (!sources.length) return { sql: "1 = 1", params: [] };
  const sql = sources.map(() => "EXISTS (SELECT 1 FROM records r WHERE r.user_id = ? AND r.id = ? AND r.revision = ? AND r.archived = 0)").join(" AND ");
  return { sql, params: sources.flatMap((source) => [userId, source.id, source.revision]) };
}

export function relationPredicate(userId, relations) {
  if (!relations?.length) return { sql: "1 = 1", params: [] };
  return { sql: `NOT EXISTS (SELECT 1 FROM json_each(?) s LEFT JOIN edges e
    ON e.user_id = ? AND e.id = json_extract(s.value, '$.id')
    WHERE e.id IS NULL OR e.from_id <> json_extract(s.value, '$.fromId')
      OR e.to_id <> json_extract(s.value, '$.toId') OR e.relation <> json_extract(s.value, '$.relation'))`,
    params: [JSON.stringify(relations), userId] };
}
