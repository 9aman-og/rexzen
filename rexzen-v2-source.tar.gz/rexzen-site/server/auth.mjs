import { ApiError, UUID_RE, anonymousSubject, decrypt, encrypt, encryptionKey, fail, fetchJson, first, json, models, pkceChallenge, randomToken, rateLimit, run, sha256 } from "./core.mjs";

const SESSION_COOKIE = "__Host-aero-session";
const PKCE_COOKIE = "__Host-aero-pkce";
const SESSION_MS = 7 * 24 * 60 * 60 * 1000;
const IDLE_MS = 24 * 60 * 60 * 1000;
const LOGIN_MS = 10 * 60 * 1000;

function cookie(ctx, name, value, maxAge) {
  ctx.cookies.push(`${name}=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Lax`);
}

function getCookie(ctx, name) {
  const header = ctx.request.headers.get("Cookie") || "";
  if (header.length > 16384) return null;
  const matches = header.split(";").map((part) => part.trim()).filter((part) => part.startsWith(`${name}=`));
  if (matches.length !== 1) return null;
  return matches[0].slice(name.length + 1);
}

function authConfig(ctx) {
  let url;
  const key = ctx.env.SUPABASE_PUBLISHABLE_KEY;
  try {
    url = new URL(ctx.env.SUPABASE_URL);
    if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash || !["", "/"].includes(url.pathname)) throw new Error("invalid auth origin");
    if (typeof key !== "string" || key.length < 16 || key.length > 4096 || /\s/.test(key)) throw new Error("invalid public key");
  } catch { fail(503, "auth_unavailable", "Google sign-in has not been configured."); }
  return { origin: url.origin, headers: { apikey: key, "Content-Type": "application/json" } };
}

function tokenPayload(value, fallbackRefresh) {
  if (!value || typeof value.access_token !== "string" || value.access_token.length < 16 || value.access_token.length > 16384) {
    fail(502, "auth_invalid_response", "Sign-in returned an invalid session.");
  }
  const refreshToken = value.refresh_token ?? fallbackRefresh;
  if (typeof refreshToken !== "string" || refreshToken.length < 1 || refreshToken.length > 4096) {
    fail(502, "auth_invalid_response", "Sign-in returned an invalid session.");
  }
  const expiresIn = Number(value.expires_in);
  if (!Number.isFinite(expiresIn) || expiresIn < 1 || expiresIn > 86400) fail(502, "auth_invalid_response", "Sign-in returned an invalid session lifetime.");
  return { accessToken: value.access_token, refreshToken, accessExpiresAt: Date.now() + expiresIn * 1000 };
}

async function verifiedUser(ctx, accessToken, expectedId) {
  const config = authConfig(ctx);
  const user = await fetchJson(`${config.origin}/auth/v1/user`, {
    method: "GET", headers: { apikey: config.headers.apikey, Authorization: `Bearer ${accessToken}` },
  }, { service: "Sign-in", maxBytes: 131072 });
  if (!user || typeof user.id !== "string" || !UUID_RE.test(user.id) || (expectedId && user.id !== expectedId) ||
      typeof user.email !== "string" || user.email.length > 320 || !user.email.includes("@") ||
      typeof user.email_confirmed_at !== "string" || !Number.isFinite(Date.parse(user.email_confirmed_at))) {
    fail(401, "verified_account_required", "A verified email account is required to use this workspace.");
  }
  // Metadata is used solely for a display label. Authorization always uses the verified user ID.
  const candidate = user.user_metadata?.full_name || user.user_metadata?.name;
  const name = typeof candidate === "string" ? candidate.replace(/[\u0000-\u001f]/g, "").slice(0, 120) : user.email.split("@")[0].slice(0, 120);
  return { id: user.id, email: user.email, name };
}

export async function startGoogle(ctx) {
  await encryptionKey(ctx);
  const config = authConfig(ctx);
  await rateLimit(ctx, await anonymousSubject(ctx), "auth", 12, LOGIN_MS);
  const verifier = randomToken();
  const expiresAt = Date.now() + LOGIN_MS;
  const protectedCookie = await encrypt(ctx, "pkce", "login", ctx.origin, { verifier, expiresAt, origin: ctx.origin });
  cookie(ctx, PKCE_COOKIE, protectedCookie, LOGIN_MS / 1000);
  const authorize = new URL(`${config.origin}/auth/v1/authorize`);
  authorize.searchParams.set("provider", "google");
  authorize.searchParams.set("redirect_to", `${ctx.origin}/auth/callback`);
  authorize.searchParams.set("code_challenge", await pkceChallenge(verifier));
  authorize.searchParams.set("code_challenge_method", "s256");
  return new Response(null, { status: 303, headers: { Location: authorize.href } });
}

export async function googleCallback(ctx) {
  cookie(ctx, PKCE_COOKIE, "", 0);
  let stage = "pkce";
  try {
    await encryptionKey(ctx);
    const config = authConfig(ctx);
    await rateLimit(ctx, await anonymousSubject(ctx), "auth-callback", 12, LOGIN_MS);
    const raw = getCookie(ctx, PKCE_COOKIE);
    const code = new URL(ctx.request.url).searchParams.get("code");
    if (!raw || raw.length > 2048 || !code || code.length > 4096) fail(401, "login_expired", "Start Google sign-in again.");
    let login;
    try { login = await decrypt(ctx, "pkce", "login", ctx.origin, raw); }
    catch (error) {
      if (error instanceof ApiError && error.code === "encryption_unavailable") throw error;
      fail(401, "login_expired", "Start Google sign-in again.");
    }
    if (login.origin !== ctx.origin || login.expiresAt < Date.now() || !/^[A-Za-z0-9_-]{43}$/.test(login.verifier)) {
      fail(401, "login_expired", "Start Google sign-in again.");
    }
    stage = "exchange";
    const exchange = await fetchJson(`${config.origin}/auth/v1/token?grant_type=pkce`, {
      method: "POST", headers: config.headers, body: JSON.stringify({ auth_code: code, code_verifier: login.verifier }),
    }, { service: "Sign-in", maxBytes: 131072 });
    stage = "token";
    const tokens = tokenPayload(exchange);
    stage = "account";
    const user = await verifiedUser(ctx, tokens.accessToken);
    const sid = randomToken();
    const sidHash = await sha256(`aero-session:${sid}`);
    const now = Date.now();
    const cipher = await encrypt(ctx, "session", user.id, sidHash, { ...tokens, user });
    stage = "storage";
    await run(ctx, `INSERT INTO sessions (sid_hash, user_id, token_cipher, supabase_expires_at, expires_at, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)`, [sidHash, user.id, cipher, tokens.accessExpiresAt, now + SESSION_MS, now, now]);
    cookie(ctx, SESSION_COOKIE, sid, SESSION_MS / 1000);
    return new Response(null, { status: 303, headers: { Location: `${ctx.origin}/aero` } });
  } catch (error) {
    console.error(JSON.stringify({event:"aero_auth_failed",stage,code:error instanceof ApiError ? error.code : "internal_error"}));
    // A fixed, non-sensitive code is the only callback error exposed in the URL.
    const code = error instanceof ApiError && ["login_expired", "verified_account_required", "rate_limited", "auth_unavailable", "encryption_unavailable", "storage_unavailable"].includes(error.code) ? error.code : "sign_in_failed";
    return new Response(null, { status: 303, headers: { Location: `${ctx.origin}/aero?auth_error=${code}` } });
  }
}

export async function getSession(ctx) {
  if (ctx.sessionChecked) return ctx.session || null;
  ctx.sessionChecked = true;
  await encryptionKey(ctx);
  const sid = getCookie(ctx, SESSION_COOKIE);
  if (!sid || !/^[A-Za-z0-9_-]{43}$/.test(sid)) {
    if (sid) cookie(ctx, SESSION_COOKIE, "", 0);
    return null;
  }
  const sidHash = await sha256(`aero-session:${sid}`);
  const row = await first(ctx, "SELECT * FROM sessions WHERE sid_hash = ?", [sidHash]);
  if (!row || row.expires_at <= Date.now() || row.updated_at + IDLE_MS <= Date.now()) {
    if (row) await run(ctx, "DELETE FROM sessions WHERE sid_hash = ? AND user_id = ?", [sidHash, row.user_id]);
    cookie(ctx, SESSION_COOKIE, "", 0);
    return null;
  }
  let payload = await decrypt(ctx, "session", row.user_id, sidHash, row.token_cipher);
  if (!payload.user || payload.user.id !== row.user_id || !UUID_RE.test(row.user_id) || typeof payload.refreshToken !== "string") {
    fail(503, "private_data_unavailable", "Stored private session data could not be read.");
  }
  if (row.supabase_expires_at <= Date.now() + 120000) {
    const config = authConfig(ctx);
    try {
      const refreshed = await fetchJson(`${config.origin}/auth/v1/token?grant_type=refresh_token`, {
        method: "POST", headers: config.headers, body: JSON.stringify({ refresh_token: payload.refreshToken }),
      }, { service: "Sign-in", maxBytes: 131072, credentialStatuses: [400, 401, 403] });
      const tokens = tokenPayload(refreshed, payload.refreshToken);
      const user = await verifiedUser(ctx, tokens.accessToken, row.user_id);
      payload = { ...tokens, user };
      const cipher = await encrypt(ctx, "session", row.user_id, sidHash, payload);
      // A concurrent refresh may win; never overwrite its newer refresh token.
      const result = await run(ctx, `UPDATE sessions SET token_cipher = ?, supabase_expires_at = ?, updated_at = ?
        WHERE sid_hash = ? AND user_id = ? AND token_cipher = ?`, [cipher, tokens.accessExpiresAt, Date.now(), sidHash, row.user_id, row.token_cipher]);
      if (!result.meta?.changes) {
        const current = await first(ctx, "SELECT * FROM sessions WHERE sid_hash = ? AND user_id = ? AND expires_at > ?", [sidHash, row.user_id, Date.now()]);
        if (!current) { cookie(ctx, SESSION_COOKIE, "", 0); return null; }
        payload = await decrypt(ctx, "session", row.user_id, sidHash, current.token_cipher);
        if (payload.user?.id !== row.user_id) fail(503, "private_data_unavailable", "Stored private session data could not be read.");
      }
    } catch (error) {
      if (error instanceof ApiError && ["upstream_credentials_rejected", "verified_account_required"].includes(error.code)) {
        // Check for a newer concurrent refresh before invalidating this session.
        const current = await first(ctx, "SELECT token_cipher, supabase_expires_at FROM sessions WHERE sid_hash = ? AND user_id = ?", [sidHash, row.user_id]);
        if (current && current.token_cipher !== row.token_cipher && current.supabase_expires_at > Date.now()) {
          payload = await decrypt(ctx, "session", row.user_id, sidHash, current.token_cipher);
          if (payload.user?.id !== row.user_id) fail(503, "private_data_unavailable", "Stored private session data could not be read.");
        } else {
          await run(ctx, "DELETE FROM sessions WHERE sid_hash = ? AND user_id = ? AND token_cipher = ?", [sidHash, row.user_id, row.token_cipher]);
          cookie(ctx, SESSION_COOKIE, "", 0);
          return null;
        }
      } else throw error;
    }
  }
  // Verify with the auth server on every authenticated request. An unexpired
  // JWT alone would leave the Aero cookie usable after upstream sign-out.
  try {
    payload.user = await verifiedUser(ctx, payload.accessToken, row.user_id);
  } catch (error) {
    if (error instanceof ApiError && ["upstream_credentials_rejected", "verified_account_required"].includes(error.code)) {
      await run(ctx, "DELETE FROM sessions WHERE sid_hash = ? AND user_id = ?", [sidHash, row.user_id]);
      cookie(ctx, SESSION_COOKIE, "", 0);
      return null;
    }
    throw error;
  }
  if (row.updated_at < Date.now() - 5 * 60 * 1000) {
    await run(ctx, "UPDATE sessions SET updated_at = ? WHERE sid_hash = ? AND user_id = ?", [Date.now(), sidHash, row.user_id]);
  }
  ctx.session = { sidHash, user: payload.user, expiresAt: row.expires_at };
  ctx.user = payload.user;
  return ctx.session;
}

export async function requireUser(ctx) {
  const session = await getSession(ctx);
  if (!session) fail(401, "sign_in_required", "Sign in to use your private workspace.");
  checkExpectedAccount(ctx, session.user.id);
  return session.user;
}

// The cookie can change in another tab. Never accept a draft from the old
// account's loaded browser state into the newly signed-in account.
export function checkExpectedAccount(ctx, userId, required = true) {
  const expected = ctx.request.headers.get("X-Aero-Account");
  if (!required && expected === null) return;
  if (typeof expected !== "string" || !UUID_RE.test(expected)) {
    fail(409, "account_state_required", "Reload Aero before continuing with this account.");
  }
  if (expected !== userId) fail(409, "account_changed", "Your sign-in changed. Reload Aero before continuing.");
}

export function ownerKeyAvailable(ctx, userId) {
  return typeof ctx.env.OWNER_USER_ID === "string" && UUID_RE.test(ctx.env.OWNER_USER_ID) && userId === ctx.env.OWNER_USER_ID &&
    typeof ctx.env.OWNER_OPENAI_API_KEY === "string" && /^sk-[A-Za-z0-9_-]{16,500}$/.test(ctx.env.OWNER_OPENAI_API_KEY);
}

export async function keyStatus(ctx, userId) {
  const personal = await first(ctx, "SELECT user_id FROM private_keys WHERE user_id = ?", [userId]);
  const ownerKey = ownerKeyAvailable(ctx, userId);
  return { hasKey: Boolean(personal) || ownerKey, ownerKey, personalKey: Boolean(personal) };
}

export async function aiKey(ctx, userId) {
  const row = await first(ctx, "SELECT key_cipher FROM private_keys WHERE user_id = ?", [userId]);
  if (row) {
    const value = await decrypt(ctx, "private-key", userId, userId, row.key_cipher);
    if (typeof value.key !== "string" || !/^sk-[A-Za-z0-9_-]{16,500}$/.test(value.key)) fail(503, "private_data_unavailable", "The private AI key could not be read.");
    return value.key;
  }
  // This is the sole boundary at which the deployment owner's key can be selected.
  if (ownerKeyAvailable(ctx, userId)) return ctx.env.OWNER_OPENAI_API_KEY;
  fail(428, "ai_key_required", "Add your own OpenAI API key in settings before sending this request.");
}

export async function sessionResponse(ctx) {
  const session = await getSession(ctx);
  const configuredModels = models(ctx);
  if (!session) {
    await rateLimit(ctx, await anonymousSubject(ctx), "anonymous-session", 60);
    return json({ authenticated: false, user: null, models: configuredModels });
  }
  checkExpectedAccount(ctx, session.user.id, false);
  await rateLimit(ctx, session.user.id, "read", 120);
  return json({ authenticated: true, user: { ...session.user, ...await keyStatus(ctx, session.user.id) }, models: configuredModels });
}

export async function logout(ctx) {
  await rateLimit(ctx, await anonymousSubject(ctx), "logout", 30);
  const sid = getCookie(ctx, SESSION_COOKIE);
  if (sid && /^[A-Za-z0-9_-]{43}$/.test(sid)) {
    const sidHash = await sha256(`aero-session:${sid}`);
    const current = await first(ctx, "SELECT user_id FROM sessions WHERE sid_hash = ?", [sidHash]);
    if (current) checkExpectedAccount(ctx, current.user_id);
    await run(ctx, "DELETE FROM sessions WHERE sid_hash = ?", [sidHash]);
  }
  cookie(ctx, SESSION_COOKIE, "", 0);
  cookie(ctx, PKCE_COOKIE, "", 0);
  return json({ ok: true });
}
