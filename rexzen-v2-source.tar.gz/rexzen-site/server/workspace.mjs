import { EDGE_LIMIT, RECORD_LIMIT, all, batch, choice, decrypt, encrypt, fail, first, iso, json, object, publicEdge, readJson, run, snapshotPredicate, string, uuid } from "./core.mjs";
import { keyStatus } from "./auth.mjs";

const TYPES = ["note", "project", "task", "goal", "log", "personal"];
const STATUSES = ["open", "active", "done"];
const RELATIONS = ["supports", "depends_on", "part_of", "related"];

function dueDate(value) {
  if (value === undefined || value === null || value === "") return null;
  const due = string(value, "Due date", 40, { trim: true });
  if (/^\d{4}-\d{2}-\d{2}$/.test(due)) {
    const time = Date.parse(`${due}T00:00:00.000Z`);
    if (Number.isFinite(time) && iso(time).slice(0, 10) === due) return due;
  } else if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(due) && Number.isFinite(Date.parse(due))) {
    return iso(Date.parse(due));
  }
  fail(400, "invalid_input", "Due date must be a valid calendar date or ISO timestamp.");
}

function tagList(value) {
  if (!Array.isArray(value) || value.length > 12) fail(400, "invalid_input", "Use no more than 12 tags.");
  return [...new Set(value.map((tag) => string(tag, "Tag", 40, { trim: true })))];
}

export function normalizeRecord(input, previous, now = Date.now()) {
  object(input);
  const type = choice(input.type ?? previous?.type ?? "note", TYPES, "Record type");
  if (previous && type !== previous.type) fail(400, "record_type_immutable", "Create a new record to use a different record type.");
  if (previous && input.id !== undefined && uuid(input.id) !== previous.id) fail(400, "invalid_input", "Record ID cannot change.");
  const id = previous?.id || (input.id ? uuid(input.id) : crypto.randomUUID());
  const title = string(input.title ?? previous?.title ?? `Untitled ${type}`, "Title", 160, { trim: true });
  const body = string(input.body ?? previous?.body ?? "", "Body", 16000, { empty: true });
  const status = choice(input.status ?? previous?.status ?? "open", STATUSES, "Status");
  const due = input.due !== undefined ? dueDate(input.due) : previous?.due ?? null;
  const projectId = input.projectId !== undefined ? (input.projectId === null || input.projectId === "" ? null : uuid(input.projectId, "Project ID")) : previous?.projectId ?? null;
  const tags = input.tags !== undefined ? tagList(input.tags) : previous?.tags ?? [];
  const cloudAllowed = input.cloudAllowed !== undefined ? input.cloudAllowed : previous?.cloudAllowed ?? type !== "personal";
  if (typeof cloudAllowed !== "boolean") fail(400, "invalid_input", "Cloud permission must be true or false.");
  return { id, type, title, body, status, due, projectId, tags, cloudAllowed, revision: previous ? previous.revision + 1 : 1,
    archived: previous?.archived ?? false, createdAt: previous?.createdAt ?? iso(now), updatedAt: iso(now) };
}

export async function recordFromRow(ctx, userId, row) {
  const record = await decrypt(ctx, "record", userId, `${row.id}:${row.revision}`, row.cipher);
  if (!record || record.id !== row.id || record.revision !== row.revision || record.type !== row.type || record.archived !== Boolean(row.archived)) {
    fail(503, "private_data_unavailable", "Stored private record data could not be read.");
  }
  return record;
}

export async function getRecord(ctx, userId, id, { required = true, active = false } = {}) {
  const row = await first(ctx, "SELECT * FROM records WHERE user_id = ? AND id = ?", [userId, id]);
  if (!row) {
    if (required) fail(404, "record_not_found", "This record was not found in your workspace.");
    return null;
  }
  const record = await recordFromRow(ctx, userId, row);
  if (active && record.archived) fail(409, "record_archived", "Restore this record before using it.");
  return record;
}

async function projectSnapshot(ctx, userId, recordId, projectId) {
  const seen = new Set([recordId]);
  const sources = [];
  let id = projectId;
  while (id) {
    if (seen.has(id) || sources.length >= 32) fail(409, "project_cycle", "A project cannot contain itself or one of its parent projects.");
    seen.add(id);
    const parent = await getRecord(ctx, userId, id, { active: true });
    if (parent.type !== "project") fail(400, "invalid_project", "Project references must point to a project in your workspace.");
    sources.push({ id: parent.id, revision: parent.revision });
    id = parent.projectId;
  }
  return sources;
}

export async function createRecord(ctx) {
  const input = await readJson(ctx.request, 98304);
  const now = Date.now();
  const userId = ctx.user.id;
  const record = normalizeRecord(input, null, now);
  if (await getRecord(ctx, userId, record.id, { required: false })) fail(409, "record_exists", "A record with this ID already exists in your workspace.");
  const projects = await projectSnapshot(ctx, userId, record.id, record.projectId);
  const guard = snapshotPredicate(userId, projects);
  const cipher = await encrypt(ctx, "record", userId, `${record.id}:1`, record);
  let results;
  try {
    results = await batch(ctx, [
      [`INSERT INTO records (user_id, id, type, revision, archived, cipher, created_at, updated_at)
        SELECT ?, ?, ?, 1, 0, ?, ?, ? WHERE (${guard.sql}) AND (SELECT COUNT(*) FROM records WHERE user_id = ?) < ?`,
      [userId, record.id, record.type, cipher, now, now, ...guard.params, userId, RECORD_LIMIT]],
      [`INSERT INTO record_revisions (user_id, record_id, revision, cipher, created_at)
        SELECT user_id, id, revision, cipher, ? FROM records WHERE user_id = ? AND id = ? AND cipher = ?`, [now, userId, record.id, cipher]],
    ]);
  } catch (error) {
    if (await getRecord(ctx, userId, record.id, { required: false })) fail(409, "record_exists", "A record with this ID already exists in your workspace.");
    throw error;
  }
  if (!results[0].meta?.changes) {
    const count = await first(ctx, "SELECT COUNT(*) AS count FROM records WHERE user_id = ?", [userId]);
    if (count.count >= RECORD_LIMIT) fail(409, "workspace_limit", `This workspace supports up to ${RECORD_LIMIT} records including archived records.`);
    fail(409, "project_changed", "The selected project changed. Refresh the workspace and try again.");
  }
  return json({ record }, 201);
}

async function commitRecord(ctx, previous, record, projects) {
  const userId = ctx.user.id;
  const now = Date.now();
  const guard = snapshotPredicate(userId, projects);
  const cipher = await encrypt(ctx, "record", userId, `${record.id}:${record.revision}`, record);
  const results = await batch(ctx, [
    [`UPDATE records SET cipher = ?, revision = ?, archived = ?, updated_at = ?
      WHERE user_id = ? AND id = ? AND revision = ? AND (${guard.sql})`,
    [cipher, record.revision, record.archived ? 1 : 0, now, userId, record.id, previous.revision, ...guard.params]],
    [`INSERT INTO record_revisions (user_id, record_id, revision, cipher, created_at)
      SELECT user_id, id, revision, cipher, ? FROM records WHERE user_id = ? AND id = ? AND revision = ? AND cipher = ?`,
    [now, userId, record.id, record.revision, cipher]],
  ]);
  if (!results[0].meta?.changes) {
    const current = await getRecord(ctx, userId, record.id, { required: false });
    fail(409, "revision_conflict", "This record or its project changed. Refresh before saving again.", { currentRevision: current?.revision ?? null });
  }
  return json({ record });
}

export async function updateRecord(ctx, rawId) {
  const id = uuid(rawId);
  const input = await readJson(ctx.request, 98304);
  if (!Number.isSafeInteger(input.expectedRevision) || input.expectedRevision < 1) fail(400, "revision_required", "Supply the exact expectedRevision before updating a record.");
  const previous = await getRecord(ctx, ctx.user.id, id, { active: true });
  if (previous.revision !== input.expectedRevision) fail(409, "revision_conflict", "This record changed. Refresh before saving again.", { currentRevision: previous.revision });
  if (input.archived !== undefined && input.archived !== previous.archived) fail(400, "archive_action_required", "Use the archive or restore action to change archive status.");
  const record = normalizeRecord(input, previous);
  const projects = await projectSnapshot(ctx, ctx.user.id, id, record.projectId);
  return commitRecord(ctx, previous, record, projects);
}

export async function archiveRecord(ctx, rawId, restore = false) {
  const previous = await getRecord(ctx, ctx.user.id, uuid(rawId));
  const archived = !restore;
  if (previous.archived === archived) return json({ record: previous });
  const record = { ...previous, archived, revision: previous.revision + 1, updatedAt: iso() };
  const projects = restore ? await projectSnapshot(ctx, ctx.user.id, previous.id, previous.projectId) : [];
  return commitRecord(ctx, previous, record, projects);
}

export async function createEdge(ctx) {
  const input = await readJson(ctx.request, 4096);
  const fromId = uuid(input.fromId, "Source record ID");
  const toId = uuid(input.toId, "Target record ID");
  const relation = choice(input.relation, RELATIONS, "Relation");
  if (fromId === toId) fail(400, "self_edge", "A record cannot link to itself.");
  const userId = ctx.user.id;
  const from = await getRecord(ctx, userId, fromId, { active: true });
  const to = await getRecord(ctx, userId, toId, { active: true });
  const existing = await first(ctx, "SELECT * FROM edges WHERE user_id = ? AND from_id = ? AND to_id = ? AND relation = ?", [userId, fromId, toId, relation]);
  if (existing) return json({ edge: publicEdge(existing) });
  const guard = snapshotPredicate(userId, [from, to]);
  const id = crypto.randomUUID();
  const now = Date.now();
  // D1 serializes the cycle predicate and insert in the same statement.
  const result = await run(ctx, `WITH RECURSIVE reachable(id) AS (
      SELECT ? UNION SELECT e.to_id FROM edges e JOIN reachable p ON e.from_id = p.id
      WHERE e.user_id = ? AND e.relation = ?)
    INSERT INTO edges (user_id, id, from_id, to_id, relation, created_at)
    SELECT ?, ?, ?, ?, ?, ? WHERE (${guard.sql})
      AND (? NOT IN ('depends_on','part_of') OR NOT EXISTS (SELECT 1 FROM reachable WHERE id = ?))
      AND (SELECT COUNT(*) FROM edges WHERE user_id = ?) < ?
      AND NOT EXISTS (SELECT 1 FROM edges WHERE user_id = ? AND from_id = ? AND to_id = ? AND relation = ?)`,
  [toId, userId, relation, userId, id, fromId, toId, relation, now, ...guard.params, relation, fromId,
    userId, EDGE_LIMIT, userId, fromId, toId, relation]);
  if (!result.meta?.changes) {
    const concurrent = await first(ctx, "SELECT * FROM edges WHERE user_id = ? AND from_id = ? AND to_id = ? AND relation = ?", [userId, fromId, toId, relation]);
    if (concurrent) return json({ edge: publicEdge(concurrent) });
    const count = await first(ctx, "SELECT COUNT(*) AS count FROM edges WHERE user_id = ?", [userId]);
    if (count.count >= EDGE_LIMIT) fail(409, "workspace_limit", `This workspace supports up to ${EDGE_LIMIT} links.`);
    fail(409, "edge_conflict", "This link would create a cycle, or one of its records changed. Refresh and try again.");
  }
  return json({ edge: { id, fromId, toId, relation, createdAt: iso(now) } }, 201);
}

export async function deleteEdge(ctx, rawId) {
  const id = uuid(rawId);
  const result = await run(ctx, "DELETE FROM edges WHERE user_id = ? AND id = ?", [ctx.user.id, id]);
  if (!result.meta?.changes) fail(404, "edge_not_found", "This link was not found in your workspace.");
  return json({ ok: true, id });
}

function boundedPreferences(value) {
  object(value, "Preferences");
  let nodes = 0;
  function inspect(item, depth) {
    if (++nodes > 240 || depth > 4) fail(400, "invalid_preferences", "Preferences are too complex.");
    if (item === null || typeof item === "boolean") return;
    if (typeof item === "number" && Number.isFinite(item) && Math.abs(item) <= 1e12) return;
    if (typeof item === "string" && item.length <= 500) return;
    if (Array.isArray(item) && item.length <= 30) { item.forEach((child) => inspect(child, depth + 1)); return; }
    if (item && typeof item === "object" && !Array.isArray(item)) {
      const entries = Object.entries(item);
      if (entries.length > 50) fail(400, "invalid_preferences", "Preferences contain too many fields.");
      for (const [key, child] of entries) {
        if (key.length > 60 || ["__proto__", "prototype", "constructor"].includes(key)) fail(400, "invalid_preferences", "Preferences contain an unsupported field.");
        inspect(child, depth + 1);
      }
      return;
    }
    fail(400, "invalid_preferences", "Preferences contain an unsupported value.");
  }
  inspect(value, 0);
  if (new TextEncoder().encode(JSON.stringify(value)).byteLength > 8192) fail(400, "invalid_preferences", "Preferences are too large.");
  return value;
}

export async function preferences(ctx, userId) {
  const row = await first(ctx, "SELECT preferences_cipher FROM account_settings WHERE user_id = ?", [userId]);
  return row ? decrypt(ctx, "preferences", userId, userId, row.preferences_cipher) : {};
}

export async function updateSettings(ctx) {
  const input = await readJson(ctx.request, 12288);
  const value = boundedPreferences(input.preferences);
  const cipher = await encrypt(ctx, "preferences", ctx.user.id, ctx.user.id, value);
  await run(ctx, `INSERT INTO account_settings (user_id, preferences_cipher, updated_at) VALUES (?, ?, ?)
    ON CONFLICT (user_id) DO UPDATE SET preferences_cipher = excluded.preferences_cipher, updated_at = excluded.updated_at`, [ctx.user.id, cipher, Date.now()]);
  return json({ preferences: value });
}

export async function updateKey(ctx, remove = false) {
  const userId = ctx.user.id;
  if (remove) await run(ctx, "DELETE FROM private_keys WHERE user_id = ?", [userId]);
  else {
    const input = await readJson(ctx.request, 1024);
    const key = string(input.key, "API key", 503, { trim: true });
    if (!/^sk-[A-Za-z0-9_-]{16,500}$/.test(key)) fail(400, "invalid_key", "Enter a valid OpenAI API key.");
    const cipher = await encrypt(ctx, "private-key", userId, userId, { key });
    await run(ctx, `INSERT INTO private_keys (user_id, key_cipher, updated_at) VALUES (?, ?, ?)
      ON CONFLICT (user_id) DO UPDATE SET key_cipher = excluded.key_cipher, updated_at = excluded.updated_at`, [userId, cipher, Date.now()]);
  }
  return json(await keyStatus(ctx, userId));
}

export async function conversationFromRow(ctx, userId, row) {
  const conversation = await decrypt(ctx, "conversation", userId, row.id, row.cipher);
  if (conversation.id !== row.id) fail(503, "private_data_unavailable", "Stored private conversation data could not be read.");
  if (conversation.proposal && row.proposal_status) conversation.proposal.status = row.proposal_status;
  return conversation;
}

function streamJson(iterator, headers = {}) {
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async pull(controller) {
      try {
        const item = await iterator.next();
        if (item.done) controller.close();
        else controller.enqueue(encoder.encode(item.value));
      } catch { controller.error(new Error("Private workspace data could not be read.")); }
    },
    async cancel() { await iterator.return?.(); },
  });
  return new Response(stream, { headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers } });
}

export async function workspace(ctx) {
  const userId = ctx.user.id;
  const conversationRows = await all(ctx, `SELECT c.*, p.status AS proposal_status FROM conversations c
    LEFT JOIN receipts r ON r.user_id = c.user_id AND r.conversation_id = c.id
    LEFT JOIN proposals p ON p.user_id = c.user_id AND p.id = r.proposal_id
    WHERE c.user_id = ? ORDER BY c.created_at DESC, c.id LIMIT 100`, [userId]);
  const settings = await preferences(ctx, userId);
  async function* data() {
    yield '{"records":[';
    let cursorTime = Number.MAX_SAFE_INTEGER;
    let cursorId = "";
    let comma = false;
    while (true) {
      const page = await all(ctx, `SELECT * FROM records WHERE user_id = ? AND
        (updated_at < ? OR (updated_at = ? AND id > ?)) ORDER BY updated_at DESC, id LIMIT 100`, [userId, cursorTime, cursorTime, cursorId]);
      if (!page.length) break;
      for (const row of page) {
        yield `${comma ? "," : ""}${JSON.stringify(await recordFromRow(ctx, userId, row))}`;
        comma = true;
        cursorTime = row.updated_at;
        cursorId = row.id;
      }
    }
    yield '],"edges":[';
    cursorId = "";
    comma = false;
    while (true) {
      const page = await all(ctx, "SELECT * FROM edges WHERE user_id = ? AND id > ? ORDER BY id LIMIT 250", [userId, cursorId]);
      if (!page.length) break;
      for (const row of page) {
        yield `${comma ? "," : ""}${JSON.stringify(publicEdge(row))}`;
        comma = true;
        cursorId = row.id;
      }
    }
    yield '],"conversations":[';
    comma = false;
    for (const row of conversationRows) {
      yield `${comma ? "," : ""}${JSON.stringify(await conversationFromRow(ctx, userId, row))}`;
      comma = true;
    }
    yield `],"preferences":${JSON.stringify(settings)}}`;
  }
  return streamJson(data()[Symbol.asyncIterator]());
}

export async function exportWorkspace(ctx) {
  const userId = ctx.user.id;
  const exportedAt = iso();
  const settings = await preferences(ctx, userId);
  // Stream all portable data in bounded pages; no key or session table is read.
  async function* rows(table, transform) {
    let last = "";
    let comma = false;
    while (true) {
      const page = table === "conversations" ? await all(ctx, `SELECT c.*, p.status AS proposal_status FROM conversations c
        LEFT JOIN receipts r ON r.user_id = c.user_id AND r.conversation_id = c.id
        LEFT JOIN proposals p ON p.user_id = c.user_id AND p.id = r.proposal_id
        WHERE c.user_id = ? AND c.id > ? ORDER BY c.id LIMIT 100`, [userId, last]) :
        await all(ctx, `SELECT * FROM ${table} WHERE user_id = ? AND id > ? ORDER BY id LIMIT 250`, [userId, last]);
      if (!page.length) break;
      for (const row of page) {
        yield `${comma ? "," : ""}${JSON.stringify(await transform(row))}`;
        comma = true;
        last = row.id;
      }
    }
  }
  async function* data() {
    yield `{"version":1,"exportedAt":${JSON.stringify(exportedAt)},"records":[`;
    yield* rows("records", (row) => recordFromRow(ctx, userId, row));
    yield `],"edges":[`;
    yield* rows("edges", (row) => publicEdge(row));
    yield `],"preferences":${JSON.stringify(settings)},"conversations":[`;
    yield* rows("conversations", (row) => conversationFromRow(ctx, userId, row));
    yield "]}";
  }
  return streamJson(data()[Symbol.asyncIterator](), {
    "Content-Disposition": `attachment; filename="aero-export-${exportedAt.slice(0, 10)}.json"`,
  });
}
