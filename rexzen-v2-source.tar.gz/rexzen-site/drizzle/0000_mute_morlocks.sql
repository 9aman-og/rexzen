CREATE TABLE `account_settings` (
	`user_id` text PRIMARY KEY NOT NULL,
	`preferences_cipher` text NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `conversations` (
	`user_id` text NOT NULL,
	`id` text NOT NULL,
	`cipher` text NOT NULL,
	`created_at` integer NOT NULL,
	PRIMARY KEY(`user_id`, `id`)
);
--> statement-breakpoint
CREATE INDEX `conversations_user_created_idx` ON `conversations` (`user_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `edges` (
	`user_id` text NOT NULL,
	`id` text NOT NULL,
	`from_id` text NOT NULL,
	`to_id` text NOT NULL,
	`relation` text NOT NULL,
	`created_at` integer NOT NULL,
	PRIMARY KEY(`user_id`, `id`),
	CONSTRAINT "edges_relation_check" CHECK("edges"."relation" in ('supports','depends_on','part_of','related')),
	CONSTRAINT "edges_self_check" CHECK("edges"."from_id" <> "edges"."to_id")
);
--> statement-breakpoint
CREATE UNIQUE INDEX `edges_endpoints_relation_idx` ON `edges` (`user_id`,`from_id`,`to_id`,`relation`);--> statement-breakpoint
CREATE INDEX `edges_user_to_idx` ON `edges` (`user_id`,`to_id`);--> statement-breakpoint
CREATE TABLE `private_keys` (
	`user_id` text PRIMARY KEY NOT NULL,
	`key_cipher` text NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `proposals` (
	`user_id` text NOT NULL,
	`id` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`cipher` text NOT NULL,
	`source_snapshot` text NOT NULL,
	`created_at` integer NOT NULL,
	`applied_at` integer,
	PRIMARY KEY(`user_id`, `id`),
	CONSTRAINT "proposals_status_check" CHECK("proposals"."status" in ('pending','applied'))
);
--> statement-breakpoint
CREATE INDEX `proposals_user_status_idx` ON `proposals` (`user_id`,`status`);--> statement-breakpoint
CREATE TABLE `rate_limit_buckets` (
	`subject` text NOT NULL,
	`scope` text NOT NULL,
	`bucket_start` integer NOT NULL,
	`request_count` integer NOT NULL,
	PRIMARY KEY(`subject`, `scope`, `bucket_start`)
);
--> statement-breakpoint
CREATE INDEX `rate_buckets_expiry_idx` ON `rate_limit_buckets` (`bucket_start`);--> statement-breakpoint
CREATE TABLE `receipts` (
	`user_id` text NOT NULL,
	`id` text NOT NULL,
	`hash` text NOT NULL,
	`model` text NOT NULL,
	`status` text DEFAULT 'prepared' NOT NULL,
	`cipher` text NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL,
	`send_started_at` integer,
	`sent_at` integer,
	`conversation_id` text,
	`proposal_id` text,
	PRIMARY KEY(`user_id`, `id`),
	CONSTRAINT "receipts_status_check" CHECK("receipts"."status" in ('prepared','sending','sent','failed'))
);
--> statement-breakpoint
CREATE INDEX `receipts_expiry_idx` ON `receipts` (`expires_at`);--> statement-breakpoint
CREATE INDEX `receipts_user_conversation_idx` ON `receipts` (`user_id`,`conversation_id`);--> statement-breakpoint
CREATE TABLE `record_revisions` (
	`user_id` text NOT NULL,
	`record_id` text NOT NULL,
	`revision` integer NOT NULL,
	`cipher` text NOT NULL,
	`created_at` integer NOT NULL,
	PRIMARY KEY(`user_id`, `record_id`, `revision`)
);
--> statement-breakpoint
CREATE TABLE `records` (
	`user_id` text NOT NULL,
	`id` text NOT NULL,
	`type` text NOT NULL,
	`revision` integer NOT NULL,
	`archived` integer DEFAULT false NOT NULL,
	`cipher` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`user_id`, `id`),
	CONSTRAINT "records_type_check" CHECK("records"."type" in ('note','project','task','goal','log','personal')),
	CONSTRAINT "records_revision_check" CHECK("records"."revision" > 0)
);
--> statement-breakpoint
CREATE INDEX `records_user_updated_idx` ON `records` (`user_id`,`updated_at`);--> statement-breakpoint
CREATE INDEX `records_user_type_idx` ON `records` (`user_id`,`type`);--> statement-breakpoint
CREATE TABLE `sessions` (
	`sid_hash` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`token_cipher` text NOT NULL,
	`supabase_expires_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `sessions_user_idx` ON `sessions` (`user_id`);--> statement-breakpoint
CREATE INDEX `sessions_expiry_idx` ON `sessions` (`expires_at`);