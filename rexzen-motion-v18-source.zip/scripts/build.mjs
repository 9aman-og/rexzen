import {readFile,writeFile,readdir,mkdir,rm,cp} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve,extname,relative} from 'node:path';
import {createHash} from 'node:crypto';
import {build,transform} from 'esbuild';
const root=fileURLToPath(new URL('..',import.meta.url));
const dist=resolve(root,'dist');
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.mp4':'video/mp4','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.xml':'application/xml; charset=utf-8'};
const assets={};
const publicRoutes=new Map([['index.html','/'],['focus.html','/focus'],['research.html','/research'],['2piarc.html','/2piarc'],['frontiers.html','/frontiers'],['about.html','/about'],['principles.html','/principles'],['privacy.html','/privacy']]);
function metadata(html,file){
  const route=publicRoutes.get(relative(resolve(root,'public'),file));
  if(route===undefined)return html;
  const title=html.match(/<title>(.*?)<\/title>/s)?.[1]||'Rexzen';
  const description=html.match(/<meta\s+name="description"\s+content="([^"]*)"/)?.[1]||'';
  const url=`https://rexzen.si${route}`;
  const share={
    '/': ['open-arc-v18.jpg','Original Rexzen material study: an open graphite arc with a cobalt channel',1536,864],
    '/focus': ['aero-share-v18.png','Aero: selected sources, cited reasoning and reviewed plans',1200,630],
    '/2piarc': ['open-arc-v18.jpg','2piarc original concept study of an open form',1536,864],
    '/research': ['evidence-panels.jpg','Original concept study for Rexzen research, with translucent panels and intersecting views',1400,933],
    '/frontiers': ['frontier-fin.jpg','Rexzen material study for its longer-term research interests',1400,933],
    '/about': ['about-paper-perspectives.jpg','Original Rexzen study of paper apertures and a cobalt line',1536,1024]
  }[route]||['open-arc-v18.jpg','Original Rexzen material study',1536,864];
  const image=`https://rexzen.si/images/${share[0]}`;
  const pageId=`${url}#page`;
  const graph=[
    {'@type':'Organization','@id':'https://rexzen.si/#organization',name:'Rexzen',url:'https://rexzen.si/',logo:{'@type':'ImageObject',url:'https://rexzen.si/brand/rexzen-logo-512.png',width:512,height:512},sameAs:['https://www.linkedin.com/company/rexzen/','https://www.instagram.com/rexzen.si/'],description:'AI software and research.'},
    {'@type':'WebSite','@id':'https://rexzen.si/#website',name:'Rexzen',url:'https://rexzen.si/',publisher:{'@id':'https://rexzen.si/#organization'}},
    {'@type':'WebPage','@id':pageId,name:title,description,url,isPartOf:{'@id':'https://rexzen.si/#website'},about:{'@id':'https://rexzen.si/#organization'}}
  ];
  if(route!=='/')graph.push({'@type':'BreadcrumbList','@id':`${url}#breadcrumb`,itemListElement:[{'@type':'ListItem',position:1,name:'Rexzen',item:'https://rexzen.si/'},{'@type':'ListItem',position:2,name:title.split(' | ')[0],item:url}]});
  const json=JSON.stringify({'@context':'https://schema.org','@graph':graph}).replace(/</g,'\\u003c');
  const tags=`<meta name="robots" content="index, follow"><meta property="og:type" content="website"><meta property="og:site_name" content="Rexzen"><meta property="og:title" content="${title}"><meta property="og:description" content="${description}"><meta property="og:url" content="${url}"><meta property="og:image" content="${image}"><meta property="og:image:width" content="${share[2]}"><meta property="og:image:height" content="${share[3]}"><meta property="og:image:alt" content="${share[1]}"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${title}"><meta name="twitter:description" content="${description}"><meta name="twitter:image" content="${image}"><meta name="twitter:image:alt" content="${share[1]}"><script type="application/ld+json">${json}</script>`;
  return html.replace('</head>',`${tags}</head>`);
}
async function collect(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const file=resolve(dir,entry.name);if(entry.isDirectory())await collect(file);else if(entry.isFile()){const ext=extname(file);if(!types[ext])throw new Error(`Unsupported public asset: ${entry.name}`);if(ext==='.pdf')throw new Error('Original papers must not be public assets.');let bytes=await readFile(file);if(ext==='.js')bytes=Buffer.from((await transform(bytes.toString(),{sourcefile:file,loader:'js',target:'es2022',legalComments:'none'})).code);if(ext==='.html'){let html=bytes.toString();html=html.replace(/(<link rel="canonical" href=")\/(.*?)"/g,'$1https://rexzen.si/$2"');html=metadata(html,file);bytes=Buffer.from(html);}assets['/'+relative(resolve(root,'public'),file)]={type:types[ext],body:bytes.toString('base64'),hash:createHash('sha256').update(bytes).digest('hex').slice(0,24)};}}}
await collect(resolve(root,'public'));
// A fresh HTML response must load the matching client code after deployment,
// even when the browser still has an older script within its cache lifetime.
for(const asset of Object.values(assets)){
  if(!asset.type.startsWith('text/html'))continue;
  const html=Buffer.from(asset.body,'base64').toString().replace(/((?:src|href)=")([^"?]+\.(?:js|css|svg|jpg|jpeg|png|webp|mp4))"/g,(match,prefix,path)=>assets[path]?`${prefix}${path}?v=${assets[path].hash}"`:match);
  const bytes=Buffer.from(html);asset.body=bytes.toString('base64');asset.hash=createHash('sha256').update(bytes).digest('hex').slice(0,24);
}
await mkdir(resolve(root,'worker'),{recursive:true});
await writeFile(resolve(root,'worker/assets.generated.mjs'),`export const assets=${JSON.stringify(assets)};\n`);
await rm(dist,{recursive:true,force:true});await mkdir(resolve(dist,'server'),{recursive:true});await mkdir(resolve(dist,'.openai'),{recursive:true});
await build({entryPoints:[resolve(root,'worker/index.mjs')],outfile:resolve(dist,'server/index.js'),bundle:true,format:'esm',platform:'browser',target:'es2022',minify:false,legalComments:'none'});
await cp(resolve(root,'.openai/hosting.json'),resolve(dist,'.openai/hosting.json'));
await cp(resolve(root,'drizzle'),resolve(dist,'.openai/drizzle'),{recursive:true});
console.log(`Built Rexzen + Aero: ${Object.keys(assets).length} public assets; Worker and D1 migrations packaged.`);
