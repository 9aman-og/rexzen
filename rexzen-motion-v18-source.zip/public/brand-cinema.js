(() => {
  'use strict';
  const root = document.documentElement;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const began = performance.now();
  const navigation = performance.getEntriesByType('navigation')[0]?.type;
  const early = !reduced.matches && !document.hidden && !location.hash && navigation !== 'back_forward';
  if (early) root.setAttribute('data-brand-intro', 'armed');
  const safety = setTimeout(() => root.removeAttribute('data-brand-intro'), 1400);

  function ready() {
    const scene = document.querySelector('[data-brand-cinema]');
    if (!scene) { clearTimeout(safety); root.removeAttribute('data-brand-intro'); return; }
    const letters = [...scene.querySelectorAll('[data-brand-letter]')];
    const annotations = [...scene.querySelectorAll('[data-cinema-note]')];
    const video = scene.querySelector('video');
    const playButton = scene.querySelector('[data-cinema-play]');
    const scrub = scene.querySelector('[data-cinema-progress]');
    const time = scene.querySelector('[data-cinema-time]');
    const configured = Number(scene.dataset.duration);
    const duration = Number.isFinite(configured) && configured > 0 ? Math.min(configured, 30) : 10;
    const saveData = navigator.connection?.saveData === true;
    let animations = [], timer = null, consumed = false, introduced = false;
    let visible = false, disposed = false, manualPause = false, desiredSeek = null;
    let frame = null, unavailable = false, controlAction = null;
    const readViewport = () => ({width: innerWidth, height: innerHeight, contentWidth: root.clientWidth});
    let resizeBase = null;
    const validMetadata = () => Number.isFinite(video?.duration) && video.duration > 0;
    const endTime = () => validMetadata() ? Math.min(video.duration, duration) : duration;

    const eligible = () => visible && !disposed && !document.hidden && !root.classList.contains('directory-open');
    const settle = () => {
      clearTimeout(safety); animations.forEach(a => a.cancel()); animations = [];
      root.removeAttribute('data-brand-intro'); scene.dataset.identityState = 'settled';
    };
    const update = () => {
      const progress = Math.min(Number.isFinite(video?.currentTime) ? video.currentTime : 0, endTime());
      const end = endTime();
      if (scrub && document.activeElement !== scrub) scrub.value = String(Math.round(progress / end * 100));
      if (time) time.textContent = `${String(Math.floor(progress)).padStart(2, '0')} / ${String(Math.round(end)).padStart(2, '0')} sec`;
      if (playButton) playButton.textContent = unavailable ? 'Scene unavailable' : !video?.paused ? 'Pause scene' : video?.ended || progress >= end - .05 ? 'Replay scene' : 'Play scene';
      scene.dataset.mediaState = !video?.paused ? 'playing' : video?.ended ? 'complete' : 'paused';
    };
    const stop = (reason = 'user') => {
      scene.dataset.pauseReason = typeof reason === 'string' ? reason : reason.type;
      consumed = true; clearTimeout(timer); timer = null;
      video?.pause(); if (frame !== null) cancelAnimationFrame(frame); frame = null;
      scene.style.removeProperty('--cinema-x'); scene.style.removeProperty('--cinema-y');
      settle(); update();
    };
    const load = () => {
      if (!video || video.getAttribute('src')) return;
      video.src = video.dataset.src; video.load();
    };
    async function play(manual = false) {
      consumed = true;
      if (!video || unavailable || !eligible() || (!manual && (reduced.matches || saveData || manualPause))) return;
      if (manual || !resizeBase) resizeBase = readViewport();
      load();
      if (video.ended || video.currentTime >= endTime() - .05) video.currentTime = 0;
      try { await video.play(); if (!eligible()) video.pause(); }
      catch { /* The original poster and links remain usable if playback is blocked. */ }
      update();
    }
    function introduce() {
      if (introduced) return;
      if (!eligible()) { introduced = true; stop(); return; }
      introduced = true;
      resizeBase = readViewport();
      const covered = root.dataset.pageMotion === 'covered' || root.dataset.pageMotion === 'arriving';
      const prepared = root.getAttribute('data-brand-intro') === 'armed';
      if (!early || !prepared || reduced.matches || !scene.animate || (!covered && performance.now() - began > 450)) settle();
      else {
        scene.dataset.identityState = 'running';
        const rank = letters.length === 6 ? [0, 3, 1, 5, 2, 4] : [0, 2, 1, 3];
        annotations.forEach((node, i) => animations.push(node.animate([
          {opacity: .1, transform: 'translateY(4px)'}, {opacity: 1, transform: 'none'}
        ], {duration: 260, delay: i * 22, easing: 'ease-out', fill: 'both'})));
        letters.forEach((node, i) => animations.push(node.animate([
          {opacity: .10, fillOpacity: 0, strokeOpacity: .8},
          {opacity: .7, fillOpacity: 1, strokeOpacity: .2, offset: .24},
          {opacity: 1, fillOpacity: 1, strokeOpacity: 0}
        ], {duration: 540, delay: 80 + (rank[i] ?? i) * 60, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'both'})));
        root.removeAttribute('data-brand-intro'); clearTimeout(safety);
        Promise.allSettled(animations.map(a => a.finished)).then(settle);
      }
      if (!consumed && !reduced.matches && !saveData && navigation !== 'back_forward' && !location.hash) timer = setTimeout(() => { timer = null; play(); }, 960);
    }
    function maybeStart() {
      if (introduced || !eligible()) return;
      if (root.dataset.pageMotion === 'covered') return;
      introduce();
    }
    if (playButton) {
      playButton.hidden = false;
      playButton.addEventListener('pointerdown', () => { controlAction = video.paused ? 'play' : 'pause'; });
      playButton.addEventListener('pointercancel', () => { controlAction = null; });
      playButton.addEventListener('blur', () => { controlAction = null; });
      playButton.addEventListener('click', () => {
        const action = controlAction || (video.paused ? 'play' : 'pause'); controlAction = null;
        consumed = true; manualPause = true; clearTimeout(timer); settle();
        if (action === 'pause') stop(); else play(true);
      });
    }
    video?.addEventListener('loadedmetadata', () => {
      if (!validMetadata()) { unavailable = true; scene.removeAttribute('data-media-ready'); if (scrub) scrub.disabled = true; stop(); return; }
      if (scrub) scrub.disabled = false;
      if (desiredSeek !== null) { video.currentTime = Math.min(desiredSeek, endTime()); desiredSeek = null; }
      update();
    });
    video?.addEventListener('loadeddata', () => { if (!unavailable && validMetadata()) scene.dataset.mediaReady = 'true'; });
    for (const event of ['play', 'pause', 'ended']) video?.addEventListener(event, update);
    video?.addEventListener('timeupdate', () => { if (video.currentTime >= endTime() && !video.paused) video.pause(); update(); });
    video?.addEventListener('error', () => { unavailable = true; stop(); scene.removeAttribute('data-media-ready'); if (scrub) scrub.disabled = true; });
    const seek = () => {
      const fraction = Math.max(0, Math.min(1, Number(scrub.value) / 100));
      if (!Number.isFinite(fraction)) return;
      stop(); manualPause = true; load();
      const value = fraction * endTime();
      if (video.readyState >= 1 && validMetadata()) video.currentTime = value; else desiredSeek = value;
      update();
    };
    scrub?.addEventListener('input', seek);
    scrub?.addEventListener('change', seek);
    scene.addEventListener('focusin', () => { manualPause = true; stop(); });
    scene.addEventListener('pointermove', event => {
      if (event.pointerType === 'touch' || reduced.matches || !eligible() || !video.paused || frame !== null) return;
      const box = scene.getBoundingClientRect();
      const x = ((event.clientX - box.left) / box.width - .5) * 8;
      const y = ((event.clientY - box.top) / box.height - .5) * 5;
      frame = requestAnimationFrame(() => { frame = null; scene.style.setProperty('--cinema-x', `${x.toFixed(2)}px`); scene.style.setProperty('--cinema-y', `${y.toFixed(2)}px`); });
    });
    scene.addEventListener('pointerleave', () => { scene.style.removeProperty('--cinema-x'); scene.style.removeProperty('--cinema-y'); });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(entries => {
        visible = entries[0].isIntersecting && entries[0].intersectionRatio >= .12;
        if (!visible && introduced) stop(); else maybeStart();
      }, {threshold: .12}).observe(scene);
    } else { const box = scene.getBoundingClientRect(); visible = box.bottom > 0 && box.top < innerHeight; maybeStart(); }
    document.addEventListener('site-page-uncover', maybeStart);
    document.addEventListener('site-menu-open', stop);
    document.addEventListener('site-navigation-start', stop);
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); else maybeStart(); });
    reduced.addEventListener('change', stop);
    window.addEventListener('resize', () => {
      if (!resizeBase || (!introduced && (!video || video.paused))) return;
      const now = readViewport();
      // Browser chrome can settle by a few CSS pixels after navigation. Keep
      // this baseline fixed so a real incremental resize still interrupts.
      const sameHeight = Math.abs(now.height - resizeBase.height) <= 8;
      const widthChange = Math.abs(now.width - resizeBase.width);
      const gutterBudget = Math.max(0, resizeBase.width - resizeBase.contentWidth, now.width - now.contentWidth);
      const unchanged = sameHeight && widthChange <= 8;
      const gutterOnly = sameHeight && now.contentWidth === resizeBase.contentWidth && widthChange <= gutterBudget;
      if (!unchanged && !gutterOnly) stop('resize');
    }, {passive: true});
    window.addEventListener('pagehide', () => { disposed = true; stop(); });
    window.addEventListener('pageshow', event => { if (event.persisted) { disposed = false; consumed = true; introduced = true; stop(); } });
    update();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready, {once: true}); else ready();
})();
