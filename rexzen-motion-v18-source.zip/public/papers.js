const form=document.querySelector('#paper-unlock');
const input=document.querySelector('#paper-password');
const status=document.querySelector('#paper-status');
const buttons=[...document.querySelectorAll('[data-paper]')];
const envelopes=new Map();
let passwordBytes;
let firstPdf;
const decode=value=>Uint8Array.from(atob(value),c=>c.charCodeAt(0));

async function envelope(id) {
  if(envelopes.has(id))return envelopes.get(id);
  const response=await fetch(`/library/${id}.encrypted.json`,{credentials:'omit'});
  if(!response.ok)throw new Error('The encrypted file could not be loaded. Please try again.');
  const data=await response.json();
  if(data.format!=='rexzen-paper-v1'||data.algorithm!=='AES-256-GCM'||data.kdf!=='PBKDF2-SHA256'||data.iterations!==600000||data.id!==id)throw new Error('This encrypted file has an unsupported format.');
  envelopes.set(id,data);return data;
}
async function decrypt(id,secret) {
  const data=await envelope(id);
  const material=await crypto.subtle.importKey('raw',secret,'PBKDF2',false,['deriveKey']);
  const key=await crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt:decode(data.salt),iterations:data.iterations},material,{name:'AES-GCM',length:256},false,['decrypt']);
  let plain;
  try {plain=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(data.iv),additionalData:new TextEncoder().encode(`rexzen-paper-v1:${id}`)},key,decode(data.ciphertext)));}
  catch{throw new Error('The password could not unlock the paper. Check it and try again.');}
  if(new TextDecoder().decode(plain.slice(0,5))!=='%PDF-')throw new Error('The decrypted file is not a PDF.');
  const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',plain))].map(n=>n.toString(16).padStart(2,'0')).join('');
  if(hash!==data.sha256)throw new Error('The paper’s file integrity could not be verified.');
  return {plain,filename:data.filename};
}
form?.addEventListener('submit',async event=>{
  event.preventDefault();const submit=form.querySelector('[type=submit]');submit.disabled=true;buttons.forEach(b=>b.disabled=true);
  passwordBytes?.fill(0);firstPdf?.plain.fill(0);passwordBytes=undefined;firstPdf=undefined;
  const secret=new TextEncoder().encode(input.value);input.value='';status.textContent='Unlocking and checking the first PDF…';
  try {firstPdf=await decrypt('structural-novelty',secret);passwordBytes=secret;buttons.forEach(b=>b.disabled=false);status.textContent='Unlocked for this page. PDFs decrypt on your device; the password is not saved.';}
  catch(e){secret.fill(0);status.textContent=e.message;input.focus();}finally{submit.disabled=false;}
});
buttons.forEach(button=>button.addEventListener('click',async()=>{
  if(!passwordBytes)return;button.disabled=true;status.textContent='Preparing your PDF…';
  try {const result=button.dataset.paper==='structural-novelty'&&firstPdf?firstPdf:await decrypt(button.dataset.paper,passwordBytes);const url=URL.createObjectURL(new Blob([result.plain],{type:'application/pdf'}));const link=document.createElement('a');link.href=url;link.download=result.filename;link.click();setTimeout(()=>URL.revokeObjectURL(url),15000);status.textContent='PDF download prepared. The original file passed its integrity check.';}
  catch(e){status.textContent=e.message;}finally{button.disabled=false;}
}));
window.addEventListener('pagehide',()=>{passwordBytes?.fill(0);firstPdf?.plain.fill(0);passwordBytes=undefined;firstPdf=undefined;buttons.forEach(b=>b.disabled=true);});
