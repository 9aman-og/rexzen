(() => {
  'use strict';
  const root = document.documentElement;
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const active = new Map();
  const pending = new Set();
  const seen = new WeakSet();
  const segmenter = typeof Intl.Segmenter === 'function' ? new Intl.Segmenter(undefined, {granularity:'grapheme'}) : null;
  let observer;
  let frame;
  let arrivalUncovered = false;
  let fontsReady = !document.fonts || document.fonts.status !== 'loading';
  let fontTimer;

  const graphemes = text => segmenter ? [...segmenter.segment(text)].map(x=>x.segment) : Array.from(text);
  function consume(node) {
    seen.add(node);
    pending.delete(node);
    observer?.unobserve(node);
    node.dataset.textState = 'settled';
  }
  function settle(node) {
    const job = active.get(node);
    if (!job) return;
    active.delete(node);
    observer?.unobserve(node);
    job.animations.forEach(animation => animation.cancel());
    node.replaceChildren(...job.original);
    if (job.label === null) node.removeAttribute('aria-label');
    else node.setAttribute('aria-label', job.label);
    node.dataset.textState = 'settled';
  }
  function pause(discardPending = false) {
    if (frame) cancelAnimationFrame(frame);
    frame = null;
    [...active.keys()].forEach(settle);
    observer?.disconnect();
    // A cancelled entrance stays readable. Future headings retain their turn.
    if (discardPending) [...pending].forEach(consume);
  }
  function blocked() {
    const phase = root.getAttribute('data-page-motion');
    return preference.matches || document.hidden || root.classList.contains('directory-open') ||
      !!(phase && !(phase === 'arriving' && arrivalUncovered));
  }
  function canReveal(node) {
    return !blocked() && node.isConnected && typeof node.animate === 'function' &&
      !node.contains(document.activeElement);
  }
  function fontGateReady() {
    // Incoming pages already have a painted cover. Use intact text while a
    // font loads rather than revealing a complete title before its entrance.
    return fontsReady || (arrivalUncovered && root.getAttribute('data-page-motion') === 'arriving');
  }
  function cadence(node) {
    if (node.closest('#workspace')) return {piece:180, spread:220, character:12, word:45, fallback:300};
    if (node.tagName === 'H1') return {piece:320, spread:580, character:27, word:95, fallback:420};
    return {piece:220, spread:330, character:16, word:60, fallback:360};
  }
  function reveal(node) {
    if (seen.has(node) || blocked()) return;
    if (!canReveal(node)) { consume(node); return; }
    seen.add(node);
    pending.delete(node);
    const original = [...node.childNodes];
    const label = node.getAttribute('aria-label');
    const clone = node.cloneNode(true);
    clone.querySelectorAll('br').forEach(br => br.replaceWith(' '));
    const name = clone.textContent.replace(/\s+/g,' ').trim();
    const characterMode = graphemes(name).length <= 48;
    const fragment = document.createDocumentFragment();
    original.forEach(child => fragment.append(child.cloneNode(true)));
    const walker = document.createTreeWalker(fragment, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);
    const pieces = [];
    textNodes.forEach(text => {
      const tokens = characterMode ? graphemes(text.data) : text.data.split(/(\s+)/);
      const replacement = document.createDocumentFragment();
      tokens.forEach(token => {
        if (!token.trim()) { replacement.append(document.createTextNode(token)); return; }
        const span = document.createElement('span');
        span.textContent = token;
        span.setAttribute('aria-hidden','true');
        span.dataset.textPiece = '';
        replacement.append(span);
        pieces.push(span);
      });
      text.replaceWith(replacement);
    });
    const height = node.getBoundingClientRect().height;
    const profile = cadence(node);
    node.setAttribute('aria-label', label || name);
    node.replaceChildren(fragment);
    node.dataset.textState = 'running';
    const job = {original,label,animations:[]};
    active.set(node,job);
    observer?.observe(node);
    try {
      // Do not animate split glyphs if line wrapping or pending fonts are unstable.
      const stable = Math.abs(node.getBoundingClientRect().height-height) < 1 && document.fonts?.status !== 'loading';
      if (!stable || !pieces.length) {
        node.replaceChildren(...original);
        job.animations.push(node.animate([{opacity:.25},{opacity:1}],{duration:profile.fallback,easing:'ease-out'}));
      } else {
        const step = Math.min(characterMode ? profile.character : profile.word, profile.spread / Math.max(1,pieces.length-1));
        pieces.forEach((piece,index) => job.animations.push(piece.animate([{opacity:0},{opacity:1}],
          {duration:profile.piece,delay:index*step,easing:'cubic-bezier(.18,.72,.25,1)',fill:'backwards'})));
      }
      Promise.allSettled(job.animations.map(animation=>animation.finished)).then(()=>{
        if (active.get(node) === job) settle(node);
      });
    } catch { settle(node); }
  }
  function schedule() {
    if (frame || !pending.size || blocked() || !fontGateReady()) return;
    frame = requestAnimationFrame(()=>{
      frame = null;
      if (blocked() || !fontGateReady()) return;
      [...pending].forEach(node => {
        if (!node.isConnected) { pending.delete(node); observer?.unobserve(node); return; }
        const box = node.getBoundingClientRect();
        if (box.top < innerHeight*.92 && box.bottom > 0) reveal(node);
        else observer?.observe(node);
      });
    });
  }
  function collect(scope=document, working=false) {
    [...active.keys()].filter(node=>!node.isConnected).forEach(settle);
    [...pending].forEach(node=>{if(!node.isConnected){observer?.unobserve(node);pending.delete(node);}});
    const nodes = [...scope.querySelectorAll('[data-headline-reveal]')];
    const restored = !working && (location.hash || window.scrollY > 24 || performance.getEntriesByType('navigation')[0]?.type === 'back_forward');
    nodes.forEach(node => {
      if (seen.has(node)) return;
      if (preference.matches || restored) { consume(node); return; }
      pending.add(node);
    });
    schedule();
  }
  if ('IntersectionObserver' in window) observer = new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if (active.has(entry.target) && !entry.isIntersecting) settle(entry.target);
      else if (entry.isIntersecting && pending.has(entry.target) && !blocked() && fontGateReady()) reveal(entry.target);
    });
  },{rootMargin:'0px 0px -8% 0px',threshold:0});
  const coverObserver = new MutationObserver(()=>{
    const phase = root.getAttribute('data-page-motion');
    if (phase !== 'arriving') arrivalUncovered = false;
    if (blocked()) pause();
    else schedule();
  });
  coverObserver.observe(root,{attributes:true,attributeFilter:['data-page-motion']});
  document.addEventListener('site-page-uncover',()=>{
    if (root.getAttribute('data-page-motion') !== 'arriving') return;
    arrivalUncovered = true;
    schedule();
  });
  ['site-navigation-start','site-menu-open','aero-navigation-start'].forEach(event=>document.addEventListener(event,()=>pause()));
  document.addEventListener('site-menu-close',schedule);
  document.addEventListener('aero-view-rendered',event=>{if(event.detail?.animateHeadline)collect(document.querySelector('#workspace') || document,true);});
  const settleReading = event => {
    [...active.keys()].forEach(node=>{if(node.contains(event.target))settle(node);});
    [...pending].forEach(node=>{if(node.contains(event.target))consume(node);});
  };
  document.addEventListener('focusin',settleReading);
  document.addEventListener('pointerdown',settleReading,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();else schedule();});
  preference.addEventListener('change',()=>{if(preference.matches)pause(true);else schedule();});
  window.addEventListener('resize',()=>{[...active.keys()].forEach(settle);schedule();},{passive:true});
  window.addEventListener('pagehide',()=>pause(true));
  window.addEventListener('pageshow',event=>{if(event.persisted)pause(true);});
  const releaseFonts = () => {
    clearTimeout(fontTimer);
    fontsReady = true;
    if (document.fonts?.status === 'loaded') [...active.keys()].forEach(settle);
    schedule();
  };
  if (!fontsReady) {
    // A slow font must not become an unbounded entrance gate.
    fontTimer = setTimeout(releaseFonts,200);
    document.fonts.ready.then(releaseFonts,releaseFonts);
  }
  document.fonts?.addEventListener('loading',()=>pause());
  document.fonts?.addEventListener('loadingdone',releaseFonts);
  document.fonts?.addEventListener('loadingerror',releaseFonts);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',()=>collect(),{once:true});
  else collect();
})();
