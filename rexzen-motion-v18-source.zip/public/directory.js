(() => {
  const dialog = document.querySelector('#site-directory');
  const trigger = document.querySelector('.nav-toggle');
  if (!dialog?.showModal || !trigger) return;
  const root = document.documentElement;
  const preference = matchMedia('(prefers-reduced-motion: reduce)');
  const close = dialog.querySelector('[data-directory-close]');
  const figure = dialog.querySelector('.directory-feature-image');
  const image = figure.querySelector('img');
  const spareImage = image.cloneNode();
  figure.setAttribute('role', 'img'); figure.setAttribute('aria-label', image.alt);
  image.alt = ''; spareImage.alt = '';
  image.setAttribute('aria-hidden', 'true'); spareImage.setAttribute('aria-hidden', 'true');
  image.dataset.fit = figure.dataset.fit || 'cover';
  image.style.opacity = '1'; spareImage.style.opacity = '0';
  figure.append(spareImage);
  let currentImage = image;
  const title = dialog.querySelector('[data-directory-title]');
  const copy = dialog.querySelector('[data-directory-copy]');
  const featureLink = dialog.querySelector('[data-directory-link]');
  let closingTimer = null, previewRevision = 0, imageAnimations = [];
  const previews = {
    aero: {src: '/images/aero-source-review.svg', fit: 'contain', title: 'From your sources to the next step.', copy: 'Inspect the request, follow the citations and review a plan before it becomes work.', href: '/focus', link: 'Explore Aero', alt: 'Illustrated Aero workflow using fictional records'},
    research: {src: '/images/home-graphite-channel.jpg', title: 'Questions worth examining.', copy: 'Selected manuscripts on learning systems, computation and decision-making. Publication status is shown for each work.', href: '/research', link: 'Read the research', alt: 'Original Rexzen charcoal material study with a cobalt channel'},
    arc: {src: '/images/open-arc-v18.jpg', title: '2piarc, taking shape.', copy: 'A programme within Rexzen. Its public scope is in development.', href: '/2piarc', link: 'Explore 2piarc', alt: 'An original concept study of an open graphite arc above a stone slab'},
    frontiers: {src: '/images/frontier-fin.jpg', title: 'A practical start. A longer horizon.', copy: 'AI software today. Learning systems, neuromorphic computing and brain–computer interfaces shape our longer-term questions.', href: '/frontiers', link: 'Explore the frontiers', alt: 'A material study for Rexzen’s research directions'},
    about: {src: '/images/about-paper-perspectives.jpg', title: 'An independent direction.', copy: 'Learn about Rexzen’s current work, research interests and approach to building useful systems.', href: '/about', link: 'About Rexzen', alt: 'Paper apertures crossed by a single cobalt line'}
  };
  function settleImages() {
    imageAnimations.forEach(animation => animation.cancel()); imageAnimations = [];
    for (const layer of [image, spareImage]) {
      layer.style.opacity = layer === currentImage ? '1' : '0';
      layer.style.transform = 'none';
    }
  }
  function closeNow(restoreFocus = false) {
    clearTimeout(closingTimer); closingTimer = null;
    previewRevision++; settleImages();
    if (dialog.open) dialog.close();
    dialog.removeAttribute('data-state'); root.classList.remove('directory-open');
    root.classList.toggle('page-sleeping', document.hidden);
    trigger.setAttribute('aria-expanded', 'false');
    if (restoreFocus) trigger.focus({preventScroll: true});
  }
  function dismiss() {
    if (!dialog.open || closingTimer !== null) return;
    if (preference.matches) { closeNow(true); return; }
    dialog.dataset.state = 'closing';
    closingTimer = setTimeout(() => closeNow(true), 190);
  }
  async function preview(key) {
    const next = previews[key]; if (!next || !dialog.open) return;
    const revision = ++previewRevision;
    const preload = new Image(); preload.src = next.src;
    try { await preload.decode(); } catch { return; }
    if (revision !== previewRevision || !dialog.open) return;
    settleImages();
    const outgoing = currentImage;
    const incoming = currentImage === image ? spareImage : image;
    incoming.src = next.src; incoming.dataset.fit = next.fit || 'cover';
    figure.setAttribute('aria-label', next.alt);
    title.textContent = next.title; copy.textContent = next.copy;
    featureLink.href = next.href; featureLink.textContent = next.link;
    currentImage = incoming;
    if (preference.matches || !incoming.animate) { settleImages(); return; }
    imageAnimations = [
      outgoing.animate([{opacity: 1}, {opacity: 0}], {duration: 240, easing: 'ease-out', fill: 'both'}),
      incoming.animate([{opacity: 0, transform: 'scale(1.015)'}, {opacity: 1, transform: 'none'}], {duration: 240, easing: 'ease-out', fill: 'both'})
    ];
    const running = imageAnimations;
    Promise.allSettled(running.map(animation => animation.finished)).then(() => {
      if (running === imageAnimations) settleImages();
    });
  }
  document.body.classList.add('has-directory');
  trigger.setAttribute('aria-controls', 'site-directory'); trigger.setAttribute('aria-haspopup', 'dialog');
  trigger.addEventListener('click', () => {
    if (dialog.open) { dismiss(); return; }
    root.classList.add('directory-open'); dialog.showModal(); dialog.scrollTop = 0;
    trigger.setAttribute('aria-expanded', 'true'); root.classList.add('page-sleeping');
    document.dispatchEvent(new Event('site-menu-open')); close.focus({preventScroll: true});
  });
  close.addEventListener('click', dismiss);
  dialog.addEventListener('cancel', event => { event.preventDefault(); dismiss(); });
  dialog.addEventListener('close', () => {
    root.classList.remove('directory-open'); trigger.setAttribute('aria-expanded', 'false');
    root.classList.toggle('page-sleeping', document.hidden);
    document.dispatchEvent(new Event('site-menu-close'));
  });
  dialog.addEventListener('click', event => {
    const link = event.target.closest('a[href]');
    if (link && event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey && !link.target && !link.hasAttribute('download')) closeNow(false);
  });
  dialog.querySelectorAll('[data-directory-preview]').forEach(link => {
    link.addEventListener('pointerenter', event => { if (event.pointerType !== 'touch') preview(link.dataset.directoryPreview); });
    link.addEventListener('focus', () => preview(link.dataset.directoryPreview));
    if (new URL(link.href).pathname === location.pathname) link.setAttribute('aria-current', 'page');
  });
  document.addEventListener('site-navigation-start', () => closeNow(false));
  window.addEventListener('pagehide', () => closeNow(false));
  window.addEventListener('pageshow', event => { if (event.persisted) closeNow(false); });
  preference.addEventListener('change', () => { settleImages(); if (closingTimer !== null) closeNow(true); });
})();
