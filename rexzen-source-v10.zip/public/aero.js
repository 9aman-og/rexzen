const $ = (selector, root = document) => root.querySelector(selector);
const escape = (value = '') => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels = {home:'Overview',work:'Work',context:'Context',graph:'Relationships',ask:'Ask Aero',journal:'Journal',personal:'Personal',settings:'Settings'};
const kinds = {note:'Note',project:'Project',task:'Task',goal:'Goal',log:'Work log',personal:'Personal context'};
const relations = {supports:'supports',depends_on:'depends on',part_of:'is part of',related:'is related to'};
const state = {session:null,records:[],edges:[],conversations:[],preferences:{},selected:new Set(),view:viewFromPath(),filter:'all',search:'',demo:false,prepared:null,latest:null};
let toastTimer;
let editing;
let routeTransition;
let navigationRevision=0;
let prepareToolRevision=0;
const accountChannel = typeof BroadcastChannel === 'function' ? new BroadcastChannel('aero-account') : null;

function clearPrivateState() {
  navigationRevision++;routeTransition?.skipTransition();routeTransition=null;
  state.session={authenticated:false};state.records=[];state.edges=[];state.conversations=[];state.preferences={};state.selected.clear();state.latest=null;state.prepared=null;state.demo=false;delete state.draftQuestion;delete state.draftMode;delete state.draftTier;editing=null;
  document.querySelectorAll('dialog').forEach(dialog=>{if(dialog.open)dialog.close();dialog.querySelectorAll('form').forEach(form=>form.reset());});
  $('#record-form').elements.projectId.replaceChildren();$('#relation-form').elements.fromId.replaceChildren();$('#relation-form').elements.toId.replaceChildren();
  $('#detail-content').replaceChildren();$('#context-review').replaceChildren();$('#confirm-copy').textContent='';$('#confirm-action').onclick=null;clearTimeout(toastTimer);$('#toast').textContent='';$('#toast').hidden=true;
  render();
}
function accountInvalidated() { clearPrivateState();notice('Your sign-in changed or expired. Reload Aero to continue with the current account.',true); }
if(accountChannel)accountChannel.onmessage=event=>{const accountId=event.data?.accountId;if(state.session?.authenticated && (accountId===null || (typeof accountId==='string' && accountId!==state.session.user.id)))accountInvalidated();};

function viewFromPath() { return Object.keys(labels).includes(location.pathname.split('/')[2]) ? location.pathname.split('/')[2] : 'home'; }
function activeRecords() { return state.records.filter(r => !r.archived); }
function record(id) { return state.records.find(r => r.id === id); }
function date(value) { if (!value) return ''; const d = new Date(value.length === 10 ? `${value}T12:00:00` : value); if (Number.isNaN(d.valueOf())) return ''; const options={month:'short',day:'numeric',year:'numeric'}; if (value.length !== 10 && validTimezone(state.preferences.timezone)) options.timeZone=state.preferences.timezone; return new Intl.DateTimeFormat(undefined,options).format(d); }
function validTimezone(value) { if (typeof value !== 'string' || !value.trim()) return false; try { new Intl.DateTimeFormat(undefined,{timeZone:value}); return true; } catch { return false; } }
function toast(text) { $('#toast').textContent=text; $('#toast').hidden=false; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('#toast').hidden=true,4500); }
function notice(text='', error=false) { const node=$('#notice');node.textContent=text;node.hidden=!text;node.classList.toggle('error',error); }
async function api(path, data, method) {
  const expected=state.session?.authenticated?state.session.user.id:null;
  const headers=data === undefined?{}:{'Content-Type':'application/json'};if(expected)headers['X-Aero-Account']=expected;
  const response=await fetch(path,{method:method || (data === undefined?'GET':'POST'),credentials:'same-origin',headers,body:data === undefined?undefined:JSON.stringify(data),cache:'no-store'});
  let payload; try { payload=await response.json(); } catch { throw new Error('The workspace returned an unreadable response. Please try again.'); }
  if (!response.ok) { const error=new Error(payload.error?.message || 'This action could not be completed.');error.code=payload.error?.code;error.status=response.status;if(response.status===401 || ['account_changed','account_state_required'].includes(error.code))accountInvalidated();throw error; }
  if(expected && state.session?.user?.id!==expected){accountInvalidated();throw new Error('Your sign-in changed while this action was running. Reload Aero.');}
  return payload;
}
async function loadWorkspace() {
  if (state.demo) return;
  const data=await api('/api/workspace');
  Object.assign(state,{records:data.records || [],edges:data.edges || [],conversations:data.conversations || [],preferences:data.preferences || {}});
  state.selected=new Set([...state.selected].filter(id=>record(id)?.cloudAllowed && !record(id)?.archived));
}
function updateChrome() {
  const authenticated=state.session?.authenticated;
  $('.workspace-name').textContent=state.demo?'Example workspace':state.preferences.workspaceName || 'Personal workspace';
  $('#signin-top').hidden=!!authenticated;$('#signout').hidden=!authenticated;
  $('#quick-add').disabled=!(authenticated || state.demo);
  $('#account-label').textContent=authenticated ? state.session.user.email : state.demo ? 'Example workspace · not saved' : 'Not signed in';
  $('#view-label').textContent=labels[state.view];
  document.title=`${labels[state.view]} — Aero`;
  document.querySelectorAll('[data-view]').forEach(a=> { if(a.dataset.view===state.view) a.setAttribute('aria-current','page');else a.removeAttribute('aria-current'); });
}
function heading(title,copy,action='') { return `<div class="page-heading"><div><div class="eyebrow">${state.demo?'Example workspace':'Your workspace'}</div><h1>${escape(title)}</h1>${copy?`<p>${escape(copy)}</p>`:''}</div>${action}</div>`; }
function addButton(type, title='New record') { return `<button class="button" data-action="add" data-type="${type}">${title}</button>`; }
function empty(title,copy,type) { return `<div class="empty-state"><h2>${escape(title)}</h2><p>${escape(copy)}</p>${type?addButton(type,`Add a ${kinds[type].toLowerCase()}`):''}</div>`; }
function rows(records) {
  if (!records.length) return empty('Nothing here yet','Create a record to begin.');
  return `<div class="record-list">${records.map(r=> {
    const blockers=state.edges.filter(e=>e.fromId===r.id && e.relation==='depends_on' && record(e.toId)?.status!=='done' && !record(e.toId)?.archived).length;
    return `<div class="record-row">${r.type==='task'&&!r.archived ? `<input type="checkbox" data-task="${r.id}" aria-label="Mark ${escape(r.title)} ${r.status==='done'?'open':'done'}" ${r.status==='done'?'checked':''}>` : `<span class="kind-marker" aria-label="${kinds[r.type]}">${escape(r.type.slice(0,1).toUpperCase())}</span>`}<button class="record-open" data-action="detail" data-id="${r.id}"><span class="record-title">${escape(r.title)}</span><span class="record-meta"><span>${kinds[r.type]}</span>${r.projectId?`<span>${escape(record(r.projectId)?.title || 'Project')}</span>`:''}${r.due?`<span>Due ${date(r.due)}</span>`:''}${blockers?`<span>${blockers} dependencies open</span>`:''}<span>${r.cloudAllowed?'AI selectable':'Excluded from AI'}</span></span></button><span class="status-chip">${r.archived?'Archived':escape(r.status)}</span></div>`;
  }).join('')}</div>`;
}
function welcome() {
  return `<div class="welcome-panel"><div><div class="eyebrow">Aero / Private workspace</div><h1>Keep the context.<br>Move the work.</h1><p>A place for the notes, decisions, and next steps that make your work yours. Connect them when it helps. Ask Aero with the context you choose.</p><div class="welcome-actions"><a class="button" href="/auth/google">Sign in with Google</a><button class="button outline" data-action="demo">Explore an example</button></div><p class="private-note">Each account has its own workspace. Bring your OpenAI key in Settings to use AI.</p></div><ol class="workflow-list"><li><div><strong>Write it down</strong><span>Notes, projects, tasks, goals, and personal context.</span></div></li><li><div><strong>Connect the details</strong><span>Record what supports a decision and what depends on a task.</span></div></li><li><div><strong>Review before sending</strong><span>Choose the sources and see the question and context first.</span></div></li><li><div><strong>Turn a plan into work</strong><span>Read the proposed steps, then accept them into your task list.</span></div></li></ol></div><p class="private-note">The example uses fictional records and has no live AI responses. Your signed-in workspace is stored privately on the server.</p>`;
}
function renderHome() {
  const records=activeRecords();const tasks=records.filter(r=>r.type==='task'&&r.status!=='done');const notes=records.filter(r=>r.type==='note');const projects=records.filter(r=>r.type==='project'&&r.status!=='done');
  return heading('A little clarity for what comes next.','Your knowledge and work, in one place.')+`<div class="overview-summary"><div><strong>${tasks.length}</strong><span>Open tasks</span></div><div><strong>${projects.length}</strong><span>Active projects</span></div><div><strong>${notes.length}</strong><span>Context notes</span></div></div><div class="overview-grid"><section><div class="page-heading"><h2 class="section-title">Next in your work</h2><button class="subtle-button" data-view="work">All work →</button></div>${tasks.length?rows([...tasks].sort((a,b)=>(a.due || '9999').localeCompare(b.due || '9999')).slice(0,6)):empty('Room for your next step','Start with a task you can finish.','task')}<section class="list-section"><h2 class="section-title">Recent context</h2>${notes.length?rows(notes.slice(0,4)):empty('Keep a useful thought','Add a note, a source, or a decision you want to return to.','note')}</section></section><section class="panel"><div class="context-title"><img src="/brand/aero-mark.svg" alt=""><h2>From context to action</h2></div><p>Choose a few relevant notes, ask a question, and review a plan before adding it to your work.</p><ol class="workflow-list"><li><div><strong>Select</strong><span>Your question and the records that matter.</span></div></li><li><div><strong>Review</strong><span>The exact context, model, and source versions.</span></div></li><li><div><strong>Decide</strong><span>Keep the answer, or approve a plan into tasks.</span></div></li></ol><button class="button" data-view="ask">Ask Aero</button><p class="private-note">AI access: ${state.demo?'sign in to connect a key':state.session?.user.hasKey?'your account is configured':'add your own key in Settings'}.</p></section></div>`;
}
function renderRecords(view) {
  const config={work:['Work','Make the next step concrete. Keep projects, goals, and their tasks together.','task'],context:['Context','Keep sources, observations, and decisions you want to build on.','note'],journal:['Journal','Record what you did, what changed, and what you learned.','log'],personal:['Personal','Your preferences and personal context. New personal records are excluded from AI by default.','personal']}[view];
  const filters=view==='work'?['all','project','task','goal']:view==='context'?['all','note']:['all'];
  const scoped=activeRecords().filter(r=>view==='work'?['project','task','goal'].includes(r.type):view==='context'?r.type==='note':r.type===(view==='journal'?'log':'personal'));
  const tabs=filters.length>1?`<div class="tabs" role="group" aria-label="Filter records">${filters.map(f=>`<button data-filter="${f}" class="tab ${state.filter===f?'active':''}" aria-pressed="${state.filter===f}">${f==='all'?'All':kinds[f]+'s'}</button>`).join('')}</div>`:'';
  return heading(config[0],config[1],addButton(config[2],`New ${kinds[config[2]].toLowerCase()}`))+tabs+`<div class="toolbar"><input id="record-search" type="search" aria-label="Search these records" placeholder="Find a record…" value="${escape(state.search)}"><span class="selected-count">${scoped.length} records</span></div><div id="filtered-records">${filteredRows(scoped)}</div>`;
}
function filteredRows(scoped) { return rows(scoped.filter(r=>(state.filter==='all'||r.type===state.filter)&&`${r.title} ${r.body} ${r.tags.join(' ')}`.toLowerCase().includes(state.search.toLowerCase()))); }
function graphSvg(records,edges) {
  if (!records.length) return empty('Connections start with records','Create two records, then add a relationship.','note');
  const nodes=records.slice(0,30);const height=Math.max(330,Math.ceil(nodes.length/3)*110+50);const positions=new Map(nodes.map((r,i)=>[r.id,{x:45+(i%3)*290,y:35+Math.floor(i/3)*110}]));
  return `<div class="graph-wrap"><svg viewBox="0 0 900 ${height}" role="img" aria-label="Connections between the first ${nodes.length} workspace records"><defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7" fill="#b0bad1"/></marker></defs>${edges.filter(e=>positions.has(e.fromId)&&positions.has(e.toId)).map(e=>{const a=positions.get(e.fromId),b=positions.get(e.toId);return `<path class="graph-edge" marker-end="url(#arrow)" d="M ${a.x+115} ${a.y+28} L ${b.x+115} ${b.y+28}"/>`;}).join('')}${nodes.map(r=>{const p=positions.get(r.id);return `<g class="graph-node" data-action="detail" data-id="${r.id}" role="button" tabindex="0" aria-label="Open ${escape(r.title)}"><rect x="${p.x}" y="${p.y}" width="235" height="64" rx="5"/><text x="${p.x+13}" y="${p.y+25}">${escape(r.title.length>27?r.title.slice(0,26)+'…':r.title)}</text><text class="graph-label" x="${p.x+13}" y="${p.y+47}">${kinds[r.type]}</text></g>`;}).join('')}</svg></div>${records.length>30?'<p class="form-note">Showing the 30 most recent records here. The list below contains all relationships.</p>':''}`;
}
function renderGraph() {
  const records=activeRecords(),ids=new Set(records.map(r=>r.id)),edges=state.edges.filter(e=>ids.has(e.fromId)&&ids.has(e.toId));
  return heading('A relationship has a reason.','Connect evidence to a decision, a task to its dependencies, or an idea to its project.',`<button class="button" data-action="relation" ${records.length<2?'disabled':''}>Add relationship</button>`)+graphSvg(records,edges)+`<section class="list-section"><h2 class="section-title">${edges.length} relationships</h2>${edges.length?edges.map(e=>`<div class="relationship-row"><div><button class="subtle-button" data-action="detail" data-id="${e.fromId}">${escape(record(e.fromId).title)}</button> <span>${relations[e.relation]}</span> <button class="subtle-button" data-action="detail" data-id="${e.toId}">${escape(record(e.toId).title)}</button></div><button class="icon-button" data-action="unlink" data-id="${e.id}" aria-label="Remove relationship between ${escape(record(e.fromId).title)} and ${escape(record(e.toId).title)}">Remove</button></div>`).join(''):empty('No links yet','Links help you remember why two records belong together.')}</section>`;
}
function answerHtml(conversation) {
  const {answer,proposal}=conversation;
  return `<div class="panel answer-panel"><div class="eyebrow">${escape(conversation.model)} · ${date(conversation.createdAt)}</div><h2>${escape(conversation.question)}</h2><div class="answer">${escape(answer.text)}</div>${answer.citations?.length?`<div class="citation-list" aria-label="Referenced sources">${answer.citations.map(c=>`<button class="citation" data-action="citation" data-id="${c.id}" data-revision="${c.revision}">${escape(record(c.id)?.title || 'Source')} · v${c.revision}</button>`).join('')}</div><p class="form-note">Source references identify records the model used. Review the claims against the source.</p>`:''}${answer.steps?.length?`<section class="list-section"><h2 class="section-title">${proposal?.status==='applied'?'Accepted plan':'Proposed plan'}</h2>${answer.steps.map((s,i)=>`<div class="plan-step"><strong>${i+1}. ${escape(s.title)}</strong><p>${escape(s.body)}</p><p>Done when: ${escape(s.doneWhen)}</p>${s.dependsOn.length?`<small>Depends on: ${s.dependsOn.map(id=>escape(answer.steps.find(x=>x.id===id)?.title || id)).join(', ')}</small>`:''}</div>`).join('')}<p class="form-note">${proposal?.status==='applied'?'These steps are in your task list.':'Review every step. Accepting adds tasks and their dependencies to your workspace.'}</p>${proposal?.status==='pending'?`<button class="button" data-action="apply" data-id="${proposal.id}">Accept ${answer.steps.length} steps into Work</button>`:''}</section>`:''}<details class="list-section"><summary>Context receipt</summary><p class="form-note">${escape(conversation.receipt?.coverage?.summary || '')}</p><p class="review-hash">${escape(conversation.receipt?.hash || '')}</p></details></div>`;
}
function renderAsk() {
  const selectable=activeRecords().filter(r=>r.cloudAllowed);
  const selectedCount=state.selected.size;
  return heading('Ask with context.','Choose the records that matter. Review the request before sending it.')+`<div class="split-view"><form id="ask-form" class="panel ask-box"><label>Your question<textarea name="question" maxlength="4000" required placeholder="What should I do next on this project, and why?">${escape(state.draftQuestion || '')}</textarea></label><div class="form-row"><label>Response<select name="mode"><option value="answer">Answer with sources</option><option value="plan" ${state.draftMode==='plan'?'selected':''}>Propose a plan</option></select></label><label>Model<select name="tier"><option value="luna">Luna · everyday work</option><option value="sol" ${state.draftTier==='sol'?'selected':''}>Sol · deeper reasoning</option></select></label></div><p class="form-note">Nothing is sent to OpenAI until you review and press Send. ${state.demo?'Sign in to use live AI.':state.session.user.hasKey?'Requests use your account’s configured key.':'Add your OpenAI key in Settings to send a request.'}</p><p id="ask-error" class="form-error" role="alert"></p><button class="button" type="submit" ${state.demo?'disabled':''}>Review context →</button></form><section class="panel"><h2>Select context</h2><p class="selected-count"><span id="selected-count">${selectedCount}</span> / 12 selected · up to 18,000 characters</p><div class="context-list">${selectable.length?selectable.map(r=>`<label><input type="checkbox" data-source="${r.id}" ${state.selected.has(r.id)?'checked':''}><span><strong>${escape(r.title)}</strong><small>${kinds[r.type]} · v${r.revision}${r.due?' · due '+date(r.due):''}</small></span></label>`).join(''):'<p>No records are enabled for AI yet. Open a record and choose “Allow this record to be selected for AI requests.”</p>'}</div><p class="form-note">Only direct relationships between selected records are included. Personal context is excluded unless you enable it.</p></section></div>${state.latest?answerHtml(state.latest):''}<section class="list-section"><h2 class="section-title">Previous conversations</h2>${state.conversations.length?state.conversations.slice(0,20).map(c=>`<button class="history-row" data-action="conversation" data-id="${c.id}">${escape(c.question)}<small>${escape(c.model)} · ${date(c.createdAt)}${c.proposal?' · '+escape(c.proposal.status)+' plan':''}</small></button>`).join(''):'<p class="private-note">Your answers and reviewed plans will appear here.</p>'}</section>`;
}
function renderSettings() {
  const user=state.session?.user || {};
  const archived=state.records.filter(r=>r.archived);
  return heading('Settings','Your account, AI connection, and portable workspace data.')+`<div class="settings-grid"><section class="panel"><h2>Account</h2><p>${escape(user.email || 'Fictional example workspace')}</p><p class="form-note">Google handles sign-in. Records belong to this account and are encrypted in server storage. Encryption is managed by the service; this is not end-to-end encryption.</p><form id="preferences-form"><label>Workspace name<input name="workspaceName" maxlength="80" value="${escape(state.preferences.workspaceName || '')}" placeholder="My workspace"></label><label>Time zone<input name="timezone" maxlength="80" value="${escape(state.preferences.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone)}"></label><label>Preferred response style<select name="tone"><option value="concise">Concise and direct</option><option value="detailed" ${state.preferences.tone==='detailed'?'selected':''}>Detailed explanations</option></select></label><p class="form-note">Response style is saved as a workspace preference. Your question controls the current AI request.</p><button class="button" type="submit">Save preferences</button></form></section><section class="panel"><h2>AI connection</h2><div class="key-state">${state.demo?'Example · no key connected':user.ownerKey?'Your founder key is configured for this verified account.':user.personalKey?'Your personal key is connected.':'Connect your own OpenAI API key.'}</div><p class="form-note">Other accounts must supply their own key. Keys are encrypted in server storage and never returned to the browser, included in context, or exported. Requests may incur charges on the connected OpenAI account.</p><form id="key-form"><label>${user.hasKey?'Replace with a personal key':'OpenAI API key'}<input type="password" name="key" autocomplete="off" spellcheck="false" placeholder="sk-…" maxlength="503" ${state.demo?'disabled':''} required></label><button class="button" type="submit" ${state.demo?'disabled':''}>Save private key</button></form>${user.personalKey?'<button class="button outline" data-action="remove-key">Remove personal key</button>':''}<p class="form-note">Luna: ${escape(state.session?.models?.luna || 'gpt-6-luna')}<br>Sol: ${escape(state.session?.models?.sol || 'gpt-6.1-sol')}</p></section><section class="panel"><h2>Take your work with you</h2><p>Export your records, relationships, preferences, and conversations. API keys and sign-in tokens are excluded.</p><button class="button outline" data-action="export">Export workspace JSON</button><h3 class="section-title list-section">Import records</h3><p class="form-note">Choose an Aero JSON export or a text note. You’ll review the count first. Imports copy active records and relationships into this account; conversations and credentials are not imported.</p><label>Choose a file<input id="import-file" class="import-input" type="file" accept=".json,.txt,.md,application/json,text/plain"></label></section><section class="panel"><h2>Archived records</h2><p>Archive removes a record from current work and AI selection. Restore it whenever you need it.</p>${archived.length?archived.map(r=>`<div class="relationship-row"><span>${escape(r.title)}</span><button class="subtle-button" data-action="restore" data-id="${r.id}">Restore</button></div>`).join(''): '<p class="form-note">No archived records.</p>'}</section></div>`;
}
function render() {
  updateChrome();
  $('#workspace').innerHTML=!state.session?.authenticated&&!state.demo?welcome():state.view==='home'?renderHome():['work','context','journal','personal'].includes(state.view)?renderRecords(state.view):state.view==='graph'?renderGraph():state.view==='ask'?renderAsk():renderSettings();
}
function navigate(view,push=true) {
  const previous=state.view;const revision=++navigationRevision;
  routeTransition?.skipTransition();
  state.view=labels[view]?view:'home';state.filter='all';state.search='';
  if(push) history.pushState({},'',state.view==='home'?'/aero':`/aero/${state.view}`);
  $('.sidebar').classList.remove('open');$('#menu-toggle').setAttribute('aria-expanded','false');
  const update=()=>{if(revision!==navigationRevision)return;render();window.scrollTo({top:0,behavior:'instant'});$('#workspace').focus({preventScroll:true});};
  if(document.startViewTransition && previous!==state.view && !document.hidden && !matchMedia('(prefers-reduced-motion: reduce)').matches){
    const transition=document.startViewTransition(update);routeTransition=transition;
    transition.finished.catch(()=>{}).finally(()=>{if(routeTransition===transition)routeTransition=null;});
    return transition.updateCallbackDone.catch(()=>{});
  }
  update();return Promise.resolve();
}
function openRecord(type='note',id) {
  editing=id?record(id):null;const form=$('#record-form');form.reset();
  $('#record-dialog-title').textContent=editing?'Edit record':'New record';$('#record-error').textContent='';
  form.elements.projectId.innerHTML='<option value="">No project</option>'+activeRecords().filter(r=>r.type==='project'&&r.id!==id).map(r=>`<option value="${r.id}">${escape(r.title)}</option>`).join('');
  form.elements.type.value=editing?.type || type;form.elements.type.disabled=!!editing;
  for(const field of ['title','body','status','projectId']) if(editing) form.elements[field].value=editing[field] || (field==='status'?'open':'');
  form.elements.due.value=editing?.due?.slice(0,10) || '';form.elements.tags.value=editing?.tags?.join(', ') || '';
  form.elements.cloudAllowed.checked=editing?.cloudAllowed || false;
  $('#record-dialog').showModal();
}
function detail(id,citedRevision) {
  const r=record(id);if(!r) return toast('This source is no longer in the workspace.');
  const linked=state.edges.filter(e=>e.fromId===id||e.toId===id);
  const linkedHtml=linked.length ? '<h3 class="section-title">Relationships</h3>'+linked.map(e=>`<p class="detail-meta">${escape(record(e.fromId)?.title || 'Archived source')} ${relations[e.relation]} ${escape(record(e.toId)?.title || 'Archived source')}</p>`).join('') : '';
  $('#detail-content').innerHTML=`<div class="dialog-heading"><h2>${escape(r.title)}</h2><button class="icon-button" data-close>Close</button></div><div class="detail-meta">${kinds[r.type]} · ${escape(r.status)} · version ${r.revision}${r.due?' · due '+date(r.due):''}<br>${r.cloudAllowed?'Enabled for explicit AI selection':'Excluded from AI requests'}${r.tags.length?' · '+escape(r.tags.join(', ')):''}</div>${citedRevision&&Number(citedRevision)!==r.revision?`<p class="stale-message">The answer referenced version ${Number(citedRevision)}. You’re viewing version ${r.revision}, which has changed since that answer.</p>`:''}<div class="detail-body">${escape(r.body || 'No additional content.')}</div>${linkedHtml}<div class="dialog-actions">${r.archived?`<button class="button" data-action="restore" data-id="${r.id}">Restore</button>`:`<button class="button outline" data-action="archive" data-id="${r.id}">Archive</button><button class="button" data-action="edit" data-id="${r.id}">Edit record</button>`}</div>`;
  if(!$('#detail-dialog').open) $('#detail-dialog').showModal();
}
async function saveRecord(data,id,expectedRevision) {
  if(state.demo) { const previous=id?record(id):null;const r={...previous,...data,id:id || crypto.randomUUID(),revision:(previous?.revision || 0)+1,createdAt:previous?.createdAt || new Date().toISOString(),updatedAt:new Date().toISOString(),archived:false};state.records=[r,...state.records.filter(x=>x.id!==r.id)];return r; }
  const result=await api(id?`/api/records/${id}`:'/api/records',id?{...data,expectedRevision:expectedRevision ?? record(id).revision}:data,id?'PATCH':'POST');
  state.records=[result.record,...state.records.filter(x=>x.id!==result.record.id)];return result.record;
}
function confirmAction(title,copy,button,action) {
  $('#confirm-title').textContent=title;$('#confirm-copy').textContent=copy;$('#confirm-action').textContent=button;
  $('#confirm-action').onclick=async()=>{const btn=$('#confirm-action');btn.disabled=true;try { await action();$('#confirm-dialog').close(); } catch(e){notice(e.message,true);}finally{btn.disabled=false;}};
  $('#confirm-dialog').showModal();
}
async function archive(id,restore=false) {
  if(state.demo) { const r=record(id);r.archived=!restore;r.revision++; }
  else {const result=await api(`/api/records/${id}${restore?'/restore':''}`,restore?{}:undefined,restore?'POST':'DELETE');state.records=state.records.map(r=>r.id===id?result.record:r);}
  state.selected.delete(id);$('#detail-dialog').close();render();toast(restore?'Record restored.':'Record archived. You can restore it in Settings.');
}
function showReview(data) {
  state.prepared=data;
  const request=data.request || {question:state.draftQuestion,mode:state.draftMode,tier:state.draftTier};
  $('#context-review').innerHTML=`<div class="dialog-heading"><h2>Review this request</h2><button data-close class="icon-button">Close</button></div><p class="form-note">Destination: OpenAI · ${escape(data.receipt.model)}<br>Mode: ${escape(request.mode)} · expires ${new Date(data.receipt.expiresAt).toLocaleTimeString()}</p><h3 class="section-title">Your question</h3><div class="detail-body">${escape(request.question)}</div><p class="form-note">${escape(data.receipt.coverage.summary)}</p>${data.evidence.map(e=>`<section class="review-source"><h3>${escape(e.title)} · v${e.revision}</h3><pre>${escape(e.excerpt)}</pre></section>`).join('')}<h3 class="section-title list-section">Selected relationships</h3>${data.relations.length?data.relations.map(e=>`<p class="form-note">${escape(record(e.fromId)?.title)} ${relations[e.relation]} ${escape(record(e.toId)?.title)}</p>`).join(''):'<p class="form-note">No direct links among selected records.</p>'}${request.wire?`<details><summary>Complete outbound request</summary><pre class="wire-preview">${escape(request.wire)}</pre></details>`:''}<p class="review-hash">SHA-256: ${escape(data.receipt.hash)}</p><p class="form-note">Pressing Send shares this question and reviewed context with OpenAI using your account’s key. Source permissions and versions are checked again before dispatch.</p><p id="send-error" role="alert" class="form-error"></p><div class="dialog-actions"><button data-close class="button outline">Cancel</button>${state.session.user.hasKey?'<button class="button" data-action="send">Send this request</button>':'<button class="button" data-action="key-settings">Connect your key first</button>'}</div>`;
  $('#context-dialog').showModal();
}
function demoWorkspace() {
  state.demo=true;const now=new Date().toISOString();const ids=Array.from({length:5},()=>crypto.randomUUID());
  const examples=[['project','Field notebook','A fictional project: make a short guide to the night sky.'],['note','Observation notes','Clear sky at 21:00. The best view was away from street lights. Keep the guide readable without specialised equipment.'],['task','Draft the first page','Explain what a reader can look for in ten minutes.'],['goal','A guide someone can use','A reader can identify three constellations from the guide.'],['personal','Working preferences','Fictional preference: short writing sessions and concrete examples.']];
  state.records=examples.map((e,i)=>({id:ids[i],type:e[0],title:e[1],body:e[2],status:i===0?'active':'open',projectId:i===2?ids[0]:null,due:null,tags:['example'],cloudAllowed:i!==4,revision:1,archived:false,createdAt:now,updatedAt:now}));
  state.edges=[{id:crypto.randomUUID(),fromId:ids[1],toId:ids[2],relation:'supports',createdAt:now},{id:crypto.randomUUID(),fromId:ids[2],toId:ids[0],relation:'part_of',createdAt:now}];
  notice('Fictional example · changes stay in this page and are not saved. Sign in for your private workspace.');render();
}
async function importFile(file) {
  if(!file) return;if(file.size>2*1024*1024) throw new Error('Import a file smaller than 2 MB.');
  const text=await file.text();let sources,edges=[];
  if(file.name.toLowerCase().endsWith('.json')) { const data=JSON.parse(text);if(!Array.isArray(data.records)) throw new Error('Choose an Aero export with a records array.');sources=data.records.filter(r=>!r.archived);edges=Array.isArray(data.edges)?data.edges:[]; }
  else sources=[{type:'note',title:file.name.replace(/\.[^.]+$/,''),body:text,status:'open',tags:[]}];
  if(!sources.length||sources.length>100) throw new Error('Import between 1 and 100 active records at a time.');
  const ids=new Map(sources.filter(r=>r.id).map(r=>[r.id,crypto.randomUUID()]));
  const safe=sources.map(r=> {if(!kinds[r.type]||typeof r.title!=='string'||!r.title.trim()||r.title.length>160||typeof(r.body || '')!=='string'||(r.body || '').length>16000) throw new Error('A record is invalid or exceeds the editor limits.');return {id:ids.get(r.id) || crypto.randomUUID(),type:r.type,title:r.title,body:r.body || '',status:['open','active','done'].includes(r.status)?r.status:'open',tags:Array.isArray(r.tags)?r.tags.filter(t=>typeof t==='string'&&t.length<=40).slice(0,12):[],due:r.due || null,projectId:ids.get(r.projectId) || null,cloudAllowed:false};});
  const queue=[];const pending=[...safe];const done=new Set();
  while(pending.length) {const index=pending.findIndex(r=>!r.projectId||done.has(r.projectId));if(index<0) throw new Error('The import contains a cycle or missing parent project.');const [r]=pending.splice(index,1);queue.push(r);done.add(r.id);}
  confirmAction(`Import ${safe.length} records?`,'Copies will be created in this account. Every imported record starts excluded from AI. Your existing records will remain.','Import records',async()=>{
    let saved=0;try {for(const r of queue) {await saveRecord(r);saved++;}for(const e of edges) if(ids.has(e.fromId)&&ids.has(e.toId)&&relations[e.relation]) {const edge={fromId:ids.get(e.fromId),toId:ids.get(e.toId),relation:e.relation};if(state.demo) state.edges.push({...edge,id:crypto.randomUUID()});else await api('/api/edges',edge);}await loadWorkspace();render();toast(`${saved} records imported.`);}catch(e){await loadWorkspace();render();throw new Error(`${saved} records imported before this issue: ${e.message}`);}
  });
}

document.addEventListener('click',async event=>{
  const close=event.target.closest('[data-close]');if(close){close.closest('dialog')?.close();return;}
  const view=event.target.closest('[data-view]');if(view){event.preventDefault();navigate(view.dataset.view);return;}
  const filter=event.target.closest('[data-filter]');if(filter){state.filter=filter.dataset.filter;render();return;}
  const button=event.target.closest('[data-action]');if(!button||button.disabled)return;
  const {action,id,type,revision}=button.dataset;
  try {
    if(action==='add') openRecord(type);
    if(action==='detail'||action==='citation') detail(id,revision);
    if(action==='edit') {$('#detail-dialog').close();openRecord('note',id);}
    if(action==='demo') demoWorkspace();
    if(action==='archive') confirmAction('Archive this record?','It will leave current work and AI selection. You can restore it in Settings.','Archive record',()=>archive(id));
    if(action==='restore') await archive(id,true);
    if(action==='relation') {const options=activeRecords().map(r=>`<option value="${r.id}">${escape(r.title)}</option>`).join('');$('#relation-form').reset();$('#relation-form').elements.fromId.innerHTML=options;$('#relation-form').elements.toId.innerHTML=options;$('#relation-form').elements.toId.selectedIndex=1;$('#relation-error').textContent='';$('#relation-dialog').showModal();}
    if(action==='unlink') confirmAction('Remove this relationship?','The records remain. You can add the relationship again.','Remove link',async()=>{if(!state.demo)await api(`/api/edges/${id}`,undefined,'DELETE');state.edges=state.edges.filter(e=>e.id!==id);render();});
    if(action==='key-settings') {$('#context-dialog').close();navigate('settings');}
    if(action==='send') {
      button.disabled=true;button.textContent='Waiting for Aero…';$('#send-error').textContent='';
      try {const result=await api('/api/context/send',{receiptId:state.prepared.receipt.id});state.latest=result.conversation;state.conversations=[result.conversation,...state.conversations.filter(c=>c.id!==result.conversation.id)];$('#context-dialog').close();render();toast('Answer saved to your private workspace.');}catch(e){const target=$('#send-error');if(target)target.textContent=e.message;else notice(e.message,true);}finally{button.disabled=false;button.textContent='Send this request';}
    }
    if(action==='conversation') {state.latest=state.conversations.find(c=>c.id===id);render();$('.answer-panel')?.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}
    if(action==='apply') {const conversation=state.conversations.find(c=>c.proposal?.id===id);confirmAction('Accept this plan into Work?',`This will create ${conversation?.answer.steps.length || 'the proposed'} tasks and their dependency links. Source versions will be checked again.`,'Accept plan',async()=>{await api(`/api/proposals/${id}/apply`,{});await loadWorkspace();state.latest=state.conversations.find(c=>c.id===conversation?.id);render();toast('Plan accepted. The tasks are now in Work.');});}
    if(action==='export') {let blob;if(state.demo)blob=new Blob([JSON.stringify({version:1,records:state.records,edges:state.edges,preferences:state.preferences,conversations:[]},null,2)],{type:'application/json'});else{const expected=state.session.user.id;const r=await fetch('/api/export',{credentials:'same-origin',cache:'no-store',headers:{'X-Aero-Account':expected}});if(!r.ok){if(r.status===401 || r.status===409)accountInvalidated();throw new Error('The export could not be completed. Reload Aero if your sign-in changed.');}if(state.session?.user?.id!==expected)throw new Error('Your sign-in changed. Reload Aero before exporting.');blob=await r.blob();if(state.session?.user?.id!==expected)throw new Error('Your sign-in changed while the export was loading. Reload Aero.');}const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`aero-export-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);}
    if(action==='remove-key') confirmAction('Remove your personal key?','AI will use no key unless this is the verified founder account. Its server-configured key remains available.','Remove personal key',async()=>{Object.assign(state.session.user,await api('/api/settings/key',undefined,'DELETE'));render();toast('Personal key removed.');});
  }catch(e){notice(e.message,true);}
});
document.addEventListener('input',event=> {
  if(event.target.id==='record-search'){state.search=event.target.value;const view=state.view;const scoped=activeRecords().filter(r=>view==='work'?['project','task','goal'].includes(r.type):r.type===(view==='context'?'note':view==='journal'?'log':'personal'));$('#filtered-records').innerHTML=filteredRows(scoped);}
  if(event.target.name==='question'){state.draftQuestion=event.target.value;}
});
document.addEventListener('change',async event=>{
  const target=event.target;
  try {
    if(target.dataset.source){if(target.checked&&state.selected.size>=12){target.checked=false;toast('Select up to 12 records.');return;}target.checked?state.selected.add(target.dataset.source):state.selected.delete(target.dataset.source);$('#selected-count').textContent=state.selected.size;}
    if(target.dataset.task){target.disabled=true;try{await saveRecord({status:target.checked?'done':'open'},target.dataset.task);render();}catch(e){target.checked=!target.checked;throw e;}finally{target.disabled=false;}}
    if(target.name==='mode')state.draftMode=target.value;
    if(target.name==='tier')state.draftTier=target.value;
    if(target.id==='import-file')await importFile(target.files[0]);
  }catch(e){notice(e.message,true);}
});
$('#record-form').addEventListener('submit',async event=> {
  event.preventDefault();const form=event.target;const submit=form.querySelector('[type=submit]');submit.disabled=true;$('#record-error').textContent='';
  try {const data={type:form.elements.type.value,title:form.elements.title.value.trim(),body:form.elements.body.value,status:form.elements.status.value,projectId:form.elements.projectId.value || null,due:form.elements.due.value || null,tags:form.elements.tags.value.split(',').map(t=>t.trim()).filter(Boolean),cloudAllowed:form.elements.cloudAllowed.checked};if(data.tags.length>12||data.tags.some(t=>t.length>40))throw new Error('Use up to 12 tags, each no more than 40 characters.');await saveRecord(data,editing?.id,editing?.revision);$('#record-dialog').close();render();toast(state.demo?'Example updated in this page.':'Record saved.');}catch(e){$('#record-error').textContent=e.message+(e.code==='revision_conflict'?' Your draft is preserved. Copy it, then reopen the updated record.':'');if(e.code==='revision_conflict')await loadWorkspace();}finally{submit.disabled=false;}
});
$('#relation-form').addEventListener('submit',async event=> {
  event.preventDefault();const form=event.target;const data={fromId:form.elements.fromId.value,toId:form.elements.toId.value,relation:form.elements.relation.value};const submit=form.querySelector('[type=submit]');submit.disabled=true;
  try{if(data.fromId===data.toId)throw new Error('Choose two different records.');const result=state.demo?{edge:{...data,id:crypto.randomUUID()}}:await api('/api/edges',data);state.edges=[...state.edges.filter(e=>e.id!==result.edge.id),result.edge];$('#relation-dialog').close();render();toast('Relationship saved.');}catch(e){$('#relation-error').textContent=e.message;}finally{submit.disabled=false;}
});
document.addEventListener('submit',async event=> {
  const form=event.target;if(!['ask-form','preferences-form','key-form'].includes(form.id))return;event.preventDefault();const button=form.querySelector('[type=submit]');button.disabled=true;
  try{
    if(form.id==='ask-form'){state.draftQuestion=form.elements.question.value.trim();state.draftMode=form.elements.mode.value;state.draftTier=form.elements.tier.value;$('#ask-error').textContent='';const data=await api('/api/context/prepare',{question:state.draftQuestion,mode:state.draftMode,tier:state.draftTier,recordIds:[...state.selected]});showReview(data);}
    if(form.id==='preferences-form'){const preferences={...state.preferences,workspaceName:form.elements.workspaceName.value.trim(),timezone:form.elements.timezone.value.trim(),tone:form.elements.tone.value};if(!validTimezone(preferences.timezone))throw new Error('Enter a recognised time zone, such as Asia/Kolkata.');state.preferences=state.demo?preferences:(await api('/api/settings',{preferences})).preferences;updateChrome();notice();toast('Preferences saved.');}
    if(form.id==='key-form'){const key=form.elements.key.value.trim();try{Object.assign(state.session.user,await api('/api/settings/key',{key}));}finally{form.elements.key.value='';}render();toast('Your private key is connected.');}
  }catch(e){const target=form.id==='ask-form'?$('#ask-error'):null;if(target)target.textContent=e.message;else notice(e.message,true);}finally{button.disabled=false;}
});
$('#quick-add').addEventListener('click',()=>openRecord(state.view==='personal'?'personal':state.view==='journal'?'log':state.view==='work'?'task':'note'));
$('#menu-toggle').addEventListener('click',()=>{$('.sidebar').classList.toggle('open');$('#menu-toggle').setAttribute('aria-expanded',String($('.sidebar').classList.contains('open')));});
$('#signout').addEventListener('click',async()=>{try{await api('/api/logout',undefined,'POST');clearPrivateState();accountChannel?.postMessage({accountId:null});notice();navigate('home');}catch(e){notice(e.message,true);}});
document.addEventListener('keydown',event=>{if((event.key==='Enter'||event.key===' ')&&event.target.matches('.graph-node')){event.preventDefault();detail(event.target.dataset.id);}});
window.addEventListener('popstate',()=>navigate(viewFromPath(),false));
async function start() {
  try {state.session=await api('/api/session');if(state.session.authenticated)await loadWorkspace();accountChannel?.postMessage({accountId:state.session?.user?.id || null});const params=new URLSearchParams(location.search);if(params.has('auth_error')){notice('Google sign-in could not complete. Please try again.',true);history.replaceState({},'',location.pathname);}render();}
  catch(e){state.session={authenticated:false};render();notice(e.message,true);}
}
function registerBrowserTools() {
  const context=document.modelContext;if(!context?.registerTool)return;
  const lifecycle=new AbortController();
  window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
  const requireAccount=()=>{if(!state.session?.authenticated || state.demo)throw new Error('Sign in to Aero before using this tool.');};
  const validInput=(input,keys)=>{if(!input || typeof input!=='object' || Array.isArray(input) || Object.keys(input).some(key=>!keys.includes(key)))throw new Error('Invalid tool input.');};
  const tools=[{
    name:'list_aero_ai_sources',title:'List selectable Aero sources',
    description:'Read the IDs, titles, types and versions of records explicitly enabled for AI in the signed-in Aero account. Returns no bodies, keys, conversations or excluded personal records.',
    inputSchema:{type:'object',properties:{},additionalProperties:false},
    annotations:{readOnlyHint:true,untrustedContentHint:true},
    async execute(input){validInput(input,[]);requireAccount();await loadWorkspace();render();return {sources:activeRecords().filter(r=>r.cloudAllowed).map(r=>({id:r.id,title:r.title,type:r.type,revision:r.revision})),maxSelected:12};}
  },{
    name:'prepare_aero_request_review',title:'Prepare an Aero request for review',
    description:'Stage a question and explicitly chosen record IDs in Aero’s visible context review. Saves a private receipt and shows the exact outbound request. Does not send to OpenAI or accept a plan; the user completes those steps in the interface.',
    inputSchema:{type:'object',properties:{question:{type:'string',minLength:1,maxLength:4000},recordIds:{type:'array',items:{type:'string'},uniqueItems:true,maxItems:12},mode:{type:'string',enum:['answer','plan']},tier:{type:'string',enum:['luna','sol']}},required:['question','recordIds','mode','tier'],additionalProperties:false},
    annotations:{readOnlyHint:false,untrustedContentHint:true},
    async execute(input){
      validInput(input,['question','recordIds','mode','tier']);requireAccount();
      if(typeof input.question!=='string' || !input.question.trim() || input.question.length>4000 || !['answer','plan'].includes(input.mode) || !['luna','sol'].includes(input.tier) || !Array.isArray(input.recordIds) || input.recordIds.length>12 || new Set(input.recordIds).size!==input.recordIds.length || input.recordIds.some(id=>typeof id!=='string'))throw new Error('Provide a question, model, response mode and up to 12 distinct source IDs.');
      const toolRevision=++prepareToolRevision;const initialNavigation=navigationRevision;
      const question=input.question.trim();const recordIds=[...input.recordIds];const mode=input.mode;const tier=input.tier;
      const interrupted=()=>{throw new Error('The workspace changed while the review was being prepared. Please try again from Ask Aero.');};
      await loadWorkspace();if(input.recordIds.some(id=>!record(id)?.cloudAllowed || record(id)?.archived))throw new Error('Every source must be current and explicitly enabled for AI.');
      if(toolRevision!==prepareToolRevision || initialNavigation!==navigationRevision)interrupted();requireAccount();
      state.draftQuestion=question;state.draftMode=mode;state.draftTier=tier;state.selected=new Set(recordIds);
      const navigationDone=navigate('ask');const stagedNavigation=navigationRevision;await navigationDone;
      const checkStaged=()=>{requireAccount();if(toolRevision!==prepareToolRevision || stagedNavigation!==navigationRevision || state.view!=='ask')interrupted();};
      checkStaged();const data=await api('/api/context/prepare',{question,mode,tier,recordIds});checkStaged();showReview(data);
      return {status:'awaiting_user_review',receiptId:data.receipt.id,hash:data.receipt.hash,model:data.receipt.model,recordCount:data.receipt.recordCount,expiresAt:data.receipt.expiresAt};
    }
  }];
  for(const tool of tools){try{Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}}
}
start().then(registerBrowserTools);
