const header = document.querySelector('.site-header');
const toggle = header?.querySelector('.nav-toggle');
const navigation = header?.querySelector('.site-nav');

if (header && toggle && navigation) {
  document.documentElement.classList.add('js');
  const closeNavigation = () => {
    header.classList.remove('nav-open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.textContent = 'Menu';
  };
  toggle.addEventListener('click', () => {
    const isOpen = header.classList.toggle('nav-open');
    toggle.setAttribute('aria-expanded', String(isOpen));
    toggle.textContent = isOpen ? 'Close' : 'Menu';
  });
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    const hasOpenMenu = header.classList.contains('nav-open');
    header.querySelectorAll('details[open]').forEach((menu) => { menu.open = false; });
    closeNavigation();
    if (hasOpenMenu) toggle.focus();
  });
  document.addEventListener('click', (event) => {
    if (!header.contains(event.target)) {
      header.querySelectorAll('details[open]').forEach((menu) => { menu.open = false; });
      closeNavigation();
    }
  });
  header.querySelectorAll('.nav-group').forEach((menu) => {
    menu.addEventListener('toggle', () => {
      if (!menu.open) return;
      header.querySelectorAll('.nav-group').forEach((other) => {
        if (other !== menu) other.open = false;
      });
    });
  });
  matchMedia('(min-width: 861px)').addEventListener('change', closeNavigation);
}

document.querySelectorAll('[data-current-year]').forEach((node) => {
  node.textContent = String(new Date().getFullYear());
});

const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
// Reveals run once. Content remains visible if scripting or observation fails.
if ('IntersectionObserver' in window) {
  const reveal = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      if (!reducedMotion.matches) entry.target.animate(
        [{opacity:.55,transform:'translateY(16px)'},{opacity:1,transform:'none'}],
        {duration:420,easing:'cubic-bezier(.2,.75,.2,1)'}
      );
      reveal.unobserve(entry.target);
    }
  }, {threshold:.12});
  document.querySelectorAll('[data-reveal]').forEach(node => reveal.observe(node));
  const dot = new IntersectionObserver(entries => entries.forEach(entry => entry.target.classList.toggle('is-visible',entry.isIntersecting)),{threshold:.1});
  document.querySelectorAll('.footer-dot').forEach(node => dot.observe(node));
}
document.addEventListener('visibilitychange',()=>document.documentElement.classList.toggle('page-sleeping',document.hidden));
window.addEventListener('pagereveal',event=>{if(reducedMotion.matches)event.viewTransition?.skipTransition();});

document.querySelectorAll('[data-aero-preview]').forEach(preview => {
  const tabs = [...preview.querySelectorAll('[role="tab"]')];
  const select = (tab,focus=false) => {
    tabs.forEach(item => {
      const active = item === tab;
      item.setAttribute('aria-selected',String(active));item.tabIndex=active?0:-1;
      const panel=document.getElementById(item.getAttribute('aria-controls'));panel.hidden=!active;
      if(active&&!reducedMotion.matches)panel.animate([{opacity:.4,transform:'translateY(6px)'},{opacity:1,transform:'none'}],{duration:220,easing:'ease-out'});
    });
    if(focus)tab.focus();
  };
  tabs.forEach((tab,index) => {
    tab.addEventListener('click',()=>select(tab));
    tab.addEventListener('keydown',event=>{
      let next;
      if(event.key==='ArrowRight')next=(index+1)%tabs.length;
      if(event.key==='ArrowLeft')next=(index+tabs.length-1)%tabs.length;
      if(event.key==='Home')next=0;if(event.key==='End')next=tabs.length-1;
      if(next!==undefined){event.preventDefault();select(tabs[next],true);}
    });
  });
});
