import {handleApi} from '../server/index.mjs';
import {assets} from './assets.generated.mjs';

const pages={'/':'/index.html','/focus':'/focus.html','/frontiers':'/frontiers.html','/principles':'/principles.html','/research':'/research.html','/2piarc':'/2piarc.html','/about':'/about.html','/privacy':'/privacy.html','/favicon.ico':'/brand/rexzen-favicon.svg'};
const appPaths=new Set(['/aero','/aero/work','/aero/context','/aero/graph','/aero/ask','/aero/journal','/aero/personal','/aero/settings']);
const security={
  'X-Content-Type-Options':'nosniff',
  'Referrer-Policy':'strict-origin-when-cross-origin',
  'Permissions-Policy':'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'self' https://chatgpt.com https://*.chatgpt.com",
};
function secured(response){const headers=new Headers(response.headers);for(const [key,value] of Object.entries(security))headers.set(key,value);return new Response(response.body,{status:response.status,statusText:response.statusText,headers});}
function decoded(base64){const text=atob(base64);return Uint8Array.from(text,c=>c.charCodeAt(0));}
export default {async fetch(request,env){
  const url=new URL(request.url);
  // Start sign-in on one origin so host-only PKCE and session cookies agree.
  if(url.hostname==='www.rexzen.si'){url.hostname='rexzen.si';return secured(Response.redirect(url.href,308));}
  let path=url.pathname;
  if(path.length>1&&path.endsWith('/'))return secured(Response.redirect(new URL(path.slice(0,-1)+url.search,url.origin).href,308));
  const api=await handleApi(request,env);if(api)return secured(api);
  if(!['GET','HEAD'].includes(request.method))return secured(new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD'}}));
  const privatePage=appPaths.has(path);
  const key=privatePage?'/aero.html':pages[path] || path;
  const asset=assets[key];
  if(!asset)return secured(new Response('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Page not found — Rexzen</title><link rel="stylesheet" href="/site.css"><main class="page-shell page-hero"><h1>Page not found.</h1><p>This address does not have a page.</p><a href="/">Return to Rexzen</a></main></html>',{status:404,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}}));
  return secured(new Response(request.method==='HEAD'?null:decoded(asset.body),{headers:{'Content-Type':asset.type,'Cache-Control':privatePage?'private, no-store':asset.type.startsWith('text/html')?'public, max-age=0, must-revalidate':'public, max-age=300','ETag':`"${asset.hash}"`,...(privatePage?{'X-Robots-Tag':'noindex, nofollow'}:{})}}));
}};
